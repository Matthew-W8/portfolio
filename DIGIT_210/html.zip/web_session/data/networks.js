var networks = {"moves_output.tsv": {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.3",
  "target_cytoscapejs_version" : "~2.1",
  "data" : {
    "shared_name" : "moves_output.tsv",
    "name" : "moves_output.tsv",
    "SUID" : 179,
    "__Annotations" : [ ],
    "selected" : true
  },
  "elements" : {
    "nodes" : [ {
      "data" : {
        "id" : "3957",
        "shared_name" : "Work Up",
        "name" : "Work Up",
        "SUID" : 3957,
        "selected" : false
      },
      "position" : {
        "x" : 585.5395964940304,
        "y" : 408.3817206187251
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3953",
        "shared_name" : "Wonder Room",
        "name" : "Wonder Room",
        "SUID" : 3953,
        "selected" : false
      },
      "position" : {
        "x" : 730.5475959141964,
        "y" : 125.4632216258052
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3949",
        "shared_name" : "Wild Charge",
        "name" : "Wild Charge",
        "SUID" : 3949,
        "selected" : false
      },
      "position" : {
        "x" : 831.4501532872433,
        "y" : 102.14761264753372
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3945",
        "shared_name" : "Wide Guard",
        "name" : "Wide Guard",
        "SUID" : 3945,
        "selected" : false
      },
      "position" : {
        "x" : 869.4341468175168,
        "y" : 194.65166576337845
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3941",
        "shared_name" : "Water Pledge",
        "name" : "Water Pledge",
        "SUID" : 3941,
        "selected" : false
      },
      "position" : {
        "x" : 443.2294959386105,
        "y" : 117.82474048566849
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3937",
        "shared_name" : "Volt Switch",
        "name" : "Volt Switch",
        "SUID" : 3937,
        "selected" : false
      },
      "position" : {
        "x" : 694.3085135777707,
        "y" : -56.5915765004155
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3933",
        "shared_name" : "Venoshock",
        "name" : "Venoshock",
        "SUID" : 3933,
        "selected" : false
      },
      "position" : {
        "x" : 859.0399817784543,
        "y" : 57.62827976179153
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3929",
        "shared_name" : "V-create",
        "name" : "V-create",
        "SUID" : 3929,
        "selected" : false
      },
      "position" : {
        "x" : 691.292003568005,
        "y" : 385.19905765485794
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3925",
        "shared_name" : "Telekinesis",
        "name" : "Telekinesis",
        "SUID" : 3925,
        "selected" : false
      },
      "position" : {
        "x" : 506.04584115345426,
        "y" : 232.2712164683345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3921",
        "shared_name" : "Techno Blast",
        "name" : "Techno Blast",
        "SUID" : 3921,
        "selected" : false
      },
      "position" : {
        "x" : 400.19449227650114,
        "y" : 200.8526716990474
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3917",
        "shared_name" : "Tail Slap",
        "name" : "Tail Slap",
        "SUID" : 3917,
        "selected" : false
      },
      "position" : {
        "x" : 756.3418921788449,
        "y" : 10.282095984936063
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3913",
        "shared_name" : "Synchronoise",
        "name" : "Synchronoise",
        "SUID" : 3913,
        "selected" : false
      },
      "position" : {
        "x" : 885.823841031384,
        "y" : 102.96201999616653
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3909",
        "shared_name" : "Struggle Bug",
        "name" : "Struggle Bug",
        "SUID" : 3909,
        "selected" : false
      },
      "position" : {
        "x" : 755.7822608311886,
        "y" : -35.93233577775925
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3905",
        "shared_name" : "Storm Throw",
        "name" : "Storm Throw",
        "SUID" : 3905,
        "selected" : false
      },
      "position" : {
        "x" : 724.6143760045285,
        "y" : 422.6366492075923
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3901",
        "shared_name" : "Stored Power",
        "name" : "Stored Power",
        "SUID" : 3901,
        "selected" : false
      },
      "position" : {
        "x" : 587.4034919102902,
        "y" : 356.29085452985794
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3897",
        "shared_name" : "Steamroller",
        "name" : "Steamroller",
        "SUID" : 3897,
        "selected" : false
      },
      "position" : {
        "x" : 505.0028800328488,
        "y" : 13.836295203686063
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3893",
        "shared_name" : "Soak",
        "name" : "Soak",
        "SUID" : 3893,
        "selected" : false
      },
      "position" : {
        "x" : 591.8212088902707,
        "y" : 184.742041663647
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3889",
        "shared_name" : "Snarl",
        "name" : "Snarl",
        "SUID" : 3889,
        "selected" : false
      },
      "position" : {
        "x" : 711.7601584752316,
        "y" : 37.48381717634231
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3885",
        "shared_name" : "Smack Down",
        "name" : "Smack Down",
        "SUID" : 3885,
        "selected" : false
      },
      "position" : {
        "x" : 570.2286300023312,
        "y" : 314.25032718610794
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3881",
        "shared_name" : "Sludge Wave",
        "name" : "Sludge Wave",
        "SUID" : 3881,
        "selected" : false
      },
      "position" : {
        "x" : 930.4570502598996,
        "y" : 119.19257648420364
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3877",
        "shared_name" : "Sky Drop",
        "name" : "Sky Drop",
        "SUID" : 3877,
        "selected" : false
      },
      "position" : {
        "x" : 511.5581244786496,
        "y" : 282.07325656843216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3873",
        "shared_name" : "Simple Beam",
        "name" : "Simple Beam",
        "SUID" : 3873,
        "selected" : false
      },
      "position" : {
        "x" : 623.3203167279477,
        "y" : 94.96794803571731
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3869",
        "shared_name" : "Shift Gear",
        "name" : "Shift Gear",
        "SUID" : 3869,
        "selected" : false
      },
      "position" : {
        "x" : 631.7661055882687,
        "y" : -101.26264278459519
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3865",
        "shared_name" : "Shell Smash",
        "name" : "Shell Smash",
        "SUID" : 3865,
        "selected" : false
      },
      "position" : {
        "x" : 715.5938071568722,
        "y" : 256.76100070905716
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3861",
        "shared_name" : "Secret Sword",
        "name" : "Secret Sword",
        "SUID" : 3861,
        "selected" : false
      },
      "position" : {
        "x" : 551.9757346471066,
        "y" : 32.39849002790481
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3857",
        "shared_name" : "Searing Shot",
        "name" : "Searing Shot",
        "SUID" : 3857,
        "selected" : false
      },
      "position" : {
        "x" : 551.2578315098996,
        "y" : 215.28954227399856
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3853",
        "shared_name" : "Scald",
        "name" : "Scald",
        "SUID" : 3853,
        "selected" : false
      },
      "position" : {
        "x" : 641.9283923466916,
        "y" : 367.35892398786575
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3849",
        "shared_name" : "Sacred Sword",
        "name" : "Sacred Sword",
        "SUID" : 3849,
        "selected" : false
      },
      "position" : {
        "x" : 890.0153998692746,
        "y" : 276.8282538218501
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3845",
        "shared_name" : "Round",
        "name" : "Round",
        "SUID" : 3845,
        "selected" : false
      },
      "position" : {
        "x" : 850.0119361241574,
        "y" : 241.96459110212356
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3841",
        "shared_name" : "Retaliate",
        "name" : "Retaliate",
        "SUID" : 3841,
        "selected" : false
      },
      "position" : {
        "x" : 579.8679580052609,
        "y" : 122.44867618513138
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3837",
        "shared_name" : "Relic Song",
        "name" : "Relic Song",
        "SUID" : 3837,
        "selected" : false
      },
      "position" : {
        "x" : 710.1772193272824,
        "y" : 207.69805438947708
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3833",
        "shared_name" : "Reflect Type",
        "name" : "Reflect Type",
        "SUID" : 3833,
        "selected" : false
      },
      "position" : {
        "x" : 563.2541083653683,
        "y" : -11.134423180103
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3829",
        "shared_name" : "Razor Shell",
        "name" : "Razor Shell",
        "SUID" : 3829,
        "selected" : false
      },
      "position" : {
        "x" : 796.3639411290402,
        "y" : 392.1268835825923
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3825",
        "shared_name" : "Rage Powder",
        "name" : "Rage Powder",
        "SUID" : 3825,
        "selected" : false
      },
      "position" : {
        "x" : 541.3799247105832,
        "y" : -56.18563167619675
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3821",
        "shared_name" : "Quiver Dance",
        "name" : "Quiver Dance",
        "SUID" : 3821,
        "selected" : false
      },
      "position" : {
        "x" : 707.8452414830441,
        "y" : -10.943215294360812
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3817",
        "shared_name" : "Quick Guard",
        "name" : "Quick Guard",
        "SUID" : 3817,
        "selected" : false
      },
      "position" : {
        "x" : 797.7782630284543,
        "y" : 243.59762485456497
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3813",
        "shared_name" : "Quash",
        "name" : "Quash",
        "SUID" : 3813,
        "selected" : false
      },
      "position" : {
        "x" : 494.06657021839567,
        "y" : -40.53719417619675
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3809",
        "shared_name" : "Psystrike",
        "name" : "Psystrike",
        "SUID" : 3809,
        "selected" : false
      },
      "position" : {
        "x" : 651.2889975865597,
        "y" : 234.14422519636184
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3805",
        "shared_name" : "Psyshock",
        "name" : "Psyshock",
        "SUID" : 3805,
        "selected" : false
      },
      "position" : {
        "x" : 766.8960761388058,
        "y" : 166.1360595984462
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3801",
        "shared_name" : "Power Split",
        "name" : "Power Split",
        "SUID" : 3801,
        "selected" : false
      },
      "position" : {
        "x" : 820.9037818272824,
        "y" : 340.7945776743892
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3797",
        "shared_name" : "Night Daze",
        "name" : "Night Daze",
        "SUID" : 3797,
        "selected" : false
      },
      "position" : {
        "x" : 815.5096778233761,
        "y" : -54.2146233754155
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3793",
        "shared_name" : "Magic Room",
        "name" : "Magic Room",
        "SUID" : 3793,
        "selected" : false
      },
      "position" : {
        "x" : 856.591663297009,
        "y" : 146.45181377363235
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3789",
        "shared_name" : "Low Sweep",
        "name" : "Low Sweep",
        "SUID" : 3789,
        "selected" : false
      },
      "position" : {
        "x" : 758.521839078259,
        "y" : 220.52207477521927
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3785",
        "shared_name" : "Leaf Tornado",
        "name" : "Leaf Tornado",
        "SUID" : 3785,
        "selected" : false
      },
      "position" : {
        "x" : 634.2086982091183,
        "y" : -50.11188594865769
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3781",
        "shared_name" : "Inferno",
        "name" : "Inferno",
        "SUID" : 3781,
        "selected" : false
      },
      "position" : {
        "x" : 675.1639060338254,
        "y" : 285.6395254893306
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3777",
        "shared_name" : "Incinerate",
        "name" : "Incinerate",
        "SUID" : 3777,
        "selected" : false
      },
      "position" : {
        "x" : 472.86432259876676,
        "y" : 341.6200018687251
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3773",
        "shared_name" : "Icicle Crash",
        "name" : "Icicle Crash",
        "SUID" : 3773,
        "selected" : false
      },
      "position" : {
        "x" : 560.8870810826535,
        "y" : 265.7239523692134
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3769",
        "shared_name" : "Ice Burn",
        "name" : "Ice Burn",
        "SUID" : 3769,
        "selected" : false
      },
      "position" : {
        "x" : 461.60533517200895,
        "y" : 66.30399234724075
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3765",
        "shared_name" : "Hurricane",
        "name" : "Hurricane",
        "SUID" : 3765,
        "selected" : false
      },
      "position" : {
        "x" : 916.3673285802121,
        "y" : 177.84917457532913
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3761",
        "shared_name" : "Horn Leech",
        "name" : "Horn Leech",
        "SUID" : 3761,
        "selected" : false
      },
      "position" : {
        "x" : 530.9301108678097,
        "y" : 380.23689945173294
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3757",
        "shared_name" : "Hone Claws",
        "name" : "Hone Claws",
        "SUID" : 3757,
        "selected" : false
      },
      "position" : {
        "x" : 806.9474067052121,
        "y" : 145.10656269025833
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3753",
        "shared_name" : "Hex",
        "name" : "Hex",
        "SUID" : 3753,
        "selected" : false
      },
      "position" : {
        "x" : 461.9093970616574,
        "y" : 288.5172415537837
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3749",
        "shared_name" : "Heavy Slam",
        "name" : "Heavy Slam",
        "SUID" : 3749,
        "selected" : false
      },
      "position" : {
        "x" : 778.7619361241574,
        "y" : 323.18904788923294
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3745",
        "shared_name" : "Heat Crash",
        "name" : "Heat Crash",
        "SUID" : 3745,
        "selected" : false
      },
      "position" : {
        "x" : 488.2408942540402,
        "y" : 133.9899321360591
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3741",
        "shared_name" : "Heart Stamp",
        "name" : "Heart Stamp",
        "SUID" : 3741,
        "selected" : false
      },
      "position" : {
        "x" : 607.8377055485959,
        "y" : -5.991661949634249
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3737",
        "shared_name" : "Heal Pulse",
        "name" : "Heal Pulse",
        "SUID" : 3737,
        "selected" : false
      },
      "position" : {
        "x" : 701.5354575474972,
        "y" : 85.72923191022903
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3733",
        "shared_name" : "Head Charge",
        "name" : "Head Charge",
        "SUID" : 3733,
        "selected" : false
      },
      "position" : {
        "x" : 454.14117806751676,
        "y" : 226.65851505231888
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3729",
        "shared_name" : "Guard Split",
        "name" : "Guard Split",
        "SUID" : 3729,
        "selected" : false
      },
      "position" : {
        "x" : 415.8328131993527,
        "y" : 265.08248813581497
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3725",
        "shared_name" : "Grass Pledge",
        "name" : "Grass Pledge",
        "SUID" : 3725,
        "selected" : false
      },
      "position" : {
        "x" : 522.5225562413449,
        "y" : 329.6730719370845
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3721",
        "shared_name" : "Glaciate",
        "name" : "Glaciate",
        "SUID" : 3721,
        "selected" : false
      },
      "position" : {
        "x" : 915.0450629552121,
        "y" : 229.97271640729934
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3717",
        "shared_name" : "Gear Grind",
        "name" : "Gear Grind",
        "SUID" : 3717,
        "selected" : false
      },
      "position" : {
        "x" : 853.5659980138058,
        "y" : -4.519844933032687
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3713",
        "shared_name" : "Fusion Flare",
        "name" : "Fusion Flare",
        "SUID" : 3713,
        "selected" : false
      },
      "position" : {
        "x" : 397.9012183507199,
        "y" : 141.98059375715286
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3709",
        "shared_name" : "Fusion Bolt",
        "name" : "Fusion Bolt",
        "SUID" : 3709,
        "selected" : false
      },
      "position" : {
        "x" : 812.4709357579464,
        "y" : 61.554076270580595
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3705",
        "shared_name" : "Frost Breath",
        "name" : "Frost Breath",
        "SUID" : 3705,
        "selected" : false
      },
      "position" : {
        "x" : 615.8841146786923,
        "y" : 37.45054538679153
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3701",
        "shared_name" : "Freeze Shock",
        "name" : "Freeze Shock",
        "SUID" : 3701,
        "selected" : false
      },
      "position" : {
        "x" : 759.0163459141964,
        "y" : 274.4995871348384
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3697",
        "shared_name" : "Foul Play",
        "name" : "Foul Play",
        "SUID" : 3697,
        "selected" : false
      },
      "position" : {
        "x" : 690.356067593884,
        "y" : 339.2147894663814
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3693",
        "shared_name" : "Flame Charge",
        "name" : "Flame Charge",
        "SUID" : 3693,
        "selected" : false
      },
      "position" : {
        "x" : 760.0586127598996,
        "y" : 55.38644321393997
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3689",
        "shared_name" : "Flame Burst",
        "name" : "Flame Burst",
        "SUID" : 3689,
        "selected" : false
      },
      "position" : {
        "x" : 898.8267402013058,
        "y" : 26.10701663923294
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3685",
        "shared_name" : "Fire Pledge",
        "name" : "Fire Pledge",
        "SUID" : 3685,
        "selected" : false
      },
      "position" : {
        "x" : 540.9432563145871,
        "y" : 156.96205194425613
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3681",
        "shared_name" : "Final Gambit",
        "name" : "Final Gambit",
        "SUID" : 3681,
        "selected" : false
      },
      "position" : {
        "x" : 820.0143317540402,
        "y" : 196.3119116587642
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3677",
        "shared_name" : "Fiery Dance",
        "name" : "Fiery Dance",
        "SUID" : 3677,
        "selected" : false
      },
      "position" : {
        "x" : 804.500842984509,
        "y" : 1.7226324839595009
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3673",
        "shared_name" : "Entrainment",
        "name" : "Entrainment",
        "SUID" : 3673,
        "selected" : false
      },
      "position" : {
        "x" : 526.0356101353879,
        "y" : 105.84550769758255
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3669",
        "shared_name" : "Electroweb",
        "name" : "Electroweb",
        "SUID" : 3669,
        "selected" : false
      },
      "position" : {
        "x" : 583.4074439366574,
        "y" : -81.40340511369675
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3665",
        "shared_name" : "Electro Ball",
        "name" : "Electro Ball",
        "SUID" : 3665,
        "selected" : false
      },
      "position" : {
        "x" : 602.0097655614132,
        "y" : 233.60501773786575
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3661",
        "shared_name" : "Echoed Voice",
        "name" : "Echoed Voice",
        "SUID" : 3661,
        "selected" : false
      },
      "position" : {
        "x" : 748.0665625890011,
        "y" : 366.29268558454544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3657",
        "shared_name" : "Dual Chop",
        "name" : "Dual Chop",
        "SUID" : 3657,
        "selected" : false
      },
      "position" : {
        "x" : 641.4084472020382,
        "y" : 321.69332035017044
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3653",
        "shared_name" : "Drill Run",
        "name" : "Drill Run",
        "SUID" : 3653,
        "selected" : false
      },
      "position" : {
        "x" : 411.4533423741574,
        "y" : 67.0583487315181
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3649",
        "shared_name" : "Dragon Tail",
        "name" : "Dragon Tail",
        "SUID" : 3649,
        "selected" : false
      },
      "position" : {
        "x" : 505.8619193394894,
        "y" : 66.69074924421341
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3645",
        "shared_name" : "Cotton Guard",
        "name" : "Cotton Guard",
        "SUID" : 3645,
        "selected" : false
      },
      "position" : {
        "x" : 757.161243375134,
        "y" : -86.06539241838425
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3641",
        "shared_name" : "Coil",
        "name" : "Coil",
        "SUID" : 3641,
        "selected" : false
      },
      "position" : {
        "x" : 696.2244452794308,
        "y" : -102.90265743303269
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3637",
        "shared_name" : "Clear Smog",
        "name" : "Clear Smog",
        "SUID" : 3637,
        "selected" : false
      },
      "position" : {
        "x" : 866.6558112462277,
        "y" : 318.6888495249751
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3633",
        "shared_name" : "Circle Throw",
        "name" : "Circle Throw",
        "SUID" : 3633,
        "selected" : false
      },
      "position" : {
        "x" : 659.6192168553586,
        "y" : -6.689171715259249
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3629",
        "shared_name" : "Chip Away",
        "name" : "Chip Away",
        "SUID" : 3629,
        "selected" : false
      },
      "position" : {
        "x" : 644.3221072514767,
        "y" : 421.5350561900142
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3625",
        "shared_name" : "Bulldoze",
        "name" : "Bulldoze",
        "SUID" : 3625,
        "selected" : false
      },
      "position" : {
        "x" : 776.4971198399777,
        "y" : 101.71356876325638
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3621",
        "shared_name" : "Bolt Strike",
        "name" : "Bolt Strike",
        "SUID" : 3621,
        "selected" : false
      },
      "position" : {
        "x" : 824.390750821423,
        "y" : 285.8212118906978
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3617",
        "shared_name" : "Blue Flare",
        "name" : "Blue Flare",
        "SUID" : 3617,
        "selected" : false
      },
      "position" : {
        "x" : 663.0406798680539,
        "y" : 44.35568149518997
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3613",
        "shared_name" : "Bestow",
        "name" : "Bestow",
        "SUID" : 3613,
        "selected" : false
      },
      "position" : {
        "x" : 569.388008054089,
        "y" : 74.99646671247513
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3609",
        "shared_name" : "Autotomize",
        "name" : "Autotomize",
        "SUID" : 3609,
        "selected" : false
      },
      "position" : {
        "x" : 455.1481665929074,
        "y" : 5.925620154857938
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3605",
        "shared_name" : "Ally Switch",
        "name" : "Ally Switch",
        "SUID" : 3605,
        "selected" : false
      },
      "position" : {
        "x" : 725.7622641881222,
        "y" : 312.9675818247798
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3601",
        "shared_name" : "After You",
        "name" : "After You",
        "SUID" : 3601,
        "selected" : false
      },
      "position" : {
        "x" : 506.29558938343473,
        "y" : 184.2849226756099
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3597",
        "shared_name" : "Acrobatics",
        "name" : "Acrobatics",
        "SUID" : 3597,
        "selected" : false
      },
      "position" : {
        "x" : 456.00601571400114,
        "y" : 172.0665865702632
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3593",
        "shared_name" : "Acid Spray",
        "name" : "Acid Spray",
        "SUID" : 3593,
        "selected" : false
      },
      "position" : {
        "x" : 612.8615464528317,
        "y" : 286.4917441172603
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3591",
        "shared_name" : "gen5",
        "name" : "gen5",
        "SUID" : 3591,
        "selected" : false
      },
      "position" : {
        "x" : 663.3768004735226,
        "y" : 159.457533435345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3587",
        "shared_name" : "Wicked Torque",
        "name" : "Wicked Torque",
        "SUID" : 3587,
        "selected" : false
      },
      "position" : {
        "x" : -263.0092392603641,
        "y" : 724.7312498850825
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3583",
        "shared_name" : "Upper Hand",
        "name" : "Upper Hand",
        "SUID" : 3583,
        "selected" : false
      },
      "position" : {
        "x" : -55.330825869250816,
        "y" : 600.3816557688716
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3579",
        "shared_name" : "Twin Beam",
        "name" : "Twin Beam",
        "SUID" : 3579,
        "selected" : false
      },
      "position" : {
        "x" : 25.58363335926481,
        "y" : 742.6374541087154
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3575",
        "shared_name" : "Triple Dive",
        "name" : "Triple Dive",
        "SUID" : 3575,
        "selected" : false
      },
      "position" : {
        "x" : -191.85151678721957,
        "y" : 618.0989409251216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3571",
        "shared_name" : "Trailblaze",
        "name" : "Trailblaze",
        "SUID" : 3571,
        "selected" : false
      },
      "position" : {
        "x" : -160.9374390284305,
        "y" : 991.3118582530025
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3567",
        "shared_name" : "Torch Song",
        "name" : "Torch Song",
        "SUID" : 3567,
        "selected" : false
      },
      "position" : {
        "x" : -13.600112978625816,
        "y" : 982.9900542063716
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3563",
        "shared_name" : "Tidy Up",
        "name" : "Tidy Up",
        "SUID" : 3563,
        "selected" : false
      },
      "position" : {
        "x" : 126.44053643543668,
        "y" : 609.0681486887935
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3559",
        "shared_name" : "Thunderclap",
        "name" : "Thunderclap",
        "SUID" : 3559,
        "selected" : false
      },
      "position" : {
        "x" : -66.29452521007113,
        "y" : 974.1938334269527
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3555",
        "shared_name" : "Tera Starstorm",
        "name" : "Tera Starstorm",
        "SUID" : 3555,
        "selected" : false
      },
      "position" : {
        "x" : -88.88639837901644,
        "y" : 644.4329253001216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3551",
        "shared_name" : "Tera Blast",
        "name" : "Tera Blast",
        "SUID" : 3551,
        "selected" : false
      },
      "position" : {
        "x" : -274.9766350428348,
        "y" : 798.9795561594966
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3547",
        "shared_name" : "Temper Flare",
        "name" : "Temper Flare",
        "SUID" : 3547,
        "selected" : false
      },
      "position" : {
        "x" : -196.3811417261844,
        "y" : 860.5464812083247
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3543",
        "shared_name" : "Tachyon Cutter",
        "name" : "Tachyon Cutter",
        "SUID" : 3543,
        "selected" : false
      },
      "position" : {
        "x" : 103.21626275379606,
        "y" : 863.31169422102
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3539",
        "shared_name" : "Syrup Bomb",
        "name" : "Syrup Bomb",
        "SUID" : 3539,
        "selected" : false
      },
      "position" : {
        "x" : 107.83586114246793,
        "y" : 923.6523791117671
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3535",
        "shared_name" : "Supercell Slam",
        "name" : "Supercell Slam",
        "SUID" : 3535,
        "selected" : false
      },
      "position" : {
        "x" : -143.31201178233675,
        "y" : 606.093905524731
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3531",
        "shared_name" : "Spin Out",
        "name" : "Spin Out",
        "SUID" : 3531,
        "selected" : false
      },
      "position" : {
        "x" : 135.90769952137418,
        "y" : 660.2861967844966
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3527",
        "shared_name" : "Spicy Extract",
        "name" : "Spicy Extract",
        "SUID" : 3527,
        "selected" : false
      },
      "position" : {
        "x" : 20.023910458874184,
        "y" : 691.805590705395
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3523",
        "shared_name" : "Snowscape",
        "name" : "Snowscape",
        "SUID" : 3523,
        "selected" : false
      },
      "position" : {
        "x" : -19.371658388782066,
        "y" : 633.6805449290279
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3519",
        "shared_name" : "Silk Trap",
        "name" : "Silk Trap",
        "SUID" : 3519,
        "selected" : false
      },
      "position" : {
        "x" : -175.87043768565707,
        "y" : 697.4403258128169
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3515",
        "shared_name" : "Shed Tail",
        "name" : "Shed Tail",
        "SUID" : 3515,
        "selected" : false
      },
      "position" : {
        "x" : 71.47932427723356,
        "y" : 700.756274299145
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3511",
        "shared_name" : "Salt Cure",
        "name" : "Salt Cure",
        "SUID" : 3511,
        "selected" : false
      },
      "position" : {
        "x" : -184.71948248546175,
        "y" : 808.2335081858638
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3507",
        "shared_name" : "Ruination",
        "name" : "Ruination",
        "SUID" : 3507,
        "selected" : false
      },
      "position" : {
        "x" : -107.24617010753207,
        "y" : 953.616517142773
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3503",
        "shared_name" : "Revival Blessing",
        "name" : "Revival Blessing",
        "SUID" : 3503,
        "selected" : false
      },
      "position" : {
        "x" : 126.93806451160856,
        "y" : 713.0857268137935
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3499",
        "shared_name" : "Raging Bull",
        "name" : "Raging Bull",
        "SUID" : 3499,
        "selected" : false
      },
      "position" : {
        "x" : -18.078079287219566,
        "y" : 893.41179187727
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3495",
        "shared_name" : "Rage Fist",
        "name" : "Rage Fist",
        "SUID" : 3495,
        "selected" : false
      },
      "position" : {
        "x" : -227.62763220470003,
        "y" : 774.2285795969966
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3491",
        "shared_name" : "Psychic Noise",
        "name" : "Psychic Noise",
        "SUID" : 3491,
        "selected" : false
      },
      "position" : {
        "x" : 21.60462945301481,
        "y" : 867.2046232981685
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3487",
        "shared_name" : "Psyblade",
        "name" : "Psyblade",
        "SUID" : 3487,
        "selected" : false
      },
      "position" : {
        "x" : 54.52992242176481,
        "y" : 962.1587458415034
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3483",
        "shared_name" : "Pounce",
        "name" : "Pounce",
        "SUID" : 3483,
        "selected" : false
      },
      "position" : {
        "x" : -160.22518927257113,
        "y" : 888.8824682993892
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3479",
        "shared_name" : "Population Bomb",
        "name" : "Population Bomb",
        "SUID" : 3479,
        "selected" : false
      },
      "position" : {
        "x" : -61.797302309680504,
        "y" : 546.4192534251216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3475",
        "shared_name" : "Order Up",
        "name" : "Order Up",
        "SUID" : 3475,
        "selected" : false
      },
      "position" : {
        "x" : -212.5408554713016,
        "y" : 725.4387541575435
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3471",
        "shared_name" : "Noxious Torque",
        "name" : "Noxious Torque",
        "SUID" : 3471,
        "selected" : false
      },
      "position" : {
        "x" : -151.56523138682894,
        "y" : 659.0923796458247
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3467",
        "shared_name" : "Mortal Spin",
        "name" : "Mortal Spin",
        "SUID" : 3467,
        "selected" : false
      },
      "position" : {
        "x" : 178.53184502918668,
        "y" : 687.721591071606
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3463",
        "shared_name" : "Mighty Cleave",
        "name" : "Mighty Cleave",
        "SUID" : 3463,
        "selected" : false
      },
      "position" : {
        "x" : 72.64228814442106,
        "y" : 581.7338286204341
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3459",
        "shared_name" : "Matcha Gotcha",
        "name" : "Matcha Gotcha",
        "SUID" : 3459,
        "selected" : false
      },
      "position" : {
        "x" : -97.71369940440707,
        "y" : 893.369971351147
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3455",
        "shared_name" : "Malignant Chain",
        "name" : "Malignant Chain",
        "SUID" : 3455,
        "selected" : false
      },
      "position" : {
        "x" : 191.80940240223356,
        "y" : 894.9472609324458
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3451",
        "shared_name" : "Make It Rain",
        "name" : "Make It Rain",
        "SUID" : 3451,
        "selected" : false
      },
      "position" : {
        "x" : -125.70434576671175,
        "y" : 851.1948347849849
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3447",
        "shared_name" : "Magical Torque",
        "name" : "Magical Torque",
        "SUID" : 3447,
        "selected" : false
      },
      "position" : {
        "x" : -124.84582525889925,
        "y" : 704.5940886301997
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3443",
        "shared_name" : "Lumina Crash",
        "name" : "Lumina Crash",
        "SUID" : 3443,
        "selected" : false
      },
      "position" : {
        "x" : 199.39134209949918,
        "y" : 820.8111372752193
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3439",
        "shared_name" : "Last Respects",
        "name" : "Last Respects",
        "SUID" : 3439,
        "selected" : false
      },
      "position" : {
        "x" : 128.01994317371793,
        "y" : 775.0912047190669
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3435",
        "shared_name" : "Kowtow Cleave",
        "name" : "Kowtow Cleave",
        "SUID" : 3435,
        "selected" : false
      },
      "position" : {
        "x" : 86.73832696278043,
        "y" : 650.3914213938716
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3431",
        "shared_name" : "Jet Punch",
        "name" : "Jet Punch",
        "SUID" : 3431,
        "selected" : false
      },
      "position" : {
        "x" : 141.45353692371793,
        "y" : 822.2112303538325
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3427",
        "shared_name" : "Ivy Cudgel",
        "name" : "Ivy Cudgel",
        "SUID" : 3427,
        "selected" : false
      },
      "position" : {
        "x" : -36.88792425792269,
        "y" : 673.4986601634029
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3423",
        "shared_name" : "Ice Spinner",
        "name" : "Ice Spinner",
        "SUID" : 3423,
        "selected" : false
      },
      "position" : {
        "x" : -48.96952826182894,
        "y" : 924.0141421122554
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3419",
        "shared_name" : "Hyper Drill",
        "name" : "Hyper Drill",
        "SUID" : 3419,
        "selected" : false
      },
      "position" : {
        "x" : 215.69328301746793,
        "y" : 748.753085212231
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3415",
        "shared_name" : "Hydro Steam",
        "name" : "Hydro Steam",
        "SUID" : 3415,
        "selected" : false
      },
      "position" : {
        "x" : 12.554000790905434,
        "y" : 600.5568571848872
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3411",
        "shared_name" : "Hard Press",
        "name" : "Hard Press",
        "SUID" : 3411,
        "selected" : false
      },
      "position" : {
        "x" : 16.85774224598356,
        "y" : 549.735751227856
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3407",
        "shared_name" : "Glaive Rush",
        "name" : "Glaive Rush",
        "SUID" : 3407,
        "selected" : false
      },
      "position" : {
        "x" : 10.971450742077309,
        "y" : 937.5964842600825
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3403",
        "shared_name" : "Gigaton Hammer",
        "name" : "Gigaton Hammer",
        "SUID" : 3403,
        "selected" : false
      },
      "position" : {
        "x" : -226.6119995753055,
        "y" : 664.472323493481
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3399",
        "shared_name" : "Flower Trick",
        "name" : "Flower Trick",
        "SUID" : 3399,
        "selected" : false
      },
      "position" : {
        "x" : -109.95246893565707,
        "y" : 756.2698088450435
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3395",
        "shared_name" : "Fillet Away",
        "name" : "Fillet Away",
        "SUID" : 3395,
        "selected" : false
      },
      "position" : {
        "x" : 63.52564996082731,
        "y" : 843.0450621409419
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3391",
        "shared_name" : "Fickle Beam",
        "name" : "Fickle Beam",
        "SUID" : 3391,
        "selected" : false
      },
      "position" : {
        "x" : 148.36448663074918,
        "y" : 947.7152891917232
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3387",
        "shared_name" : "Electro Shot",
        "name" : "Electro Shot",
        "SUID" : 3387,
        "selected" : false
      },
      "position" : {
        "x" : -98.10923773448519,
        "y" : 1016.7098189158443
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3383",
        "shared_name" : "Electro Drift",
        "name" : "Electro Drift",
        "SUID" : 3383,
        "selected" : false
      },
      "position" : {
        "x" : 152.18376153309293,
        "y" : 876.1242552561763
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3379",
        "shared_name" : "Dragon Cheer",
        "name" : "Dragon Cheer",
        "SUID" : 3379,
        "selected" : false
      },
      "position" : {
        "x" : 36.693283017467934,
        "y" : 1017.3851729197505
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3375",
        "shared_name" : "Double Shock",
        "name" : "Double Shock",
        "SUID" : 3375,
        "selected" : false
      },
      "position" : {
        "x" : -110.0636597315555,
        "y" : 574.8544951243404
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3371",
        "shared_name" : "Doodle",
        "name" : "Doodle",
        "SUID" : 3371,
        "selected" : false
      },
      "position" : {
        "x" : 64.50083916981168,
        "y" : 903.4657355113033
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3367",
        "shared_name" : "Comeuppance",
        "name" : "Comeuppance",
        "SUID" : 3367,
        "selected" : false
      },
      "position" : {
        "x" : 75.14781182606168,
        "y" : 795.5919981760982
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3363",
        "shared_name" : "Combat Torque",
        "name" : "Combat Torque",
        "SUID" : 3363,
        "selected" : false
      },
      "position" : {
        "x" : -231.461242739368,
        "y" : 894.5290556712154
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3359",
        "shared_name" : "Collision Course",
        "name" : "Collision Course",
        "SUID" : 3359,
        "selected" : false
      },
      "position" : {
        "x" : 37.52497857410856,
        "y" : 639.2639799876216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3355",
        "shared_name" : "Chilly Reception",
        "name" : "Chilly Reception",
        "SUID" : 3355,
        "selected" : false
      },
      "position" : {
        "x" : -166.0299683253055,
        "y" : 760.0473967356685
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3351",
        "shared_name" : "Chilling Water",
        "name" : "Chilling Water",
        "SUID" : 3351,
        "selected" : false
      },
      "position" : {
        "x" : -74.98062140147738,
        "y" : 705.9301787180904
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3347",
        "shared_name" : "Burning Bulwark",
        "name" : "Burning Bulwark",
        "SUID" : 3347,
        "selected" : false
      },
      "position" : {
        "x" : 100.26789849598356,
        "y" : 989.8612089915279
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3343",
        "shared_name" : "Blood Moon",
        "name" : "Blood Moon",
        "SUID" : 3343,
        "selected" : false
      },
      "position" : {
        "x" : -248.04582983653597,
        "y" : 845.6801253123286
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3339",
        "shared_name" : "Blazing Torque",
        "name" : "Blazing Torque",
        "SUID" : 3339,
        "selected" : false
      },
      "position" : {
        "x" : 81.24095147449918,
        "y" : 747.3769255442622
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3335",
        "shared_name" : "Bitter Blade",
        "name" : "Bitter Blade",
        "SUID" : 3335,
        "selected" : false
      },
      "position" : {
        "x" : 168.37763970692106,
        "y" : 757.87321765852
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3331",
        "shared_name" : "Axe Kick",
        "name" : "Axe Kick",
        "SUID" : 3331,
        "selected" : false
      },
      "position" : {
        "x" : -147.42272955577425,
        "y" : 933.1834517283443
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3327",
        "shared_name" : "Armor Cannon",
        "name" : "Armor Cannon",
        "SUID" : 3327,
        "selected" : false
      },
      "position" : {
        "x" : -202.19778448741488,
        "y" : 944.1969538195136
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3323",
        "shared_name" : "Aqua Step",
        "name" : "Aqua Step",
        "SUID" : 3323,
        "selected" : false
      },
      "position" : {
        "x" : -126.4843140284305,
        "y" : 803.455233649731
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3319",
        "shared_name" : "Aqua Cutter",
        "name" : "Aqua Cutter",
        "SUID" : 3319,
        "selected" : false
      },
      "position" : {
        "x" : -34.282119814563316,
        "y" : 1029.6189070506098
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3315",
        "shared_name" : "Alluring Voice",
        "name" : "Alluring Voice",
        "SUID" : 3315,
        "selected" : false
      },
      "position" : {
        "x" : -62.590576235461754,
        "y" : 852.559351996899
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3313",
        "shared_name" : "gen9",
        "name" : "gen9",
        "SUID" : 3313,
        "selected" : false
      },
      "position" : {
        "x" : -29.920303408313316,
        "y" : 789.6088896555904
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3309",
        "shared_name" : "Wildbolt Storm",
        "name" : "Wildbolt Storm",
        "SUID" : 3309,
        "selected" : false
      },
      "position" : {
        "x" : 160.99303811390348,
        "y" : -309.7325493531224
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3305",
        "shared_name" : "Wicked Blow",
        "name" : "Wicked Blow",
        "SUID" : 3305,
        "selected" : false
      },
      "position" : {
        "x" : -22.406467501330894,
        "y" : -336.9367424683568
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3301",
        "shared_name" : "Wave Crash",
        "name" : "Wave Crash",
        "SUID" : 3301,
        "selected" : false
      },
      "position" : {
        "x" : 309.70464700062223,
        "y" : -400.6346184449193
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3297",
        "shared_name" : "Victory Dance",
        "name" : "Victory Dance",
        "SUID" : 3297,
        "selected" : false
      },
      "position" : {
        "x" : 146.6671408971066,
        "y" : -688.0371758179662
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3293",
        "shared_name" : "Triple Axel",
        "name" : "Triple Axel",
        "SUID" : 3293,
        "selected" : false
      },
      "position" : {
        "x" : 116.79095071155973,
        "y" : -290.98688284921616
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3289",
        "shared_name" : "Triple Arrows",
        "name" : "Triple Arrows",
        "SUID" : 3289,
        "selected" : false
      },
      "position" : {
        "x" : 84.5571555455441,
        "y" : -241.75336234140366
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3285",
        "shared_name" : "Thunderous Kick",
        "name" : "Thunderous Kick",
        "SUID" : 3285,
        "selected" : false
      },
      "position" : {
        "x" : -143.22769552867464,
        "y" : -568.0193535523412
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3281",
        "shared_name" : "Thunder Cage",
        "name" : "Thunder Cage",
        "SUID" : 3281,
        "selected" : false
      },
      "position" : {
        "x" : 238.16149514515348,
        "y" : -251.0825249390599
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3277",
        "shared_name" : "Terrain Pulse",
        "name" : "Terrain Pulse",
        "SUID" : 3277,
        "selected" : false
      },
      "position" : {
        "x" : 66.5896262486691,
        "y" : -291.96979300546616
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3273",
        "shared_name" : "Teatime",
        "name" : "Teatime",
        "SUID" : 3273,
        "selected" : false
      },
      "position" : {
        "x" : 367.10523598988004,
        "y" : -392.09930960702866
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3269",
        "shared_name" : "Tar Shot",
        "name" : "Tar Shot",
        "SUID" : 3269,
        "selected" : false
      },
      "position" : {
        "x" : -108.7166481653934,
        "y" : -528.2979180054662
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3265",
        "shared_name" : "Take Heart",
        "name" : "Take Heart",
        "SUID" : 3265,
        "selected" : false
      },
      "position" : {
        "x" : 389.5928000767941,
        "y" : -477.5356499390599
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3261",
        "shared_name" : "Surging Strikes",
        "name" : "Surging Strikes",
        "SUID" : 3261,
        "selected" : false
      },
      "position" : {
        "x" : 103.34099953968473,
        "y" : -538.3126885132787
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3257",
        "shared_name" : "Stuff Cheeks",
        "name" : "Stuff Cheeks",
        "SUID" : 3257,
        "selected" : false
      },
      "position" : {
        "x" : 297.9262961705441,
        "y" : -261.50079886484116
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3253",
        "shared_name" : "Strange Steam",
        "name" : "Strange Steam",
        "SUID" : 3253,
        "selected" : false
      },
      "position" : {
        "x" : -19.417759005237144,
        "y" : -511.6676079468724
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3249",
        "shared_name" : "Stone Axe",
        "name" : "Stone Axe",
        "SUID" : 3249,
        "selected" : false
      },
      "position" : {
        "x" : 127.23522561390348,
        "y" : -341.1254936890599
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3245",
        "shared_name" : "Steel Roller",
        "name" : "Steel Roller",
        "SUID" : 3245,
        "selected" : false
      },
      "position" : {
        "x" : 349.30123513538786,
        "y" : -626.9467522339818
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3241",
        "shared_name" : "Steel Beam",
        "name" : "Steel Beam",
        "SUID" : 3241,
        "selected" : false
      },
      "position" : {
        "x" : 336.58285134632536,
        "y" : -709.3275200562474
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3237",
        "shared_name" : "Springtide Storm",
        "name" : "Springtide Storm",
        "SUID" : 3237,
        "selected" : false
      },
      "position" : {
        "x" : 323.34652322132536,
        "y" : -666.9736229615208
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3233",
        "shared_name" : "Spirit Break",
        "name" : "Spirit Break",
        "SUID" : 3233,
        "selected" : false
      },
      "position" : {
        "x" : -52.275974337268394,
        "y" : -673.864522619724
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3229",
        "shared_name" : "Snipe Shot",
        "name" : "Snipe Shot",
        "SUID" : 3229,
        "selected" : false
      },
      "position" : {
        "x" : 56.959438260387856,
        "y" : -553.7775932984349
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3225",
        "shared_name" : "Snap Trap",
        "name" : "Snap Trap",
        "SUID" : 3225,
        "selected" : false
      },
      "position" : {
        "x" : 205.49767678577848,
        "y" : -806.7928692536351
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3221",
        "shared_name" : "Skitter Smack",
        "name" : "Skitter Smack",
        "SUID" : 3221,
        "selected" : false
      },
      "position" : {
        "x" : 23.496059354137856,
        "y" : -630.2597405152318
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3217",
        "shared_name" : "Shelter",
        "name" : "Shelter",
        "SUID" : 3217,
        "selected" : false
      },
      "position" : {
        "x" : 345.6683310826535,
        "y" : -344.2325188355443
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3213",
        "shared_name" : "Shell Side Arm",
        "name" : "Shell Side Arm",
        "SUID" : 3213,
        "selected" : false
      },
      "position" : {
        "x" : 172.4659690221066,
        "y" : -353.33051077890366
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3209",
        "shared_name" : "Scorching Sands",
        "name" : "Scorching Sands",
        "SUID" : 3209,
        "selected" : false
      },
      "position" : {
        "x" : 413.01974099476286,
        "y" : -531.6583611207005
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3205",
        "shared_name" : "Scale Shot",
        "name" : "Scale Shot",
        "SUID" : 3205,
        "selected" : false
      },
      "position" : {
        "x" : 306.5731162389035,
        "y" : -794.7871529297826
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3201",
        "shared_name" : "Sandsear Storm",
        "name" : "Sandsear Storm",
        "SUID" : 3201,
        "selected" : false
      },
      "position" : {
        "x" : -77.49026877086214,
        "y" : -337.4168755249974
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3197",
        "shared_name" : "Rising Voltage",
        "name" : "Rising Voltage",
        "SUID" : 3197,
        "selected" : false
      },
      "position" : {
        "x" : 345.1922873814816,
        "y" : -761.1722161011693
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3193",
        "shared_name" : "Raging Fury",
        "name" : "Raging Fury",
        "SUID" : 3193,
        "selected" : false
      },
      "position" : {
        "x" : -43.659275118518394,
        "y" : -384.0096184449193
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3189",
        "shared_name" : "Pyro Ball",
        "name" : "Pyro Ball",
        "SUID" : 3189,
        "selected" : false
      },
      "position" : {
        "x" : -65.0135231653934,
        "y" : -529.3205620484349
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3185",
        "shared_name" : "Psyshield Bash",
        "name" : "Psyshield Bash",
        "SUID" : 3185,
        "selected" : false
      },
      "position" : {
        "x" : 24.645778592419106,
        "y" : -260.74884573984116
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3181",
        "shared_name" : "Power Shift",
        "name" : "Power Shift",
        "SUID" : 3181,
        "selected" : false
      },
      "position" : {
        "x" : 370.6728324254269,
        "y" : -523.6565605835912
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3177",
        "shared_name" : "Poltergeist",
        "name" : "Poltergeist",
        "SUID" : 3177,
        "selected" : false
      },
      "position" : {
        "x" : 245.41512673695036,
        "y" : -721.0686012940404
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3173",
        "shared_name" : "Overdrive",
        "name" : "Overdrive",
        "SUID" : 3173,
        "selected" : false
      },
      "position" : {
        "x" : 1.5543479283566057,
        "y" : -731.840238256931
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3169",
        "shared_name" : "Octolock",
        "name" : "Octolock",
        "SUID" : 3169,
        "selected" : false
      },
      "position" : {
        "x" : 78.7635764439816,
        "y" : -590.4440819458958
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3165",
        "shared_name" : "Obstruct",
        "name" : "Obstruct",
        "SUID" : 3165,
        "selected" : false
      },
      "position" : {
        "x" : 253.35967629749723,
        "y" : -774.0658318238255
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3161",
        "shared_name" : "No Retreat",
        "name" : "No Retreat",
        "SUID" : 3161,
        "selected" : false
      },
      "position" : {
        "x" : 73.36178201038786,
        "y" : -623.6700188355443
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3157",
        "shared_name" : "Mystical Power",
        "name" : "Mystical Power",
        "SUID" : 3157,
        "selected" : false
      },
      "position" : {
        "x" : 464.5159415562863,
        "y" : -526.2738396363255
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3153",
        "shared_name" : "Mountain Gale",
        "name" : "Mountain Gale",
        "SUID" : 3153,
        "selected" : false
      },
      "position" : {
        "x" : 65.83797829945036,
        "y" : -422.4381157593724
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3149",
        "shared_name" : "Misty Explosion",
        "name" : "Misty Explosion",
        "SUID" : 3149,
        "selected" : false
      },
      "position" : {
        "x" : 363.4002189000363,
        "y" : -575.2246758179662
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3145",
        "shared_name" : "Meteor Beam",
        "name" : "Meteor Beam",
        "SUID" : 3145,
        "selected" : false
      },
      "position" : {
        "x" : 146.50243752796598,
        "y" : -394.5868889527318
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3141",
        "shared_name" : "Meteor Assault",
        "name" : "Meteor Assault",
        "SUID" : 3141,
        "selected" : false
      },
      "position" : {
        "x" : 164.28365701038786,
        "y" : -779.3602883057591
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3137",
        "shared_name" : "Max Wyrmwind",
        "name" : "Max Wyrmwind",
        "SUID" : 3137,
        "selected" : false
      },
      "position" : {
        "x" : 243.8696555455441,
        "y" : -389.38675467538803
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3133",
        "shared_name" : "Max Strike",
        "name" : "Max Strike",
        "SUID" : 3133,
        "selected" : false
      },
      "position" : {
        "x" : 256.9532431920285,
        "y" : -295.2766167359349
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3129",
        "shared_name" : "Max Steelspike",
        "name" : "Max Steelspike",
        "SUID" : 3129,
        "selected" : false
      },
      "position" : {
        "x" : 449.763912137341,
        "y" : -627.4989067749974
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3125",
        "shared_name" : "Max Starfall",
        "name" : "Max Starfall",
        "SUID" : 3125,
        "selected" : false
      },
      "position" : {
        "x" : -100.5734596888309,
        "y" : -387.8215386109349
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3121",
        "shared_name" : "Max Rockfall",
        "name" : "Max Rockfall",
        "SUID" : 3121,
        "selected" : false
      },
      "position" : {
        "x" : 288.92123025257536,
        "y" : -698.7330528931615
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3117",
        "shared_name" : "Max Quake",
        "name" : "Max Quake",
        "SUID" : 3117,
        "selected" : false
      },
      "position" : {
        "x" : 123.59115212757536,
        "y" : -737.2069756226537
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3113",
        "shared_name" : "Max Phantasm",
        "name" : "Max Phantasm",
        "SUID" : 3113,
        "selected" : false
      },
      "position" : {
        "x" : 113.94109719593473,
        "y" : -476.71637503671616
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3109",
        "shared_name" : "Max Overgrowth",
        "name" : "Max Overgrowth",
        "SUID" : 3109,
        "selected" : false
      },
      "position" : {
        "x" : -20.630344454455894,
        "y" : -429.80057303476303
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3105",
        "shared_name" : "Max Ooze",
        "name" : "Max Ooze",
        "SUID" : 3105,
        "selected" : false
      },
      "position" : {
        "x" : 167.19164651234098,
        "y" : -727.1279350953099
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3101",
        "shared_name" : "Max Mindstorm",
        "name" : "Max Mindstorm",
        "SUID" : 3101,
        "selected" : false
      },
      "position" : {
        "x" : 26.325832303356606,
        "y" : -780.9635903077123
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3097",
        "shared_name" : "Max Lightning",
        "name" : "Max Lightning",
        "SUID" : 3097,
        "selected" : false
      },
      "position" : {
        "x" : 136.6378440221066,
        "y" : -242.6154839234349
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3093",
        "shared_name" : "Max Knuckle",
        "name" : "Max Knuckle",
        "SUID" : 3093,
        "selected" : false
      },
      "position" : {
        "x" : 394.70219033558317,
        "y" : -341.80228201913803
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3089",
        "shared_name" : "Max Hailstorm",
        "name" : "Max Hailstorm",
        "SUID" : 3089,
        "selected" : false
      },
      "position" : {
        "x" : 451.45504372913786,
        "y" : -574.9744927124974
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3085",
        "shared_name" : "Max Guard",
        "name" : "Max Guard",
        "SUID" : 3085,
        "selected" : false
      },
      "position" : {
        "x" : 103.00667947132536,
        "y" : -381.0935112671849
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3081",
        "shared_name" : "Max Geyser",
        "name" : "Max Geyser",
        "SUID" : 3081,
        "selected" : false
      },
      "position" : {
        "x" : 373.2208213170285,
        "y" : -678.2350212769505
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3077",
        "shared_name" : "Max Flutterby",
        "name" : "Max Flutterby",
        "SUID" : 3077,
        "selected" : false
      },
      "position" : {
        "x" : 340.00493996937223,
        "y" : -483.5931450562474
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3073",
        "shared_name" : "Max Flare",
        "name" : "Max Flare",
        "SUID" : 3073,
        "selected" : false
      },
      "position" : {
        "x" : 210.51522439320036,
        "y" : -302.89996878671616
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3069",
        "shared_name" : "Max Darkness",
        "name" : "Max Darkness",
        "SUID" : 3069,
        "selected" : false
      },
      "position" : {
        "x" : 421.8026389439816,
        "y" : -388.6892143921849
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3065",
        "shared_name" : "Max Airstream",
        "name" : "Max Airstream",
        "SUID" : 3065,
        "selected" : false
      },
      "position" : {
        "x" : 64.95650857288786,
        "y" : -805.4902760224339
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3061",
        "shared_name" : "Magic Powder",
        "name" : "Magic Powder",
        "SUID" : 3061,
        "selected" : false
      },
      "position" : {
        "x" : 285.1438254674191,
        "y" : -646.717549963474
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3057",
        "shared_name" : "Lunar Blessing",
        "name" : "Lunar Blessing",
        "SUID" : 3057,
        "selected" : false
      },
      "position" : {
        "x" : 219.25139993030973,
        "y" : -438.67972342538803
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3053",
        "shared_name" : "Life Dew",
        "name" : "Life Dew",
        "SUID" : 3053,
        "selected" : false
      },
      "position" : {
        "x" : -22.080600802112144,
        "y" : -286.2503716187474
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3049",
        "shared_name" : "Lash Out",
        "name" : "Lash Out",
        "SUID" : 3049,
        "selected" : false
      },
      "position" : {
        "x" : 192.96029275257536,
        "y" : -400.7773186402318
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3045",
        "shared_name" : "Jungle Healing",
        "name" : "Jungle Healing",
        "SUID" : 3045,
        "selected" : false
      },
      "position" : {
        "x" : 214.4162864049191,
        "y" : -755.4569985108373
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3041",
        "shared_name" : "Jaw Lock",
        "name" : "Jaw Lock",
        "SUID" : 3041,
        "selected" : false
      },
      "position" : {
        "x" : -15.317844454455894,
        "y" : -554.7956597046849
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3037",
        "shared_name" : "Infernal Parade",
        "name" : "Infernal Parade",
        "SUID" : 3037,
        "selected" : false
      },
      "position" : {
        "x" : 344.3725852330441,
        "y" : -436.6228996949193
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3033",
        "shared_name" : "Headlong Rush",
        "name" : "Headlong Rush",
        "SUID" : 3033,
        "selected" : false
      },
      "position" : {
        "x" : -124.98367697398714,
        "y" : -435.01981131601303
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3029",
        "shared_name" : "Grav Apple",
        "name" : "Grav Apple",
        "SUID" : 3029,
        "selected" : false
      },
      "position" : {
        "x" : 55.021266873669106,
        "y" : -510.83832327890366
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3025",
        "shared_name" : "Grassy Glide",
        "name" : "Grassy Glide",
        "SUID" : 3025,
        "selected" : false
      },
      "position" : {
        "x" : -107.6609841028934,
        "y" : -667.8385063843724
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3021",
        "shared_name" : "Glacial Lance",
        "name" : "Glacial Lance",
        "SUID" : 3021,
        "selected" : false
      },
      "position" : {
        "x" : -21.578220431018394,
        "y" : -779.5824295716283
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3017",
        "shared_name" : "G-Max Wind Rage",
        "name" : "G-Max Wind Rage",
        "SUID" : 3017,
        "selected" : false
      },
      "position" : {
        "x" : 449.0187796910519,
        "y" : -439.67020194101303
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3013",
        "shared_name" : "G-Max Wildfire",
        "name" : "G-Max Wildfire",
        "SUID" : 3013,
        "selected" : false
      },
      "position" : {
        "x" : -75.30936056773714,
        "y" : -632.2084252076146
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3009",
        "shared_name" : "G-Max Volt Crash",
        "name" : "G-Max Volt Crash",
        "SUID" : 3009,
        "selected" : false
      },
      "position" : {
        "x" : 396.07581704456754,
        "y" : -432.40533988046616
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3005",
        "shared_name" : "G-Max Volcalith",
        "name" : "G-Max Volcalith",
        "SUID" : 3005,
        "selected" : false
      },
      "position" : {
        "x" : 268.4264182408566,
        "y" : -526.4386040406224
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3001",
        "shared_name" : "G-Max Vine Lash",
        "name" : "G-Max Vine Lash",
        "SUID" : 3001,
        "selected" : false
      },
      "position" : {
        "x" : -147.85074240367464,
        "y" : -496.7030083374974
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2997",
        "shared_name" : "G-Max Terror",
        "name" : "G-Max Terror",
        "SUID" : 2997,
        "selected" : false
      },
      "position" : {
        "x" : 187.34920876820036,
        "y" : -655.3390251832005
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2993",
        "shared_name" : "G-Max Tartness",
        "name" : "G-Max Tartness",
        "SUID" : 2993,
        "selected" : false
      },
      "position" : {
        "x" : 321.35616677601286,
        "y" : -527.3498589234349
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2989",
        "shared_name" : "G-Max Sweetness",
        "name" : "G-Max Sweetness",
        "SUID" : 2989,
        "selected" : false
      },
      "position" : {
        "x" : -97.08890158336214,
        "y" : -475.5766350464818
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2985",
        "shared_name" : "G-Max Stun Shock",
        "name" : "G-Max Stun Shock",
        "SUID" : 2985,
        "selected" : false
      },
      "position" : {
        "x" : 264.90999978382536,
        "y" : -343.55899588632553
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2981",
        "shared_name" : "G-Max Stonesurge",
        "name" : "G-Max Stonesurge",
        "SUID" : 2981,
        "selected" : false
      },
      "position" : {
        "x" : 80.9764670689816,
        "y" : -335.03534476327866
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2977",
        "shared_name" : "G-Max Steelsurge",
        "name" : "G-Max Steelsurge",
        "SUID" : 2977,
        "selected" : false
      },
      "position" : {
        "x" : 25.066249783825356,
        "y" : -582.7345482544896
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2973",
        "shared_name" : "G-Max Snooze",
        "name" : "G-Max Snooze",
        "SUID" : 2973,
        "selected" : false
      },
      "position" : {
        "x" : 225.95479958851286,
        "y" : -638.0320793824193
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2969",
        "shared_name" : "G-Max Smite",
        "name" : "G-Max Smite",
        "SUID" : 2969,
        "selected" : false
      },
      "position" : {
        "x" : 17.957546170544106,
        "y" : -685.4398857789037
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2965",
        "shared_name" : "G-Max Sandblast",
        "name" : "G-Max Sandblast",
        "SUID" : 2965,
        "selected" : false
      },
      "position" : {
        "x" : 56.542446072887856,
        "y" : -673.145528479099
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2961",
        "shared_name" : "G-Max Resonance",
        "name" : "G-Max Resonance",
        "SUID" : 2961,
        "selected" : false
      },
      "position" : {
        "x" : 200.39196389515348,
        "y" : -481.66742484140366
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2957",
        "shared_name" : "G-Max Replenish",
        "name" : "G-Max Replenish",
        "SUID" : 2957,
        "selected" : false
      },
      "position" : {
        "x" : 244.1068381627316,
        "y" : -594.4254967408177
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2953",
        "shared_name" : "G-Max Rapid Flow",
        "name" : "G-Max Rapid Flow",
        "SUID" : 2953,
        "selected" : false
      },
      "position" : {
        "x" : 155.9558371861691,
        "y" : -625.6012322144505
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2949",
        "shared_name" : "G-Max One Blow",
        "name" : "G-Max One Blow",
        "SUID" : 2949,
        "selected" : false
      },
      "position" : {
        "x" : 264.12115090687223,
        "y" : -429.2619682984349
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2945",
        "shared_name" : "G-Max Meltdown",
        "name" : "G-Max Meltdown",
        "SUID" : 2945,
        "selected" : false
      },
      "position" : {
        "x" : 349.7239951451535,
        "y" : -294.33612601327866
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2941",
        "shared_name" : "G-Max Malodor",
        "name" : "G-Max Malodor",
        "SUID" : 2941,
        "selected" : false
      },
      "position" : {
        "x" : -50.850315157580894,
        "y" : -472.27835623788803
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2937",
        "shared_name" : "G-Max Hydrosnipe",
        "name" : "G-Max Hydrosnipe",
        "SUID" : 2937,
        "selected" : false
      },
      "position" : {
        "x" : 124.84551614124723,
        "y" : -597.3316246705052
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2933",
        "shared_name" : "G-Max Gravitas",
        "name" : "G-Max Gravitas",
        "SUID" : 2933,
        "selected" : false
      },
      "position" : {
        "x" : 300.0338095982785,
        "y" : -364.94058768320053
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2929",
        "shared_name" : "G-Max Gold Rush",
        "name" : "G-Max Gold Rush",
        "SUID" : 2929,
        "selected" : false
      },
      "position" : {
        "x" : 19.298000272106606,
        "y" : -529.7728630738255
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2925",
        "shared_name" : "G-Max Foam Burst",
        "name" : "G-Max Foam Burst",
        "SUID" : 2925,
        "selected" : false
      },
      "position" : {
        "x" : 2.0246848424191057,
        "y" : -477.73492972421616
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2921",
        "shared_name" : "G-Max Fireball",
        "name" : "G-Max Fireball",
        "SUID" : 2921,
        "selected" : false
      },
      "position" : {
        "x" : 57.678371365856606,
        "y" : -380.83893363046616
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2917",
        "shared_name" : "G-Max Finale",
        "name" : "G-Max Finale",
        "SUID" : 2917,
        "selected" : false
      },
      "position" : {
        "x" : 178.0655783971066,
        "y" : -268.4179741578099
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2913",
        "shared_name" : "G-Max Drum Solo",
        "name" : "G-Max Drum Solo",
        "SUID" : 2913,
        "selected" : false
      },
      "position" : {
        "x" : 255.1412619908566,
        "y" : -826.6979929642674
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2909",
        "shared_name" : "G-Max Depletion",
        "name" : "G-Max Depletion",
        "SUID" : 2909,
        "selected" : false
      },
      "position" : {
        "x" : 157.72307961780973,
        "y" : -827.2257534699437
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2905",
        "shared_name" : "G-Max Cuddle",
        "name" : "G-Max Cuddle",
        "SUID" : 2905,
        "selected" : false
      },
      "position" : {
        "x" : 95.33822244007536,
        "y" : -693.173131628513
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2901",
        "shared_name" : "G-Max Chi Strike",
        "name" : "G-Max Chi Strike",
        "SUID" : 2901,
        "selected" : false
      },
      "position" : {
        "x" : 400.19971841175504,
        "y" : -583.5980583863255
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2897",
        "shared_name" : "G-Max Centiferno",
        "name" : "G-Max Centiferno",
        "SUID" : 2897,
        "selected" : false
      },
      "position" : {
        "x" : 397.39161294300504,
        "y" : -631.872594519138
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2893",
        "shared_name" : "G-Max Cannonade",
        "name" : "G-Max Cannonade",
        "SUID" : 2893,
        "selected" : false
      },
      "position" : {
        "x" : 113.39355080921598,
        "y" : -649.7408653931615
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2889",
        "shared_name" : "G-Max Befuddle",
        "name" : "G-Max Befuddle",
        "SUID" : 2889,
        "selected" : false
      },
      "position" : {
        "x" : 52.801357205700356,
        "y" : -722.272969885349
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2885",
        "shared_name" : "Freezing Glare",
        "name" : "Freezing Glare",
        "SUID" : 2885,
        "selected" : false
      },
      "position" : {
        "x" : 224.97900002796598,
        "y" : -545.2643486695287
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2881",
        "shared_name" : "Flip Turn",
        "name" : "Flip Turn",
        "SUID" : 2881,
        "selected" : false
      },
      "position" : {
        "x" : 83.1175803502316,
        "y" : -743.8255211548802
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2877",
        "shared_name" : "Fishious Rend",
        "name" : "Fishious Rend",
        "SUID" : 2877,
        "selected" : false
      },
      "position" : {
        "x" : -81.8047829310184,
        "y" : -709.4032799439427
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2873",
        "shared_name" : "Fiery Wrath",
        "name" : "Fiery Wrath",
        "SUID" : 2873,
        "selected" : false
      },
      "position" : {
        "x" : -131.4931374232059,
        "y" : -617.8636833863255
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2869",
        "shared_name" : "False Surrender",
        "name" : "False Surrender",
        "SUID" : 2869,
        "selected" : false
      },
      "position" : {
        "x" : 424.99139016468473,
        "y" : -681.4777428345677
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2865",
        "shared_name" : "Expanding Force",
        "name" : "Expanding Force",
        "SUID" : 2865,
        "selected" : false
      },
      "position" : {
        "x" : 21.968227322887856,
        "y" : -441.5678459839818
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2861",
        "shared_name" : "Eternabeam",
        "name" : "Eternabeam",
        "SUID" : 2861,
        "selected" : false
      },
      "position" : {
        "x" : 104.31237405140348,
        "y" : -837.6981286244389
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2857",
        "shared_name" : "Esper Wing",
        "name" : "Esper Wing",
        "SUID" : 2857,
        "selected" : false
      },
      "position" : {
        "x" : -85.96036154429964,
        "y" : -583.7724663453099
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2853",
        "shared_name" : "Eerie Spell",
        "name" : "Eerie Spell",
        "SUID" : 2853,
        "selected" : false
      },
      "position" : {
        "x" : -69.5142555872684,
        "y" : -428.2647759156224
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2849",
        "shared_name" : "Dynamax Cannon",
        "name" : "Dynamax Cannon",
        "SUID" : 2849,
        "selected" : false
      },
      "position" : {
        "x" : -42.880588595080894,
        "y" : -730.420560522556
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2845",
        "shared_name" : "Dual Wingbeat",
        "name" : "Dual Wingbeat",
        "SUID" : 2845,
        "selected" : false
      },
      "position" : {
        "x" : 117.50341409046598,
        "y" : -786.8237244324681
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2841",
        "shared_name" : "Drum Beating",
        "name" : "Drum Beating",
        "SUID" : 2841,
        "selected" : false
      },
      "position" : {
        "x" : 24.842067654919106,
        "y" : -357.3286186890599
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2837",
        "shared_name" : "Dragon Energy",
        "name" : "Dragon Energy",
        "SUID" : 2837,
        "selected" : false
      },
      "position" : {
        "x" : 204.66399758655973,
        "y" : -699.0099999146458
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2833",
        "shared_name" : "Dragon Darts",
        "name" : "Dragon Darts",
        "SUID" : 2833,
        "selected" : false
      },
      "position" : {
        "x" : 214.64214700062223,
        "y" : -354.8844048218724
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2829",
        "shared_name" : "Dire Claw",
        "name" : "Dire Claw",
        "SUID" : 2829,
        "selected" : false
      },
      "position" : {
        "x" : 302.56914895374723,
        "y" : -442.1587883667943
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2825",
        "shared_name" : "Decorate",
        "name" : "Decorate",
        "SUID" : 2825,
        "selected" : false
      },
      "position" : {
        "x" : -15.370212618518394,
        "y" : -657.5697075562474
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2821",
        "shared_name" : "Court Change",
        "name" : "Court Change",
        "SUID" : 2821,
        "selected" : false
      },
      "position" : {
        "x" : 296.75680154163786,
        "y" : -613.4103447632787
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2817",
        "shared_name" : "Corrosive Gas",
        "name" : "Corrosive Gas",
        "SUID" : 2817,
        "selected" : false
      },
      "position" : {
        "x" : -20.332004610705894,
        "y" : -612.9997154908177
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2813",
        "shared_name" : "Coaching",
        "name" : "Coaching",
        "SUID" : 2813,
        "selected" : false
      },
      "position" : {
        "x" : 295.67205422718473,
        "y" : -488.5789848999974
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2809",
        "shared_name" : "Clangorous Soul",
        "name" : "Clangorous Soul",
        "SUID" : 2809,
        "selected" : false
      },
      "position" : {
        "x" : 290.8546103795285,
        "y" : -746.9662453370091
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2805",
        "shared_name" : "Chloroblast",
        "name" : "Chloroblast",
        "SUID" : 2805,
        "selected" : false
      },
      "position" : {
        "x" : 8.311000760387856,
        "y" : -394.30866019296616
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2801",
        "shared_name" : "Ceaseless Edge",
        "name" : "Ceaseless Edge",
        "SUID" : 2801,
        "selected" : false
      },
      "position" : {
        "x" : -46.864597384143394,
        "y" : -582.3822228150365
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2797",
        "shared_name" : "Burning Jealousy",
        "name" : "Burning Jealousy",
        "SUID" : 2797,
        "selected" : false
      },
      "position" : {
        "x" : 247.04769509632536,
        "y" : -672.1418053345677
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2793",
        "shared_name" : "Breaking Swipe",
        "name" : "Breaking Swipe",
        "SUID" : 2793,
        "selected" : false
      },
      "position" : {
        "x" : 302.14193337757536,
        "y" : -319.45050589609116
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2789",
        "shared_name" : "Branch Poke",
        "name" : "Branch Poke",
        "SUID" : 2789,
        "selected" : false
      },
      "position" : {
        "x" : 115.77087014515348,
        "y" : -433.0461479859349
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2785",
        "shared_name" : "Bolt Beak",
        "name" : "Bolt Beak",
        "SUID" : 2785,
        "selected" : false
      },
      "position" : {
        "x" : 65.90963357288786,
        "y" : -467.2332512574193
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2781",
        "shared_name" : "Body Press",
        "name" : "Body Press",
        "SUID" : 2781,
        "selected" : false
      },
      "position" : {
        "x" : 191.16329568226286,
        "y" : -595.2018486695287
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2777",
        "shared_name" : "Bleakwind Storm",
        "name" : "Bleakwind Storm",
        "SUID" : 2777,
        "selected" : false
      },
      "position" : {
        "x" : 194.33761208851286,
        "y" : -225.2391411499974
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2773",
        "shared_name" : "Bitter Malice",
        "name" : "Bitter Malice",
        "SUID" : 2773,
        "selected" : false
      },
      "position" : {
        "x" : 320.7954367955441,
        "y" : -571.9999443726537
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2769",
        "shared_name" : "Behemoth Blade",
        "name" : "Behemoth Blade",
        "SUID" : 2769,
        "selected" : false
      },
      "position" : {
        "x" : 389.36385720570036,
        "y" : -727.8509499268529
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2765",
        "shared_name" : "Behemoth Bash",
        "name" : "Behemoth Bash",
        "SUID" : 2765,
        "selected" : false
      },
      "position" : {
        "x" : 250.56490701038786,
        "y" : -480.8775688843724
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2761",
        "shared_name" : "Barb Barrage",
        "name" : "Barb Barrage",
        "SUID" : 2761,
        "selected" : false
      },
      "position" : {
        "x" : 26.929836209606606,
        "y" : -318.68561331796616
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2757",
        "shared_name" : "Aura Wheel",
        "name" : "Aura Wheel",
        "SUID" : 2757,
        "selected" : false
      },
      "position" : {
        "x" : 162.79394143421598,
        "y" : -439.76505057382553
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2753",
        "shared_name" : "Astral Barrage",
        "name" : "Astral Barrage",
        "SUID" : 2753,
        "selected" : false
      },
      "position" : {
        "x" : 279.18612283070036,
        "y" : -564.8768669800755
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2749",
        "shared_name" : "Apple Acid",
        "name" : "Apple Acid",
        "SUID" : 2749,
        "selected" : false
      },
      "position" : {
        "x" : 435.9805716832394,
        "y" : -486.6530815796849
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2747",
        "shared_name" : "gen8",
        "name" : "gen8",
        "SUID" : 2747,
        "selected" : false
      },
      "position" : {
        "x" : 158.56145852405973,
        "y" : -535.6030327515599
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2743",
        "shared_name" : "Zen Headbutt",
        "name" : "Zen Headbutt",
        "SUID" : 2743,
        "selected" : false
      },
      "position" : {
        "x" : 976.5444068272824,
        "y" : -301.14791194963425
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2739",
        "shared_name" : "X-Scissor",
        "name" : "X-Scissor",
        "SUID" : 2739,
        "selected" : false
      },
      "position" : {
        "x" : 941.8604010899777,
        "y" : -760.3546990590092
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2735",
        "shared_name" : "Wring Out",
        "name" : "Wring Out",
        "SUID" : 2735,
        "selected" : false
      },
      "position" : {
        "x" : 843.1328162511105,
        "y" : -804.6356286244389
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2731",
        "shared_name" : "Worry Seed",
        "name" : "Worry Seed",
        "SUID" : 2731,
        "selected" : false
      },
      "position" : {
        "x" : 1056.931034024548,
        "y" : -663.9430016713139
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2727",
        "shared_name" : "Wood Hammer",
        "name" : "Wood Hammer",
        "SUID" : 2727,
        "selected" : false
      },
      "position" : {
        "x" : 1030.7140845616573,
        "y" : -766.5005730824467
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2723",
        "shared_name" : "Wake-Up Slap",
        "name" : "Wake-Up Slap",
        "SUID" : 2723,
        "selected" : false
      },
      "position" : {
        "x" : 713.4598731358761,
        "y" : -726.1981591420171
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2719",
        "shared_name" : "Vacuum Wave",
        "name" : "Vacuum Wave",
        "SUID" : 2719,
        "selected" : false
      },
      "position" : {
        "x" : 967.0427893956418,
        "y" : -678.3089684681889
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2715",
        "shared_name" : "U-turn",
        "name" : "U-turn",
        "SUID" : 2715,
        "selected" : false
      },
      "position" : {
        "x" : 1128.6060218175166,
        "y" : -530.3488597111699
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2711",
        "shared_name" : "Trump Card",
        "name" : "Trump Card",
        "SUID" : 2711,
        "selected" : false
      },
      "position" : {
        "x" : 628.361438687634,
        "y" : -712.8906335072514
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2707",
        "shared_name" : "Trick Room",
        "name" : "Trick Room",
        "SUID" : 2707,
        "selected" : false
      },
      "position" : {
        "x" : 838.0763739903683,
        "y" : -354.25711910295456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2703",
        "shared_name" : "Toxic Spikes",
        "name" : "Toxic Spikes",
        "SUID" : 2703,
        "selected" : false
      },
      "position" : {
        "x" : 803.4710501988644,
        "y" : -469.4430360035893
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2699",
        "shared_name" : "Thunder Fang",
        "name" : "Thunder Fang",
        "SUID" : 2699,
        "selected" : false
      },
      "position" : {
        "x" : 635.6827697118039,
        "y" : -369.1542290883061
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2695",
        "shared_name" : "Tailwind",
        "name" : "Tailwind",
        "SUID" : 2695,
        "selected" : false
      },
      "position" : {
        "x" : 883.3440589268918,
        "y" : -266.3326958851811
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2691",
        "shared_name" : "Switcheroo",
        "name" : "Switcheroo",
        "SUID" : 2691,
        "selected" : false
      },
      "position" : {
        "x" : 979.444950040173,
        "y" : -581.6411141591069
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2687",
        "shared_name" : "Sucker Punch",
        "name" : "Sucker Punch",
        "SUID" : 2687,
        "selected" : false
      },
      "position" : {
        "x" : 759.7694739659543,
        "y" : -378.04439632463425
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2683",
        "shared_name" : "Stone Edge",
        "name" : "Stone Edge",
        "SUID" : 2683,
        "selected" : false
      },
      "position" : {
        "x" : 1049.2481421788448,
        "y" : -524.7788418965337
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2679",
        "shared_name" : "Stealth Rock",
        "name" : "Stealth Rock",
        "SUID" : 2679,
        "selected" : false
      },
      "position" : {
        "x" : 979.7293128331418,
        "y" : -357.7552422718999
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2675",
        "shared_name" : "Spacial Rend",
        "name" : "Spacial Rend",
        "SUID" : 2675,
        "selected" : false
      },
      "position" : {
        "x" : 933.2590064366574,
        "y" : -575.6575669484135
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2671",
        "shared_name" : "Shadow Sneak",
        "name" : "Shadow Sneak",
        "SUID" : 2671,
        "selected" : false
      },
      "position" : {
        "x" : 784.05640786488,
        "y" : -671.7112969593999
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2667",
        "shared_name" : "Shadow Force",
        "name" : "Shadow Force",
        "SUID" : 2667,
        "selected" : false
      },
      "position" : {
        "x" : 671.2000083287472,
        "y" : -441.2625283436772
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2663",
        "shared_name" : "Shadow Claw",
        "name" : "Shadow Claw",
        "SUID" : 2663,
        "selected" : false
      },
      "position" : {
        "x" : 1114.7617835362666,
        "y" : -452.59291545915573
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2659",
        "shared_name" : "Seed Flare",
        "name" : "Seed Flare",
        "SUID" : 2659,
        "selected" : false
      },
      "position" : {
        "x" : 744.7627906163449,
        "y" : -764.6989373402592
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2655",
        "shared_name" : "Seed Bomb",
        "name" : "Seed Bomb",
        "SUID" : 2655,
        "selected" : false
      },
      "position" : {
        "x" : 805.6198462804074,
        "y" : -725.9377221302983
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2651",
        "shared_name" : "Roost",
        "name" : "Roost",
        "SUID" : 2651,
        "selected" : false
      },
      "position" : {
        "x" : 705.449193890881,
        "y" : -474.64423839616745
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2647",
        "shared_name" : "Rock Wrecker",
        "name" : "Rock Wrecker",
        "SUID" : 2647,
        "selected" : false
      },
      "position" : {
        "x" : 909.333606656384,
        "y" : -683.557030601978
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2643",
        "shared_name" : "Rock Polish",
        "name" : "Rock Polish",
        "SUID" : 2643,
        "selected" : false
      },
      "position" : {
        "x" : 628.065181668591,
        "y" : -468.9730691151616
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2639",
        "shared_name" : "Rock Climb",
        "name" : "Rock Climb",
        "SUID" : 2639,
        "selected" : false
      },
      "position" : {
        "x" : 687.8211426099057,
        "y" : -558.9924668507573
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2635",
        "shared_name" : "Roar of Time",
        "name" : "Roar of Time",
        "SUID" : 2635,
        "selected" : false
      },
      "position" : {
        "x" : 580.406864102673,
        "y" : -453.74886409807175
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2631",
        "shared_name" : "Punishment",
        "name" : "Punishment",
        "SUID" : 2631,
        "selected" : false
      },
      "position" : {
        "x" : 985.6718787511105,
        "y" : -534.4925355153081
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2627",
        "shared_name" : "Psycho Shift",
        "name" : "Psycho Shift",
        "SUID" : 2627,
        "selected" : false
      },
      "position" : {
        "x" : 763.0533103307004,
        "y" : -718.2076806263921
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2623",
        "shared_name" : "Psycho Cut",
        "name" : "Psycho Cut",
        "SUID" : 2623,
        "selected" : false
      },
      "position" : {
        "x" : 752.9545783360714,
        "y" : -455.1184739308354
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2619",
        "shared_name" : "Power Whip",
        "name" : "Power Whip",
        "SUID" : 2619,
        "selected" : false
      },
      "position" : {
        "x" : 957.4059485753293,
        "y" : -491.7962483601567
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2615",
        "shared_name" : "Power Trick",
        "name" : "Power Trick",
        "SUID" : 2615,
        "selected" : false
      },
      "position" : {
        "x" : 821.8008612950558,
        "y" : -623.4183282093999
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2611",
        "shared_name" : "Power Swap",
        "name" : "Power Swap",
        "SUID" : 2611,
        "selected" : false
      },
      "position" : {
        "x" : 926.5394934972043,
        "y" : -400.2249764637944
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2607",
        "shared_name" : "Power Gem",
        "name" : "Power Gem",
        "SUID" : 2607,
        "selected" : false
      },
      "position" : {
        "x" : 977.7403296788449,
        "y" : -629.7065667347905
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2603",
        "shared_name" : "Poison Jab",
        "name" : "Poison Jab",
        "SUID" : 2603,
        "selected" : false
      },
      "position" : {
        "x" : 596.7074164708371,
        "y" : -670.7203301625249
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2599",
        "shared_name" : "Pluck",
        "name" : "Pluck",
        "SUID" : 2599,
        "selected" : false
      },
      "position" : {
        "x" : 922.719852383923,
        "y" : -305.22103206682175
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2595",
        "shared_name" : "Payback",
        "name" : "Payback",
        "SUID" : 2595,
        "selected" : false
      },
      "position" : {
        "x" : 1049.4430884679073,
        "y" : -473.30883495378464
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2591",
        "shared_name" : "Ominous Wind",
        "name" : "Ominous Wind",
        "SUID" : 2591,
        "selected" : false
      },
      "position" : {
        "x" : 892.9930610020871,
        "y" : -607.4243249135014
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2587",
        "shared_name" : "Night Slash",
        "name" : "Night Slash",
        "SUID" : 2587,
        "selected" : false
      },
      "position" : {
        "x" : 783.0130576451535,
        "y" : -335.07434932756394
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2583",
        "shared_name" : "Natural Gift",
        "name" : "Natural Gift",
        "SUID" : 2583,
        "selected" : false
      },
      "position" : {
        "x" : 878.3076056798214,
        "y" : -402.53308956193894
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2579",
        "shared_name" : "Nasty Plot",
        "name" : "Nasty Plot",
        "SUID" : 2579,
        "selected" : false
      },
      "position" : {
        "x" : 870.7731208165402,
        "y" : -314.43636409807175
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2575",
        "shared_name" : "Mud Bomb",
        "name" : "Mud Bomb",
        "SUID" : 2575,
        "selected" : false
      },
      "position" : {
        "x" : 564.5159415562863,
        "y" : -517.5592827038762
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2571",
        "shared_name" : "Mirror Shot",
        "name" : "Mirror Shot",
        "SUID" : 2571,
        "selected" : false
      },
      "position" : {
        "x" : 679.1183823903317,
        "y" : -325.7137994008061
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2567",
        "shared_name" : "Miracle Eye",
        "name" : "Miracle Eye",
        "SUID" : 2567,
        "selected" : false
      },
      "position" : {
        "x" : 826.879032071423,
        "y" : -293.5230492787358
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2563",
        "shared_name" : "Metal Burst",
        "name" : "Metal Burst",
        "SUID" : 2563,
        "selected" : false
      },
      "position" : {
        "x" : 907.2162207921261,
        "y" : -441.26065151262253
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2559",
        "shared_name" : "Me First",
        "name" : "Me First",
        "SUID" : 2559,
        "selected" : false
      },
      "position" : {
        "x" : 722.8972377141232,
        "y" : -417.5219506459233
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2555",
        "shared_name" : "Magnet Rise",
        "name" : "Magnet Rise",
        "SUID" : 2555,
        "selected" : false
      },
      "position" : {
        "x" : 891.1946448643918,
        "y" : -735.6195153431889
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2551",
        "shared_name" : "Magnet Bomb",
        "name" : "Magnet Bomb",
        "SUID" : 2551,
        "selected" : false
      },
      "position" : {
        "x" : 807.0682181676144,
        "y" : -380.535057945728
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2547",
        "shared_name" : "Magma Storm",
        "name" : "Magma Storm",
        "SUID" : 2547,
        "selected" : false
      },
      "position" : {
        "x" : 791.5510749181027,
        "y" : -777.7858056263921
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2543",
        "shared_name" : "Lunar Dance",
        "name" : "Lunar Dance",
        "SUID" : 2543,
        "selected" : false
      },
      "position" : {
        "x" : 567.7290610631222,
        "y" : -620.8934411244389
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2539",
        "shared_name" : "Lucky Chant",
        "name" : "Lucky Chant",
        "SUID" : 2539,
        "selected" : false
      },
      "position" : {
        "x" : 1062.0169410069698,
        "y" : -607.5535134510991
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2535",
        "shared_name" : "Leaf Storm",
        "name" : "Leaf Storm",
        "SUID" : 2535,
        "selected" : false
      },
      "position" : {
        "x" : 890.7228888829464,
        "y" : -355.9572076039311
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2531",
        "shared_name" : "Lava Plume",
        "name" : "Lava Plume",
        "SUID" : 2531,
        "selected" : false
      },
      "position" : {
        "x" : 1024.9675940831416,
        "y" : -392.5031747059819
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2527",
        "shared_name" : "Last Resort",
        "name" : "Last Resort",
        "SUID" : 2527,
        "selected" : false
      },
      "position" : {
        "x" : 960.1727942784543,
        "y" : -450.77443019914597
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2523",
        "shared_name" : "Judgment",
        "name" : "Judgment",
        "SUID" : 2523,
        "selected" : false
      },
      "position" : {
        "x" : 788.5072745640988,
        "y" : -518.7474600510594
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2519",
        "shared_name" : "Iron Head",
        "name" : "Iron Head",
        "SUID" : 2519,
        "selected" : false
      },
      "position" : {
        "x" : 781.560901578259,
        "y" : -275.33585445451706
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2515",
        "shared_name" : "Ice Shard",
        "name" : "Ice Shard",
        "SUID" : 2515,
        "selected" : false
      },
      "position" : {
        "x" : 658.9805182774777,
        "y" : -505.7062930302617
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2511",
        "shared_name" : "Ice Fang",
        "name" : "Ice Fang",
        "SUID" : 2511,
        "selected" : false
      },
      "position" : {
        "x" : 755.8418921788449,
        "y" : -631.6630028920171
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2507",
        "shared_name" : "Heart Swap",
        "name" : "Heart Swap",
        "SUID" : 2507,
        "selected" : false
      },
      "position" : {
        "x" : 721.120565350842,
        "y" : -599.5580681996342
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2503",
        "shared_name" : "Healing Wish",
        "name" : "Healing Wish",
        "SUID" : 2503,
        "selected" : false
      },
      "position" : {
        "x" : 929.2031134923214,
        "y" : -638.1154488759038
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2499",
        "shared_name" : "Heal Order",
        "name" : "Heal Order",
        "SUID" : 2499,
        "selected" : false
      },
      "position" : {
        "x" : 993.5221595128293,
        "y" : -725.6147240834233
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2495",
        "shared_name" : "Heal Block",
        "name" : "Heal Block",
        "SUID" : 2495,
        "selected" : false
      },
      "position" : {
        "x" : 667.7819251378293,
        "y" : -607.5055321888921
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2491",
        "shared_name" : "Head Smash",
        "name" : "Head Smash",
        "SUID" : 2491,
        "selected" : false
      },
      "position" : {
        "x" : 872.6398505528683,
        "y" : -649.3156365590092
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2487",
        "shared_name" : "Hammer Arm",
        "name" : "Hammer Arm",
        "SUID" : 2487,
        "selected" : false
      },
      "position" : {
        "x" : 1127.651004727673,
        "y" : -592.8674401478764
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2483",
        "shared_name" : "Gyro Ball",
        "name" : "Gyro Ball",
        "SUID" : 2483,
        "selected" : false
      },
      "position" : {
        "x" : 747.8771743138547,
        "y" : -817.7118310170171
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2479",
        "shared_name" : "Gunk Shot",
        "name" : "Gunk Shot",
        "SUID" : 2479,
        "selected" : false
      },
      "position" : {
        "x" : 613.2536429723019,
        "y" : -521.9541877942082
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2475",
        "shared_name" : "Guard Swap",
        "name" : "Guard Swap",
        "SUID" : 2475,
        "selected" : false
      },
      "position" : {
        "x" : 1007.1122168858761,
        "y" : -442.1090554432866
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2471",
        "shared_name" : "Gravity",
        "name" : "Gravity",
        "SUID" : 2471,
        "selected" : false
      },
      "position" : {
        "x" : 937.7858619054074,
        "y" : -354.4437798695561
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2467",
        "shared_name" : "Grass Knot",
        "name" : "Grass Knot",
        "SUID" : 2467,
        "selected" : false
      },
      "position" : {
        "x" : 747.9403647740597,
        "y" : -502.7235993580815
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2463",
        "shared_name" : "Giga Impact",
        "name" : "Giga Impact",
        "SUID" : 2463,
        "selected" : false
      },
      "position" : {
        "x" : 640.4626654942746,
        "y" : -564.563321037769
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2459",
        "shared_name" : "Gastro Acid",
        "name" : "Gastro Acid",
        "SUID" : 2459,
        "selected" : false
      },
      "position" : {
        "x" : 617.9211310704464,
        "y" : -609.3359231190678
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2455",
        "shared_name" : "Force Palm",
        "name" : "Force Palm",
        "SUID" : 2455,
        "selected" : false
      },
      "position" : {
        "x" : 1084.8437537511104,
        "y" : -564.823990746021
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2451",
        "shared_name" : "Focus Blast",
        "name" : "Focus Blast",
        "SUID" : 2451,
        "selected" : false
      },
      "position" : {
        "x" : 889.4564704259152,
        "y" : -832.8342675404546
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2447",
        "shared_name" : "Fling",
        "name" : "Fling",
        "SUID" : 2447,
        "selected" : false
      },
      "position" : {
        "x" : 702.4789237340207,
        "y" : -517.1451646523473
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2443",
        "shared_name" : "Flash Cannon",
        "name" : "Flash Cannon",
        "SUID" : 2443,
        "selected" : false
      },
      "position" : {
        "x" : 1105.6548804600948,
        "y" : -638.7839287953374
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2439",
        "shared_name" : "Flare Blitz",
        "name" : "Flare Blitz",
        "SUID" : 2439,
        "selected" : false
      },
      "position" : {
        "x" : 841.1547736485714,
        "y" : -755.6214226918217
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2435",
        "shared_name" : "Fire Fang",
        "name" : "Fire Fang",
        "SUID" : 2435,
        "selected" : false
      },
      "position" : {
        "x" : 690.4846356471295,
        "y" : -785.5001610951421
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2431",
        "shared_name" : "Feint",
        "name" : "Feint",
        "SUID" : 2431,
        "selected" : false
      },
      "position" : {
        "x" : 1008.5225562413449,
        "y" : -497.1195649342534
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2427",
        "shared_name" : "Energy Ball",
        "name" : "Energy Ball",
        "SUID" : 2427,
        "selected" : false
      },
      "position" : {
        "x" : 938.8405341466183,
        "y" : -813.5512475209233
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2423",
        "shared_name" : "Embargo",
        "name" : "Embargo",
        "SUID" : 2423,
        "selected" : false
      },
      "position" : {
        "x" : 836.1414527257199,
        "y" : -421.1784218983647
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2419",
        "shared_name" : "Earth Power",
        "name" : "Earth Power",
        "SUID" : 2419,
        "selected" : false
      },
      "position" : {
        "x" : 678.4376410802121,
        "y" : -687.8420952992436
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2415",
        "shared_name" : "Drain Punch",
        "name" : "Drain Punch",
        "SUID" : 2415,
        "selected" : false
      },
      "position" : {
        "x" : 623.3638877232785,
        "y" : -416.3834008412358
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2411",
        "shared_name" : "Dragon Rush",
        "name" : "Dragon Rush",
        "SUID" : 2411,
        "selected" : false
      },
      "position" : {
        "x" : 1020.428592618298,
        "y" : -335.84400264787644
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2407",
        "shared_name" : "Dragon Pulse",
        "name" : "Dragon Pulse",
        "SUID" : 2407,
        "selected" : false
      },
      "position" : {
        "x" : 1050.124668057751,
        "y" : -721.0151147084233
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2403",
        "shared_name" : "Draco Meteor",
        "name" : "Draco Meteor",
        "SUID" : 2403,
        "selected" : false
      },
      "position" : {
        "x" : 919.3299903233761,
        "y" : -528.6810473637578
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2399",
        "shared_name" : "Double Hit",
        "name" : "Double Hit",
        "SUID" : 2399,
        "selected" : false
      },
      "position" : {
        "x" : 854.0759620030636,
        "y" : -468.6655396656987
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2395",
        "shared_name" : "Discharge",
        "name" : "Discharge",
        "SUID" : 2395,
        "selected" : false
      },
      "position" : {
        "x" : 666.691366132092,
        "y" : -742.6396569447514
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2391",
        "shared_name" : "Defog",
        "name" : "Defog",
        "SUID" : 2391,
        "selected" : false
      },
      "position" : {
        "x" : 785.5404776890988,
        "y" : -420.4475640492436
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2387",
        "shared_name" : "Defend Order",
        "name" : "Defend Order",
        "SUID" : 2387,
        "selected" : false
      },
      "position" : {
        "x" : 1094.6487464268916,
        "y" : -698.2803582386967
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2383",
        "shared_name" : "Dark Void",
        "name" : "Dark Void",
        "SUID" : 2383,
        "selected" : false
      },
      "position" : {
        "x" : 987.2189368565793,
        "y" : -787.3496178822514
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2379",
        "shared_name" : "Dark Pulse",
        "name" : "Dark Pulse",
        "SUID" : 2379,
        "selected" : false
      },
      "position" : {
        "x" : 1078.6000708897823,
        "y" : -380.9983605580327
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2375",
        "shared_name" : "Crush Grip",
        "name" : "Crush Grip",
        "SUID" : 2375,
        "selected" : false
      },
      "position" : {
        "x" : 1020.7507666905636,
        "y" : -613.3861931996342
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2371",
        "shared_name" : "Cross Poison",
        "name" : "Cross Poison",
        "SUID" : 2371,
        "selected" : false
      },
      "position" : {
        "x" : 682.3222293217892,
        "y" : -387.74574367570847
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2367",
        "shared_name" : "Copycat",
        "name" : "Copycat",
        "SUID" : 2367,
        "selected" : false
      },
      "position" : {
        "x" : 902.9570044835324,
        "y" : -484.6888245778081
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2363",
        "shared_name" : "Close Combat",
        "name" : "Close Combat",
        "SUID" : 2363,
        "selected" : false
      },
      "position" : {
        "x" : 583.2221030553097,
        "y" : -566.3074845509526
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2359",
        "shared_name" : "Chatter",
        "name" : "Chatter",
        "SUID" : 2359,
        "selected" : false
      },
      "position" : {
        "x" : 1060.3552283604854,
        "y" : -428.2126168446538
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2355",
        "shared_name" : "Charge Beam",
        "name" : "Charge Beam",
        "SUID" : 2355,
        "selected" : false
      },
      "position" : {
        "x" : 647.5454863866086,
        "y" : -652.4557885365483
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2351",
        "shared_name" : "Captivate",
        "name" : "Captivate",
        "SUID" : 2351,
        "selected" : false
      },
      "position" : {
        "x" : 1090.4706458409541,
        "y" : -498.6018475728032
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2347",
        "shared_name" : "Bullet Punch",
        "name" : "Bullet Punch",
        "SUID" : 2347,
        "selected" : false
      },
      "position" : {
        "x" : 700.6856965382809,
        "y" : -646.8648461537358
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2343",
        "shared_name" : "Bug Buzz",
        "name" : "Bug Buzz",
        "SUID" : 2343,
        "selected" : false
      },
      "position" : {
        "x" : 720.2377223332638,
        "y" : -358.995263023853
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2339",
        "shared_name" : "Bug Bite",
        "name" : "Bug Bite",
        "SUID" : 2339,
        "selected" : false
      },
      "position" : {
        "x" : 826.5027503331418,
        "y" : -675.2157067494389
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2335",
        "shared_name" : "Brine",
        "name" : "Brine",
        "SUID" : 2335,
        "selected" : false
      },
      "position" : {
        "x" : 945.3040198643918,
        "y" : -716.942528648853
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2331",
        "shared_name" : "Brave Bird",
        "name" : "Brave Bird",
        "SUID" : 2331,
        "selected" : false
      },
      "position" : {
        "x" : 859.6789740880246,
        "y" : -703.2642144398686
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2327",
        "shared_name" : "Avalanche",
        "name" : "Avalanche",
        "SUID" : 2327,
        "selected" : false
      },
      "position" : {
        "x" : 972.8347510655636,
        "y" : -405.71175472307175
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2323",
        "shared_name" : "Aura Sphere",
        "name" : "Aura Sphere",
        "SUID" : 2323,
        "selected" : false
      },
      "position" : {
        "x" : 735.437812741589,
        "y" : -680.2072991566655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2319",
        "shared_name" : "Attack Order",
        "name" : "Attack Order",
        "SUID" : 2319,
        "selected" : false
      },
      "position" : {
        "x" : 1027.795535977673,
        "y" : -564.4971741871831
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2315",
        "shared_name" : "Assurance",
        "name" : "Assurance",
        "SUID" : 2315,
        "selected" : false
      },
      "position" : {
        "x" : 735.7796973546261,
        "y" : -306.04422847795456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2311",
        "shared_name" : "Aqua Tail",
        "name" : "Aqua Tail",
        "SUID" : 2311,
        "selected" : false
      },
      "position" : {
        "x" : 890.000598843884,
        "y" : -781.3830956654546
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2307",
        "shared_name" : "Aqua Ring",
        "name" : "Aqua Ring",
        "SUID" : 2307,
        "selected" : false
      },
      "position" : {
        "x" : 780.2490958531613,
        "y" : -584.1757821278569
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2303",
        "shared_name" : "Aqua Jet",
        "name" : "Aqua Jet",
        "SUID" : 2303,
        "selected" : false
      },
      "position" : {
        "x" : 806.4666098912472,
        "y" : -837.6981286244389
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2299",
        "shared_name" : "Air Slash",
        "name" : "Air Slash",
        "SUID" : 2299,
        "selected" : false
      },
      "position" : {
        "x" : 1012.4669837315793,
        "y" : -677.1807488636967
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2295",
        "shared_name" : "Acupressure",
        "name" : "Acupressure",
        "SUID" : 2295,
        "selected" : false
      },
      "position" : {
        "x" : 742.2165030797238,
        "y" : -554.6036194996831
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2293",
        "shared_name" : "gen4",
        "name" : "gen4",
        "SUID" : 2293,
        "selected" : false
      },
      "position" : {
        "x" : 852.1055182774777,
        "y" : -560.5755089955327
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2289",
        "shared_name" : "Yawn",
        "name" : "Yawn",
        "SUID" : 2289,
        "selected" : false
      },
      "position" : {
        "x" : -489.76153952281527,
        "y" : 63.23784549665481
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2285",
        "shared_name" : "Wish",
        "name" : "Wish",
        "SUID" : 2285,
        "selected" : false
      },
      "position" : {
        "x" : -518.3370781580692,
        "y" : 276.253027991772
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2281",
        "shared_name" : "Will-O-Wisp",
        "name" : "Will-O-Wisp",
        "SUID" : 2281,
        "selected" : false
      },
      "position" : {
        "x" : -839.8907738367801,
        "y" : 228.9162359995845
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2277",
        "shared_name" : "Weather Ball",
        "name" : "Weather Ball",
        "SUID" : 2277,
        "selected" : false
      },
      "position" : {
        "x" : -424.85081869761996,
        "y" : 15.760916785717313
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2273",
        "shared_name" : "Water Spout",
        "name" : "Water Spout",
        "SUID" : 2273,
        "selected" : false
      },
      "position" : {
        "x" : -489.24239737193636,
        "y" : 414.5836172862056
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2269",
        "shared_name" : "Water Sport",
        "name" : "Water Sport",
        "SUID" : 2269,
        "selected" : false
      },
      "position" : {
        "x" : -388.6576710383182,
        "y" : 97.41744144392044
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2265",
        "shared_name" : "Water Pulse",
        "name" : "Water Pulse",
        "SUID" : 2265,
        "selected" : false
      },
      "position" : {
        "x" : -816.4274254481082,
        "y" : 181.8773413462642
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2261",
        "shared_name" : "Volt Tackle",
        "name" : "Volt Tackle",
        "SUID" : 2261,
        "selected" : false
      },
      "position" : {
        "x" : -461.38084799449496,
        "y" : 226.59940250349075
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2257",
        "shared_name" : "Uproar",
        "name" : "Uproar",
        "SUID" : 2257,
        "selected" : false
      },
      "position" : {
        "x" : -529.0206108729129,
        "y" : 22.514212684154813
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2253",
        "shared_name" : "Trick",
        "name" : "Trick",
        "SUID" : 2253,
        "selected" : false
      },
      "position" : {
        "x" : -740.1267662684207,
        "y" : 7.636679725170438
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2249",
        "shared_name" : "Torment",
        "name" : "Torment",
        "SUID" : 2249,
        "selected" : false
      },
      "position" : {
        "x" : -435.25560385386996,
        "y" : 182.0312720103267
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2245",
        "shared_name" : "Tickle",
        "name" : "Tickle",
        "SUID" : 2245,
        "selected" : false
      },
      "position" : {
        "x" : -392.85361487071566,
        "y" : 157.2942419810298
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2241",
        "shared_name" : "Teeter Dance",
        "name" : "Teeter Dance",
        "SUID" : 2241,
        "selected" : false
      },
      "position" : {
        "x" : -617.2082482020145,
        "y" : 289.1812964243892
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2237",
        "shared_name" : "Taunt",
        "name" : "Taunt",
        "SUID" : 2237,
        "selected" : false
      },
      "position" : {
        "x" : -546.080440584827,
        "y" : -94.52539913225144
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2233",
        "shared_name" : "Tail Glow",
        "name" : "Tail Glow",
        "SUID" : 2233,
        "selected" : false
      },
      "position" : {
        "x" : -615.9931755701786,
        "y" : 70.43819339704544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2229",
        "shared_name" : "Swallow",
        "name" : "Swallow",
        "SUID" : 2229,
        "selected" : false
      },
      "position" : {
        "x" : -570.5654259363895,
        "y" : 261.36397464704544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2225",
        "shared_name" : "Superpower",
        "name" : "Superpower",
        "SUID" : 2225,
        "selected" : false
      },
      "position" : {
        "x" : -718.2994957606082,
        "y" : 309.1274481577876
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2221",
        "shared_name" : "Stockpile",
        "name" : "Stockpile",
        "SUID" : 2221,
        "selected" : false
      },
      "position" : {
        "x" : -506.5658226649051,
        "y" : 188.0513220591548
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2217",
        "shared_name" : "Spit Up",
        "name" : "Spit Up",
        "SUID" : 2217,
        "selected" : false
      },
      "position" : {
        "x" : -693.3315697352176,
        "y" : 212.6097937388423
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2213",
        "shared_name" : "Snatch",
        "name" : "Snatch",
        "SUID" : 2213,
        "selected" : false
      },
      "position" : {
        "x" : -597.5083885828739,
        "y" : -75.01032344865769
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2209",
        "shared_name" : "Smelling Salts",
        "name" : "Smelling Salts",
        "SUID" : 2209,
        "selected" : false
      },
      "position" : {
        "x" : -571.3108025233036,
        "y" : 307.5438452525142
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2205",
        "shared_name" : "Slack Off",
        "name" : "Slack Off",
        "SUID" : 2205,
        "selected" : false
      },
      "position" : {
        "x" : -348.7765923182254,
        "y" : 137.7211218638423
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2201",
        "shared_name" : "Sky Uppercut",
        "name" : "Sky Uppercut",
        "SUID" : 2201,
        "selected" : false
      },
      "position" : {
        "x" : -786.8980370203739,
        "y" : -8.768380089282687
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2197",
        "shared_name" : "Skill Swap",
        "name" : "Skill Swap",
        "SUID" : 2197,
        "selected" : false
      },
      "position" : {
        "x" : -409.726322237659,
        "y" : 220.58385379743606
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2193",
        "shared_name" : "Silver Wind",
        "name" : "Silver Wind",
        "SUID" : 2193,
        "selected" : false
      },
      "position" : {
        "x" : -665.8933373133426,
        "y" : -64.66254512834519
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2189",
        "shared_name" : "Signal Beam",
        "name" : "Signal Beam",
        "SUID" : 2189,
        "selected" : false
      },
      "position" : {
        "x" : -426.99770361583285,
        "y" : 274.1868201060298
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2185",
        "shared_name" : "Shock Wave",
        "name" : "Shock Wave",
        "SUID" : 2185,
        "selected" : false
      },
      "position" : {
        "x" : -547.2451439539676,
        "y" : 430.20295246076614
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2181",
        "shared_name" : "Sheer Cold",
        "name" : "Sheer Cold",
        "SUID" : 2181,
        "selected" : false
      },
      "position" : {
        "x" : -510.3649407068973,
        "y" : -19.077828331470187
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2177",
        "shared_name" : "Shadow Punch",
        "name" : "Shadow Punch",
        "SUID" : 2177,
        "selected" : false
      },
      "position" : {
        "x" : -711.9013024012332,
        "y" : 158.0005408091548
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2173",
        "shared_name" : "Secret Power",
        "name" : "Secret Power",
        "SUID" : 2173,
        "selected" : false
      },
      "position" : {
        "x" : -763.5823631922489,
        "y" : 272.1878882212642
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2169",
        "shared_name" : "Sand Tomb",
        "name" : "Sand Tomb",
        "SUID" : 2169,
        "selected" : false
      },
      "position" : {
        "x" : -709.7039147059207,
        "y" : -31.097603722095187
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2165",
        "shared_name" : "Role Play",
        "name" : "Role Play",
        "SUID" : 2165,
        "selected" : false
      },
      "position" : {
        "x" : -834.7100182215457,
        "y" : -11.746468468188937
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2161",
        "shared_name" : "Rock Tomb",
        "name" : "Rock Tomb",
        "SUID" : 2161,
        "selected" : false
      },
      "position" : {
        "x" : -780.6863365809207,
        "y" : 40.83803470563919
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2157",
        "shared_name" : "Rock Blast",
        "name" : "Rock Blast",
        "SUID" : 2157,
        "selected" : false
      },
      "position" : {
        "x" : -612.7601128260379,
        "y" : 446.4192534251216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2153",
        "shared_name" : "Revenge",
        "name" : "Revenge",
        "SUID" : 2153,
        "selected" : false
      },
      "position" : {
        "x" : -720.0343285242801,
        "y" : 56.31163700056106
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2149",
        "shared_name" : "Refresh",
        "name" : "Refresh",
        "SUID" : 2149,
        "selected" : false
      },
      "position" : {
        "x" : -714.4998131434207,
        "y" : 261.21251590681106
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2145",
        "shared_name" : "Recycle",
        "name" : "Recycle",
        "SUID" : 2145,
        "selected" : false
      },
      "position" : {
        "x" : -871.3812828699832,
        "y" : 82.01119144392044
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2141",
        "shared_name" : "Psycho Boost",
        "name" : "Psycho Boost",
        "SUID" : 2141,
        "selected" : false
      },
      "position" : {
        "x" : -437.0294914881473,
        "y" : 63.74822147321731
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2137",
        "shared_name" : "Poison Tail",
        "name" : "Poison Tail",
        "SUID" : 2137,
        "selected" : false
      },
      "position" : {
        "x" : -533.087276522327,
        "y" : 78.60591800642044
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2133",
        "shared_name" : "Poison Fang",
        "name" : "Poison Fang",
        "SUID" : 2133,
        "selected" : false
      },
      "position" : {
        "x" : -510.0073662440067,
        "y" : 233.86551578474075
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2129",
        "shared_name" : "Overheat",
        "name" : "Overheat",
        "SUID" : 2129,
        "selected" : false
      },
      "position" : {
        "x" : -752.981563631702,
        "y" : 131.6965552134517
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2125",
        "shared_name" : "Odor Sleuth",
        "name" : "Odor Sleuth",
        "SUID" : 2125,
        "selected" : false
      },
      "position" : {
        "x" : -845.0368004481082,
        "y" : 38.01045902204544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2121",
        "shared_name" : "Needle Arm",
        "name" : "Needle Arm",
        "SUID" : 2121,
        "selected" : false
      },
      "position" : {
        "x" : -554.3996391932254,
        "y" : 157.4551001353267
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2117",
        "shared_name" : "Nature Power",
        "name" : "Nature Power",
        "SUID" : 2117,
        "selected" : false
      },
      "position" : {
        "x" : -611.3453636805301,
        "y" : 346.9273138804439
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2113",
        "shared_name" : "Muddy Water",
        "name" : "Muddy Water",
        "SUID" : 2113,
        "selected" : false
      },
      "position" : {
        "x" : -380.22934729259066,
        "y" : 47.70192630720169
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2109",
        "shared_name" : "Mud Sport",
        "name" : "Mud Sport",
        "SUID" : 2109,
        "selected" : false
      },
      "position" : {
        "x" : -553.0102196375614,
        "y" : -44.40204708147019
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2105",
        "shared_name" : "Mud Shot",
        "name" : "Mud Shot",
        "SUID" : 2105,
        "selected" : false
      },
      "position" : {
        "x" : -768.9386559168582,
        "y" : -56.19525997209519
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2101",
        "shared_name" : "Mist Ball",
        "name" : "Mist Ball",
        "SUID" : 2101,
        "selected" : false
      },
      "position" : {
        "x" : -764.1740074793582,
        "y" : 86.36498172712356
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2097",
        "shared_name" : "Meteor Mash",
        "name" : "Meteor Mash",
        "SUID" : 2097,
        "selected" : false
      },
      "position" : {
        "x" : -867.2960472742801,
        "y" : 180.7226782603267
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2093",
        "shared_name" : "Metal Sound",
        "name" : "Metal Sound",
        "SUID" : 2093,
        "selected" : false
      },
      "position" : {
        "x" : -800.0812035242801,
        "y" : 134.91344364118606
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2089",
        "shared_name" : "Memento",
        "name" : "Memento",
        "SUID" : 2089,
        "selected" : false
      },
      "position" : {
        "x" : -438.92308432261996,
        "y" : -31.73313228654831
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2085",
        "shared_name" : "Magical Leaf",
        "name" : "Magical Leaf",
        "SUID" : 2085,
        "selected" : false
      },
      "position" : {
        "x" : -632.4089623133426,
        "y" : 240.19470889997513
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2081",
        "shared_name" : "Magic Coat",
        "name" : "Magic Coat",
        "SUID" : 2081,
        "selected" : false
      },
      "position" : {
        "x" : -791.6537132899051,
        "y" : 225.00333316755325
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2077",
        "shared_name" : "Luster Purge",
        "name" : "Luster Purge",
        "SUID" : 2077,
        "selected" : false
      },
      "position" : {
        "x" : -515.4641533533817,
        "y" : 126.31856449079544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2073",
        "shared_name" : "Leaf Blade",
        "name" : "Leaf Blade",
        "SUID" : 2073,
        "selected" : false
      },
      "position" : {
        "x" : -716.6177025477176,
        "y" : 389.54646976423294
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2069",
        "shared_name" : "Knock Off",
        "name" : "Knock Off",
        "SUID" : 2069,
        "selected" : false
      },
      "position" : {
        "x" : -813.2755699793582,
        "y" : 271.52994449567825
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2065",
        "shared_name" : "Iron Defense",
        "name" : "Iron Defense",
        "SUID" : 2065,
        "selected" : false
      },
      "position" : {
        "x" : -485.8463631312137,
        "y" : 346.3377753062251
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2061",
        "shared_name" : "Ingrain",
        "name" : "Ingrain",
        "SUID" : 2061,
        "selected" : false
      },
      "position" : {
        "x" : -577.7421837488895,
        "y" : 0.7373877329829384
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2057",
        "shared_name" : "Imprison",
        "name" : "Imprison",
        "SUID" : 2057,
        "selected" : false
      },
      "position" : {
        "x" : -358.68469149272494,
        "y" : 208.65152652692825
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2053",
        "shared_name" : "Icicle Spear",
        "name" : "Icicle Spear",
        "SUID" : 2053,
        "selected" : false
      },
      "position" : {
        "x" : -525.8613396326786,
        "y" : 322.12100894880325
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2049",
        "shared_name" : "Ice Ball",
        "name" : "Ice Ball",
        "SUID" : 2049,
        "selected" : false
      },
      "position" : {
        "x" : -561.7887993494754,
        "y" : 212.1864538950923
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2045",
        "shared_name" : "Hyper Voice",
        "name" : "Hyper Voice",
        "SUID" : 2045,
        "selected" : false
      },
      "position" : {
        "x" : -613.3137932459598,
        "y" : -27.91574947404831
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2041",
        "shared_name" : "Hydro Cannon",
        "name" : "Hydro Cannon",
        "SUID" : 2041,
        "selected" : false
      },
      "position" : {
        "x" : -813.8328209559207,
        "y" : 82.80431278181106
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2037",
        "shared_name" : "Howl",
        "name" : "Howl",
        "SUID" : 2037,
        "selected" : false
      },
      "position" : {
        "x" : -845.589473787952,
        "y" : 130.0968542857173
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2033",
        "shared_name" : "Helping Hand",
        "name" : "Helping Hand",
        "SUID" : 2033,
        "selected" : false
      },
      "position" : {
        "x" : -572.3358727137332,
        "y" : 107.26369388532669
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2029",
        "shared_name" : "Heat Wave",
        "name" : "Heat Wave",
        "SUID" : 2029,
        "selected" : false
      },
      "position" : {
        "x" : -431.0329399744754,
        "y" : 125.80486209821731
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2025",
        "shared_name" : "Hail",
        "name" : "Hail",
        "SUID" : 2025,
        "selected" : false
      },
      "position" : {
        "x" : -475.4572563807254,
        "y" : 16.500113563061063
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2021",
        "shared_name" : "Grudge",
        "name" : "Grudge",
        "SUID" : 2021,
        "selected" : false
      },
      "position" : {
        "x" : -388.2577095667606,
        "y" : 314.9226141734126
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2017",
        "shared_name" : "Grass Whistle",
        "name" : "Grass Whistle",
        "SUID" : 2017,
        "selected" : false
      },
      "position" : {
        "x" : -781.9098168055301,
        "y" : 319.5238104624751
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2013",
        "shared_name" : "Frenzy Plant",
        "name" : "Frenzy Plant",
        "SUID" : 2013,
        "selected" : false
      },
      "position" : {
        "x" : -866.7295494715457,
        "y" : 274.6959753794673
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2009",
        "shared_name" : "Follow Me",
        "name" : "Follow Me",
        "SUID" : 2009,
        "selected" : false
      },
      "position" : {
        "x" : -487.5813484827762,
        "y" : -64.83338253068894
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2005",
        "shared_name" : "Focus Punch",
        "name" : "Focus Punch",
        "SUID" : 2005,
        "selected" : false
      },
      "position" : {
        "x" : -474.7037621180301,
        "y" : 155.36803348493606
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2001",
        "shared_name" : "Flatter",
        "name" : "Flatter",
        "SUID" : 2001,
        "selected" : false
      },
      "position" : {
        "x" : -662.3504295984989,
        "y" : 425.3688727183345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1997",
        "shared_name" : "Feather Dance",
        "name" : "Feather Dance",
        "SUID" : 1997,
        "selected" : false
      },
      "position" : {
        "x" : -637.5059471766239,
        "y" : -102.90265743303269
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1993",
        "shared_name" : "Fake Tears",
        "name" : "Fake Tears",
        "SUID" : 1993,
        "selected" : false
      },
      "position" : {
        "x" : -657.4159203211551,
        "y" : -16.05246822404831
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1989",
        "shared_name" : "Fake Out",
        "name" : "Fake Out",
        "SUID" : 1989,
        "selected" : false
      },
      "position" : {
        "x" : -687.8960228602176,
        "y" : 354.50245578718216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1985",
        "shared_name" : "Facade",
        "name" : "Facade",
        "SUID" : 1985,
        "selected" : false
      },
      "position" : {
        "x" : -527.3133202234989,
        "y" : 379.2637472910884
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1981",
        "shared_name" : "Extrasensory",
        "name" : "Extrasensory",
        "SUID" : 1981,
        "selected" : false
      },
      "position" : {
        "x" : -374.1854859034305,
        "y" : 260.94026859235794
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1977",
        "shared_name" : "Eruption",
        "name" : "Eruption",
        "SUID" : 1977,
        "selected" : false
      },
      "position" : {
        "x" : -842.0571556727176,
        "y" : 319.9490423960689
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1973",
        "shared_name" : "Endeavor",
        "name" : "Endeavor",
        "SUID" : 1973,
        "selected" : false
      },
      "position" : {
        "x" : -712.814327303577,
        "y" : 437.74884517622024
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1969",
        "shared_name" : "Dragon Dance",
        "name" : "Dragon Dance",
        "SUID" : 1969,
        "selected" : false
      },
      "position" : {
        "x" : -443.01929861705355,
        "y" : 326.07149417829544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1965",
        "shared_name" : "Dragon Claw",
        "name" : "Dragon Claw",
        "SUID" : 1965,
        "selected" : false
      },
      "position" : {
        "x" : -671.6894188563114,
        "y" : 274.35909183454544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1961",
        "shared_name" : "Doom Desire",
        "name" : "Doom Desire",
        "SUID" : 1961,
        "selected" : false
      },
      "position" : {
        "x" : -565.9221764246707,
        "y" : 354.9366980357173
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1957",
        "shared_name" : "Dive",
        "name" : "Dive",
        "SUID" : 1957,
        "selected" : false
      },
      "position" : {
        "x" : -590.7117729822879,
        "y" : 398.67718418073684
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1953",
        "shared_name" : "Crush Claw",
        "name" : "Crush Claw",
        "SUID" : 1953,
        "selected" : false
      },
      "position" : {
        "x" : -668.166622225452,
        "y" : 62.61501224470169
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1949",
        "shared_name" : "Covet",
        "name" : "Covet",
        "SUID" : 1949,
        "selected" : false
      },
      "position" : {
        "x" : -657.9485741297489,
        "y" : 111.04750736188919
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1945",
        "shared_name" : "Cosmic Power",
        "name" : "Cosmic Power",
        "SUID" : 1945,
        "selected" : false
      },
      "position" : {
        "x" : -643.6972008387332,
        "y" : 379.09163577985794
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1941",
        "shared_name" : "Charge",
        "name" : "Charge",
        "SUID" : 1941,
        "selected" : false
      },
      "position" : {
        "x" : -741.769649569202,
        "y" : 224.0156012339595
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1937",
        "shared_name" : "Camouflage",
        "name" : "Camouflage",
        "SUID" : 1937,
        "selected" : false
      },
      "position" : {
        "x" : -471.48921591441683,
        "y" : 104.60246952009231
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1933",
        "shared_name" : "Calm Mind",
        "name" : "Calm Mind",
        "SUID" : 1933,
        "selected" : false
      },
      "position" : {
        "x" : -711.0598717371707,
        "y" : 104.38115604352981
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1929",
        "shared_name" : "Bullet Seed",
        "name" : "Bullet Seed",
        "SUID" : 1929,
        "selected" : false
      },
      "position" : {
        "x" : -716.296749178577,
        "y" : -83.34217159318894
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1925",
        "shared_name" : "Bulk Up",
        "name" : "Bulk Up",
        "SUID" : 1925,
        "selected" : false
      },
      "position" : {
        "x" : -475.320560518909,
        "y" : 283.10965640974075
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1921",
        "shared_name" : "Brick Break",
        "name" : "Brick Break",
        "SUID" : 1921,
        "selected" : false
      },
      "position" : {
        "x" : -771.1927757899051,
        "y" : 396.4285116953853
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1917",
        "shared_name" : "Bounce",
        "name" : "Bounce",
        "SUID" : 1917,
        "selected" : false
      },
      "position" : {
        "x" : -658.2747154871707,
        "y" : 322.7423315806392
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1913",
        "shared_name" : "Block",
        "name" : "Block",
        "SUID" : 1913,
        "selected" : false
      },
      "position" : {
        "x" : -814.8006249109989,
        "y" : 362.36817844343216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1909",
        "shared_name" : "Blaze Kick",
        "name" : "Blaze Kick",
        "SUID" : 1909,
        "selected" : false
      },
      "position" : {
        "x" : -571.4126091639286,
        "y" : 46.86455448102981
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1905",
        "shared_name" : "Blast Burn",
        "name" : "Blast Burn",
        "SUID" : 1905,
        "selected" : false
      },
      "position" : {
        "x" : -629.2671166102176,
        "y" : 26.09682376813919
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1901",
        "shared_name" : "Astonish",
        "name" : "Astonish",
        "SUID" : 1901,
        "selected" : false
      },
      "position" : {
        "x" : -688.3638573328739,
        "y" : 16.66060550642044
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1897",
        "shared_name" : "Assist",
        "name" : "Assist",
        "SUID" : 1897,
        "selected" : false
      },
      "position" : {
        "x" : -894.931026522327,
        "y" : 225.49567325544388
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1893",
        "shared_name" : "Aromatherapy",
        "name" : "Aromatherapy",
        "SUID" : 1893,
        "selected" : false
      },
      "position" : {
        "x" : -895.4544029871707,
        "y" : 135.5339575572017
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1889",
        "shared_name" : "Arm Thrust",
        "name" : "Arm Thrust",
        "SUID" : 1889,
        "selected" : false
      },
      "position" : {
        "x" : -747.5548973719364,
        "y" : 348.94512851667434
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1885",
        "shared_name" : "Air Cutter",
        "name" : "Air Cutter",
        "SUID" : 1885,
        "selected" : false
      },
      "position" : {
        "x" : -436.389522616077,
        "y" : 376.2412176890376
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1881",
        "shared_name" : "Aerial Ace",
        "name" : "Aerial Ace",
        "SUID" : 1881,
        "selected" : false
      },
      "position" : {
        "x" : -761.7832298914676,
        "y" : 179.30672367048294
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1879",
        "shared_name" : "gen3",
        "name" : "gen3",
        "SUID" : 1879,
        "selected" : false
      },
      "position" : {
        "x" : -625.5109215418582,
        "y" : 167.7651587290767
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1875",
        "shared_name" : "Zap Cannon",
        "name" : "Zap Cannon",
        "SUID" : 1875,
        "selected" : false
      },
      "position" : {
        "x" : -668.3845940272098,
        "y" : 968.6582499308589
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1871",
        "shared_name" : "Whirlpool",
        "name" : "Whirlpool",
        "SUID" : 1871,
        "selected" : false
      },
      "position" : {
        "x" : -548.651500765491,
        "y" : 834.9349089426997
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1867",
        "shared_name" : "Vital Throw",
        "name" : "Vital Throw",
        "SUID" : 1867,
        "selected" : false
      },
      "position" : {
        "x" : -551.390026156116,
        "y" : 904.5343428416255
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1863",
        "shared_name" : "Twister",
        "name" : "Twister",
        "SUID" : 1863,
        "selected" : false
      },
      "position" : {
        "x" : -579.790905062366,
        "y" : 942.0022841258052
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1859",
        "shared_name" : "Triple Kick",
        "name" : "Triple Kick",
        "SUID" : 1859,
        "selected" : false
      },
      "position" : {
        "x" : -588.372692171741,
        "y" : 1043.7905035777094
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1855",
        "shared_name" : "Thief",
        "name" : "Thief",
        "SUID" : 1855,
        "selected" : false
      },
      "position" : {
        "x" : -596.6725578943973,
        "y" : 695.1174956126216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1851",
        "shared_name" : "Synthesis",
        "name" : "Synthesis",
        "SUID" : 1851,
        "selected" : false
      },
      "position" : {
        "x" : -707.8280449549442,
        "y" : 778.5289488596919
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1847",
        "shared_name" : "Sweet Scent",
        "name" : "Sweet Scent",
        "SUID" : 1847,
        "selected" : false
      },
      "position" : {
        "x" : -664.0239067713504,
        "y" : 735.431063727856
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1843",
        "shared_name" : "Sweet Kiss",
        "name" : "Sweet Kiss",
        "SUID" : 1843,
        "selected" : false
      },
      "position" : {
        "x" : -651.2780571619754,
        "y" : 641.4933501048091
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1839",
        "shared_name" : "Swagger",
        "name" : "Swagger",
        "SUID" : 1839,
        "selected" : false
      },
      "position" : {
        "x" : -683.2651787440067,
        "y" : 546.4192534251216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1835",
        "shared_name" : "Sunny Day",
        "name" : "Sunny Day",
        "SUID" : 1835,
        "selected" : false
      },
      "position" : {
        "x" : -663.0258598963504,
        "y" : 929.0085631175044
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1831",
        "shared_name" : "Steel Wing",
        "name" : "Steel Wing",
        "SUID" : 1831,
        "selected" : false
      },
      "position" : {
        "x" : -374.9766350428348,
        "y" : 772.2686949534419
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1827",
        "shared_name" : "Spite",
        "name" : "Spite",
        "SUID" : 1827,
        "selected" : false
      },
      "position" : {
        "x" : -842.8335686365848,
        "y" : 782.4052611155513
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1823",
        "shared_name" : "Spikes",
        "name" : "Spikes",
        "SUID" : 1823,
        "selected" : false
      },
      "position" : {
        "x" : -793.2849846522098,
        "y" : 929.9730864329341
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1819",
        "shared_name" : "Spider Web",
        "name" : "Spider Web",
        "SUID" : 1819,
        "selected" : false
      },
      "position" : {
        "x" : -506.6150627772098,
        "y" : 847.2241087718013
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1815",
        "shared_name" : "Spark",
        "name" : "Spark",
        "SUID" : 1815,
        "selected" : false
      },
      "position" : {
        "x" : -718.343151156116,
        "y" : 845.6072111887935
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1811",
        "shared_name" : "Snore",
        "name" : "Snore",
        "SUID" : 1811,
        "selected" : false
      },
      "position" : {
        "x" : -857.4478264490848,
        "y" : 833.9316588206294
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1807",
        "shared_name" : "Sludge Bomb",
        "name" : "Sludge Bomb",
        "SUID" : 1807,
        "selected" : false
      },
      "position" : {
        "x" : -421.8147698084598,
        "y" : 958.0286780161861
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1803",
        "shared_name" : "Sleep Talk",
        "name" : "Sleep Talk",
        "SUID" : 1803,
        "selected" : false
      },
      "position" : {
        "x" : -644.740367952991,
        "y" : 1011.7562666697505
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1799",
        "shared_name" : "Sketch",
        "name" : "Sketch",
        "SUID" : 1799,
        "selected" : false
      },
      "position" : {
        "x" : -604.3620720545536,
        "y" : 645.7422209544185
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1795",
        "shared_name" : "Shadow Ball",
        "name" : "Shadow Ball",
        "SUID" : 1795,
        "selected" : false
      },
      "position" : {
        "x" : -797.1730156580692,
        "y" : 780.0564604563716
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1791",
        "shared_name" : "Scary Face",
        "name" : "Scary Face",
        "SUID" : 1791,
        "selected" : false
      },
      "position" : {
        "x" : -791.6553764979129,
        "y" : 588.4089079661372
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1787",
        "shared_name" : "Sandstorm",
        "name" : "Sandstorm",
        "SUID" : 1787,
        "selected" : false
      },
      "position" : {
        "x" : -440.1354485193973,
        "y" : 826.1374235911372
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1783",
        "shared_name" : "Safeguard",
        "name" : "Safeguard",
        "SUID" : 1783,
        "selected" : false
      },
      "position" : {
        "x" : -799.0175896326786,
        "y" : 677.727206305981
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1779",
        "shared_name" : "Sacred Fire",
        "name" : "Sacred Fire",
        "SUID" : 1779,
        "selected" : false
      },
      "position" : {
        "x" : -422.6826897303348,
        "y" : 780.9918394846919
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1775",
        "shared_name" : "Rollout",
        "name" : "Rollout",
        "SUID" : 1775,
        "selected" : false
      },
      "position" : {
        "x" : -845.0176201502567,
        "y" : 946.9154730601314
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1771",
        "shared_name" : "Rock Smash",
        "name" : "Rock Smash",
        "SUID" : 1771,
        "selected" : false
      },
      "position" : {
        "x" : -533.2885246912723,
        "y" : 1041.2894278330805
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1767",
        "shared_name" : "Reversal",
        "name" : "Reversal",
        "SUID" : 1767,
        "selected" : false
      },
      "position" : {
        "x" : -443.5919914881473,
        "y" : 652.0822172923091
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1763",
        "shared_name" : "Return",
        "name" : "Return",
        "SUID" : 1763,
        "selected" : false
      },
      "position" : {
        "x" : -668.3370781580692,
        "y" : 868.7458983225825
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1759",
        "shared_name" : "Rapid Spin",
        "name" : "Rapid Spin",
        "SUID" : 1759,
        "selected" : false
      },
      "position" : {
        "x" : -386.15259939830355,
        "y" : 839.7610350413325
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1755",
        "shared_name" : "Rain Dance",
        "name" : "Rain Dance",
        "SUID" : 1755,
        "selected" : false
      },
      "position" : {
        "x" : -751.8628349940067,
        "y" : 762.983325080395
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1751",
        "shared_name" : "Pursuit",
        "name" : "Pursuit",
        "SUID" : 1751,
        "selected" : false
      },
      "position" : {
        "x" : -468.7838860193973,
        "y" : 760.286044196606
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1747",
        "shared_name" : "Psych Up",
        "name" : "Psych Up",
        "SUID" : 1747,
        "selected" : false
      },
      "position" : {
        "x" : -794.3870049158817,
        "y" : 878.462931708813
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1743",
        "shared_name" : "Protect",
        "name" : "Protect",
        "SUID" : 1743,
        "selected" : false
      },
      "position" : {
        "x" : -610.293590609241,
        "y" : 981.5153590006831
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1739",
        "shared_name" : "Present",
        "name" : "Present",
        "SUID" : 1739,
        "selected" : false
      },
      "position" : {
        "x" : -507.54554373424105,
        "y" : 905.6375990672115
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1735",
        "shared_name" : "Powder Snow",
        "name" : "Powder Snow",
        "SUID" : 1735,
        "selected" : false
      },
      "position" : {
        "x" : -730.8270683924442,
        "y" : 581.3125334544185
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1731",
        "shared_name" : "Perish Song",
        "name" : "Perish Song",
        "SUID" : 1731,
        "selected" : false
      },
      "position" : {
        "x" : -623.3855705897098,
        "y" : 549.3596525950435
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1727",
        "shared_name" : "Pain Split",
        "name" : "Pain Split",
        "SUID" : 1727,
        "selected" : false
      },
      "position" : {
        "x" : -639.9895134608036,
        "y" : 1061.505656318188
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1723",
        "shared_name" : "Outrage",
        "name" : "Outrage",
        "SUID" : 1723,
        "selected" : false
      },
      "position" : {
        "x" : -558.1770134608036,
        "y" : 786.8033324046138
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1719",
        "shared_name" : "Octazooka",
        "name" : "Octazooka",
        "SUID" : 1719,
        "selected" : false
      },
      "position" : {
        "x" : -840.8956719080692,
        "y" : 650.6513701243404
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1715",
        "shared_name" : "Nightmare",
        "name" : "Nightmare",
        "SUID" : 1715,
        "selected" : false
      },
      "position" : {
        "x" : -475.0792961756473,
        "y" : 603.6890593333247
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1711",
        "shared_name" : "Mud-Slap",
        "name" : "Mud-Slap",
        "SUID" : 1711,
        "selected" : false
      },
      "position" : {
        "x" : -736.2382317225223,
        "y" : 667.5240507884029
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1707",
        "shared_name" : "Morning Sun",
        "name" : "Morning Sun",
        "SUID" : 1707,
        "selected" : false
      },
      "position" : {
        "x" : -841.9629326502567,
        "y" : 894.5292998118404
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1703",
        "shared_name" : "Moonlight",
        "name" : "Moonlight",
        "SUID" : 1703,
        "selected" : false
      },
      "position" : {
        "x" : -705.9526177088504,
        "y" : 711.3577910227779
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1699",
        "shared_name" : "Mirror Coat",
        "name" : "Mirror Coat",
        "SUID" : 1699,
        "selected" : false
      },
      "position" : {
        "x" : -676.1706658045536,
        "y" : 597.8254423899654
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1695",
        "shared_name" : "Mind Reader",
        "name" : "Mind Reader",
        "SUID" : 1695,
        "selected" : false
      },
      "position" : {
        "x" : -769.4299736658817,
        "y" : 987.2078610224727
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1691",
        "shared_name" : "Milk Drink",
        "name" : "Milk Drink",
        "SUID" : 1691,
        "selected" : false
      },
      "position" : {
        "x" : -805.5201836268192,
        "y" : 834.8501768870357
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1687",
        "shared_name" : "Metal Claw",
        "name" : "Metal Claw",
        "SUID" : 1687,
        "selected" : false
      },
      "position" : {
        "x" : -475.4162102381473,
        "y" : 704.2789030833247
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1683",
        "shared_name" : "Megahorn",
        "name" : "Megahorn",
        "SUID" : 1683,
        "selected" : false
      },
      "position" : {
        "x" : -760.5956841151004,
        "y" : 826.4084349436763
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1679",
        "shared_name" : "Mean Look",
        "name" : "Mean Look",
        "SUID" : 1679,
        "selected" : false
      },
      "position" : {
        "x" : -561.4579582850223,
        "y" : 995.7447043223384
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1675",
        "shared_name" : "Magnitude",
        "name" : "Magnitude",
        "SUID" : 1675,
        "selected" : false
      },
      "position" : {
        "x" : -801.0266228358036,
        "y" : 730.3333769602779
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1671",
        "shared_name" : "Mach Punch",
        "name" : "Mach Punch",
        "SUID" : 1671,
        "selected" : false
      },
      "position" : {
        "x" : -715.8935967127567,
        "y" : 986.2823754115108
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1667",
        "shared_name" : "Lock-On",
        "name" : "Lock-On",
        "SUID" : 1667,
        "selected" : false
      },
      "position" : {
        "x" : -582.0518303553348,
        "y" : 740.5897856516841
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1663",
        "shared_name" : "Iron Tail",
        "name" : "Iron Tail",
        "SUID" : 1663,
        "selected" : false
      },
      "position" : {
        "x" : -871.5957146326786,
        "y" : 739.7432585520747
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1659",
        "shared_name" : "Icy Wind",
        "name" : "Icy Wind",
        "SUID" : 1659,
        "selected" : false
      },
      "position" : {
        "x" : -463.18397146861605,
        "y" : 867.0465727610591
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1655",
        "shared_name" : "Hidden Power",
        "name" : "Hidden Power",
        "SUID" : 1655,
        "selected" : false
      },
      "position" : {
        "x" : -816.7343559901004,
        "y" : 994.778692798138
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1651",
        "shared_name" : "Heal Bell",
        "name" : "Heal Bell",
        "SUID" : 1651,
        "selected" : false
      },
      "position" : {
        "x" : -738.2477226893192,
        "y" : 946.3253851695064
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1647",
        "shared_name" : "Giga Drain",
        "name" : "Giga Drain",
        "SUID" : 1647,
        "selected" : false
      },
      "position" : {
        "x" : -701.2207451502567,
        "y" : 637.1743193430904
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1643",
        "shared_name" : "Future Sight",
        "name" : "Future Sight",
        "SUID" : 1643,
        "selected" : false
      },
      "position" : {
        "x" : -758.7543450037723,
        "y" : 711.0219755930904
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1639",
        "shared_name" : "Fury Cutter",
        "name" : "Fury Cutter",
        "SUID" : 1639,
        "selected" : false
      },
      "position" : {
        "x" : -741.0178032557254,
        "y" : 1038.8446913523676
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1635",
        "shared_name" : "Frustration",
        "name" : "Frustration",
        "SUID" : 1635,
        "selected" : false
      },
      "position" : {
        "x" : -546.684459749866,
        "y" : 618.067538337231
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1631",
        "shared_name" : "Foresight",
        "name" : "Foresight",
        "SUID" : 1631,
        "selected" : false
      },
      "position" : {
        "x" : -573.2819939295536,
        "y" : 567.4063750071529
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1627",
        "shared_name" : "Flame Wheel",
        "name" : "Flame Wheel",
        "SUID" : 1627,
        "selected" : false
      },
      "position" : {
        "x" : -403.5409660975223,
        "y" : 895.3698302073482
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1623",
        "shared_name" : "Flail",
        "name" : "Flail",
        "SUID" : 1623,
        "selected" : false
      },
      "position" : {
        "x" : -769.3208428065067,
        "y" : 631.5188628001216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1619",
        "shared_name" : "Feint Attack",
        "name" : "Feint Attack",
        "SUID" : 1619,
        "selected" : false
      },
      "position" : {
        "x" : -500.6717034022098,
        "y" : 651.6155119700435
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1615",
        "shared_name" : "False Swipe",
        "name" : "False Swipe",
        "SUID" : 1615,
        "selected" : false
      },
      "position" : {
        "x" : -550.291637484241,
        "y" : 664.4446440501216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1611",
        "shared_name" : "Extreme Speed",
        "name" : "Extreme Speed",
        "SUID" : 1611,
        "selected" : false
      },
      "position" : {
        "x" : -895.4544029871707,
        "y" : 789.4803343577388
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1607",
        "shared_name" : "Endure",
        "name" : "Endure",
        "SUID" : 1607,
        "selected" : false
      },
      "position" : {
        "x" : -700.5994377772098,
        "y" : 907.5020857615474
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1603",
        "shared_name" : "Encore",
        "name" : "Encore",
        "SUID" : 1603,
        "selected" : false
      },
      "position" : {
        "x" : -693.4721184412723,
        "y" : 1040.2433768076899
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1599",
        "shared_name" : "Dynamic Punch",
        "name" : "Dynamic Punch",
        "SUID" : 1599,
        "selected" : false
      },
      "position" : {
        "x" : -525.2586174647098,
        "y" : 571.4264860911372
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1595",
        "shared_name" : "Dragon Breath",
        "name" : "Dragon Breath",
        "SUID" : 1595,
        "selected" : false
      },
      "position" : {
        "x" : -892.2571221033817,
        "y" : 876.8977156443599
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1591",
        "shared_name" : "Detect",
        "name" : "Detect",
        "SUID" : 1591,
        "selected" : false
      },
      "position" : {
        "x" : -525.1478996912723,
        "y" : 961.104949073315
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1587",
        "shared_name" : "Destiny Bond",
        "name" : "Destiny Bond",
        "SUID" : 1587,
        "selected" : false
      },
      "position" : {
        "x" : -749.8094292322879,
        "y" : 897.0190916819575
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1583",
        "shared_name" : "Curse",
        "name" : "Curse",
        "SUID" : 1583,
        "selected" : false
      },
      "position" : {
        "x" : -619.265758577991,
        "y" : 911.9786330027583
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1579",
        "shared_name" : "Crunch",
        "name" : "Crunch",
        "SUID" : 1579,
        "selected" : false
      },
      "position" : {
        "x" : -518.1496086756473,
        "y" : 752.774828986645
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1575",
        "shared_name" : "Cross Chop",
        "name" : "Cross Chop",
        "SUID" : 1575,
        "selected" : false
      },
      "position" : {
        "x" : -482.58485037486605,
        "y" : 1008.7771378321651
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1571",
        "shared_name" : "Cotton Spore",
        "name" : "Cotton Spore",
        "SUID" : 1571,
        "selected" : false
      },
      "position" : {
        "x" : -478.1919670740848,
        "y" : 957.2456122202876
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1567",
        "shared_name" : "Conversion 2",
        "name" : "Conversion 2",
        "SUID" : 1567,
        "selected" : false
      },
      "position" : {
        "x" : -457.3402825037723,
        "y" : 913.5177565379146
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1563",
        "shared_name" : "Charm",
        "name" : "Charm",
        "SUID" : 1563,
        "selected" : false
      },
      "position" : {
        "x" : -490.6908684412723,
        "y" : 799.9086943430904
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1559",
        "shared_name" : "Bone Rush",
        "name" : "Bone Rush",
        "SUID" : 1559,
        "selected" : false
      },
      "position" : {
        "x" : -850.460338656116,
        "y" : 696.2574492259029
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1555",
        "shared_name" : "Belly Drum",
        "name" : "Belly Drum",
        "SUID" : 1555,
        "selected" : false
      },
      "position" : {
        "x" : -620.0449944178348,
        "y" : 601.4266997141841
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1551",
        "shared_name" : "Beat Up",
        "name" : "Beat Up",
        "SUID" : 1551,
        "selected" : false
      },
      "position" : {
        "x" : -588.2148552576786,
        "y" : 867.8626738352779
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1547",
        "shared_name" : "Baton Pass",
        "name" : "Baton Pass",
        "SUID" : 1547,
        "selected" : false
      },
      "position" : {
        "x" : -401.3727532068973,
        "y" : 687.8673125071529
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1543",
        "shared_name" : "Attract",
        "name" : "Attract",
        "SUID" : 1543,
        "selected" : false
      },
      "position" : {
        "x" : -430.31812674205355,
        "y" : 727.9448576731685
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1539",
        "shared_name" : "Ancient Power",
        "name" : "Ancient Power",
        "SUID" : 1539,
        "selected" : false
      },
      "position" : {
        "x" : -652.644176546741,
        "y" : 687.5582915110591
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1535",
        "shared_name" : "Aeroblast",
        "name" : "Aeroblast",
        "SUID" : 1535,
        "selected" : false
      },
      "position" : {
        "x" : -528.9672356287723,
        "y" : 705.0762358469966
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1533",
        "shared_name" : "gen2",
        "name" : "gen2",
        "SUID" : 1533,
        "selected" : false
      },
      "position" : {
        "x" : -636.5845451990848,
        "y" : 804.0465727610591
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1529",
        "shared_name" : "Wrap",
        "name" : "Wrap",
        "SUID" : 1529,
        "selected" : false
      },
      "position" : {
        "x" : -811.9606476465946,
        "y" : -750.1458520131108
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1525",
        "shared_name" : "Withdraw",
        "name" : "Withdraw",
        "SUID" : 1525,
        "selected" : false
      },
      "position" : {
        "x" : -672.5039635340457,
        "y" : -588.7267464833257
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1521",
        "shared_name" : "Wing Attack",
        "name" : "Wing Attack",
        "SUID" : 1521,
        "selected" : false
      },
      "position" : {
        "x" : -675.194324556995,
        "y" : -688.6810082631108
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1517",
        "shared_name" : "Whirlwind",
        "name" : "Whirlwind",
        "SUID" : 1517,
        "selected" : false
      },
      "position" : {
        "x" : -368.3218727747684,
        "y" : -767.0395135121342
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1513",
        "shared_name" : "Waterfall",
        "name" : "Waterfall",
        "SUID" : 1513,
        "selected" : false
      },
      "position" : {
        "x" : -465.3907509485965,
        "y" : -525.9143456654546
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1509",
        "shared_name" : "Water Gun",
        "name" : "Water Gun",
        "SUID" : 1509,
        "selected" : false
      },
      "position" : {
        "x" : -291.80740744273714,
        "y" : -655.7535523610112
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1505",
        "shared_name" : "Vise Grip",
        "name" : "Vise Grip",
        "SUID" : 1505,
        "selected" : false
      },
      "position" : {
        "x" : -393.10150534312777,
        "y" : -427.49979488420456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1501",
        "shared_name" : "Vine Whip",
        "name" : "Vine Whip",
        "SUID" : 1501,
        "selected" : false
      },
      "position" : {
        "x" : -895.4544029871707,
        "y" : -496.49076168107956
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1497",
        "shared_name" : "Twineedle",
        "name" : "Twineedle",
        "SUID" : 1497,
        "selected" : false
      },
      "position" : {
        "x" : -479.65237814586214,
        "y" : -639.6959628300664
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1493",
        "shared_name" : "Tri Attack",
        "name" : "Tri Attack",
        "SUID" : 1493,
        "selected" : false
      },
      "position" : {
        "x" : -460.05646139781527,
        "y" : -770.1458825306889
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1489",
        "shared_name" : "Transform",
        "name" : "Transform",
        "SUID" : 1489,
        "selected" : false
      },
      "position" : {
        "x" : -585.7458840052371,
        "y" : -306.90970699357956
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1485",
        "shared_name" : "Toxic",
        "name" : "Toxic",
        "SUID" : 1485,
        "selected" : false
      },
      "position" : {
        "x" : -460.9462624232059,
        "y" : -720.3165902333257
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1481",
        "shared_name" : "Thunderbolt",
        "name" : "Thunderbolt",
        "SUID" : 1481,
        "selected" : false
      },
      "position" : {
        "x" : -373.41974264781527,
        "y" : -467.6766137318608
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1477",
        "shared_name" : "Thunder Wave",
        "name" : "Thunder Wave",
        "SUID" : 1477,
        "selected" : false
      },
      "position" : {
        "x" : -753.3488712946659,
        "y" : -639.3476981358525
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1473",
        "shared_name" : "Thunder Shock",
        "name" : "Thunder Shock",
        "SUID" : 1473,
        "selected" : false
      },
      "position" : {
        "x" : -562.6424141566043,
        "y" : -797.2826470570561
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1469",
        "shared_name" : "Thunder Punch",
        "name" : "Thunder Punch",
        "SUID" : 1469,
        "selected" : false
      },
      "position" : {
        "x" : -483.2027626673465,
        "y" : -575.7915887074467
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1465",
        "shared_name" : "Thunder",
        "name" : "Thunder",
        "SUID" : 1465,
        "selected" : false
      },
      "position" : {
        "x" : -505.8381081263309,
        "y" : -378.7060784535405
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1461",
        "shared_name" : "Thrash",
        "name" : "Thrash",
        "SUID" : 1461,
        "selected" : false
      },
      "position" : {
        "x" : -443.359867159534,
        "y" : -415.9482201771733
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1457",
        "shared_name" : "Teleport",
        "name" : "Teleport",
        "SUID" : 1457,
        "selected" : false
      },
      "position" : {
        "x" : -461.64398581187777,
        "y" : -473.3414849476811
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1453",
        "shared_name" : "Take Down",
        "name" : "Take Down",
        "SUID" : 1453,
        "selected" : false
      },
      "position" : {
        "x" : -516.4122353235965,
        "y" : -292.99207393693894
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1449",
        "shared_name" : "Tail Whip",
        "name" : "Tail Whip",
        "SUID" : 1449,
        "selected" : false
      },
      "position" : {
        "x" : -342.00677878062777,
        "y" : -304.5248803334233
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1445",
        "shared_name" : "Tackle",
        "name" : "Tackle",
        "SUID" : 1445,
        "selected" : false
      },
      "position" : {
        "x" : -726.1765366236453,
        "y" : -486.294823570728
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1441",
        "shared_name" : "Swords Dance",
        "name" : "Swords Dance",
        "SUID" : 1441,
        "selected" : false
      },
      "position" : {
        "x" : -648.6267281214481,
        "y" : -254.7121056752202
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1437",
        "shared_name" : "Swift",
        "name" : "Swift",
        "SUID" : 1437,
        "selected" : false
      },
      "position" : {
        "x" : -839.0754852930789,
        "y" : -580.242764397144
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1433",
        "shared_name" : "Surf",
        "name" : "Surf",
        "SUID" : 1433,
        "selected" : false
      },
      "position" : {
        "x" : -830.8199959437137,
        "y" : -629.3332937793729
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1429",
        "shared_name" : "Supersonic",
        "name" : "Supersonic",
        "SUID" : 1429,
        "selected" : false
      },
      "position" : {
        "x" : -281.02191549937777,
        "y" : -533.2935189442632
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1425",
        "shared_name" : "Super Fang",
        "name" : "Super Fang",
        "SUID" : 1425,
        "selected" : false
      },
      "position" : {
        "x" : -373.4980202357059,
        "y" : -718.6714486317632
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1421",
        "shared_name" : "Substitute",
        "name" : "Substitute",
        "SUID" : 1421,
        "selected" : false
      },
      "position" : {
        "x" : -835.687934939075,
        "y" : -341.4401635365483
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1417",
        "shared_name" : "Submission",
        "name" : "Submission",
        "SUID" : 1417,
        "selected" : false
      },
      "position" : {
        "x" : -641.8438301722293,
        "y" : -451.7867211537358
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1413",
        "shared_name" : "Stun Spore",
        "name" : "Stun Spore",
        "SUID" : 1413,
        "selected" : false
      },
      "position" : {
        "x" : -559.6746712366825,
        "y" : -270.55640499162644
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1409",
        "shared_name" : "Struggle",
        "name" : "Struggle",
        "SUID" : 1409,
        "selected" : false
      },
      "position" : {
        "x" : -642.1577339808231,
        "y" : -833.0509118275639
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1405",
        "shared_name" : "String Shot",
        "name" : "String Shot",
        "SUID" : 1405,
        "selected" : false
      },
      "position" : {
        "x" : -279.83246237437777,
        "y" : -403.38855831193894
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1401",
        "shared_name" : "Strength",
        "name" : "Strength",
        "SUID" : 1401,
        "selected" : false
      },
      "position" : {
        "x" : -671.905750338245,
        "y" : -735.5436562733647
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1397",
        "shared_name" : "Stomp",
        "name" : "Stomp",
        "SUID" : 1397,
        "selected" : false
      },
      "position" : {
        "x" : -638.6801186243778,
        "y" : -555.0270470814702
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1393",
        "shared_name" : "Spore",
        "name" : "Spore",
        "SUID" : 1393,
        "selected" : false
      },
      "position" : {
        "x" : -701.3900032679325,
        "y" : -817.2191704945561
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1389",
        "shared_name" : "Splash",
        "name" : "Splash",
        "SUID" : 1389,
        "selected" : false
      },
      "position" : {
        "x" : -415.21649557750277,
        "y" : -588.4758996205327
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1385",
        "shared_name" : "Spike Cannon",
        "name" : "Spike Cannon",
        "SUID" : 1385,
        "selected" : false
      },
      "position" : {
        "x" : -804.5980435053592,
        "y" : -495.3121270375249
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1381",
        "shared_name" : "Sonic Boom",
        "name" : "Sonic Boom",
        "SUID" : 1381,
        "selected" : false
      },
      "position" : {
        "x" : -716.1694107691532,
        "y" : -664.5682496266362
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1377",
        "shared_name" : "Solar Beam",
        "name" : "Solar Beam",
        "SUID" : 1377,
        "selected" : false
      },
      "position" : {
        "x" : -319.6214638392215,
        "y" : -484.6883324818608
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1373",
        "shared_name" : "Soft-Boiled",
        "name" : "Soft-Boiled",
        "SUID" : 1373,
        "selected" : false
      },
      "position" : {
        "x" : -722.666133944202,
        "y" : -247.7002648549077
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1369",
        "shared_name" : "Smokescreen",
        "name" : "Smokescreen",
        "SUID" : 1369,
        "selected" : false
      },
      "position" : {
        "x" : -419.38968283336214,
        "y" : -800.2867058949467
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1365",
        "shared_name" : "Smog",
        "name" : "Smog",
        "SUID" : 1365,
        "selected" : false
      },
      "position" : {
        "x" : -549.7609444300418,
        "y" : -709.5631646351811
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1361",
        "shared_name" : "Sludge",
        "name" : "Sludge",
        "SUID" : 1361,
        "selected" : false
      },
      "position" : {
        "x" : -339.735355440784,
        "y" : -624.0485643582341
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1357",
        "shared_name" : "Sleep Powder",
        "name" : "Sleep Powder",
        "SUID" : 1357,
        "selected" : false
      },
      "position" : {
        "x" : -594.1102638880496,
        "y" : -389.88887874650925
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1353",
        "shared_name" : "Slash",
        "name" : "Slash",
        "SUID" : 1353,
        "selected" : false
      },
      "position" : {
        "x" : -627.2676430384403,
        "y" : -310.08524410295456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1349",
        "shared_name" : "Slam",
        "name" : "Slam",
        "SUID" : 1349,
        "selected" : false
      },
      "position" : {
        "x" : -847.5222893397098,
        "y" : -688.6477708058354
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1345",
        "shared_name" : "Sky Attack",
        "name" : "Sky Attack",
        "SUID" : 1345,
        "selected" : false
      },
      "position" : {
        "x" : -501.46417624156527,
        "y" : -485.746483726978
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1341",
        "shared_name" : "Skull Bash",
        "name" : "Skull Bash",
        "SUID" : 1341,
        "selected" : false
      },
      "position" : {
        "x" : -436.441898409534,
        "y" : -298.23746578264206
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1337",
        "shared_name" : "Sing",
        "name" : "Sing",
        "SUID" : 1337,
        "selected" : false
      },
      "position" : {
        "x" : -308.88629538219027,
        "y" : -348.2406701283452
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1333",
        "shared_name" : "Sharpen",
        "name" : "Sharpen",
        "SUID" : 1333,
        "selected" : false
      },
      "position" : {
        "x" : -520.5731545130496,
        "y" : -419.7820061879155
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1329",
        "shared_name" : "Self-Destruct",
        "name" : "Self-Destruct",
        "SUID" : 1329,
        "selected" : false
      },
      "position" : {
        "x" : -796.879476610828,
        "y" : -704.5956887440678
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1325",
        "shared_name" : "Seismic Toss",
        "name" : "Seismic Toss",
        "SUID" : 1325,
        "selected" : false
      },
      "position" : {
        "x" : -707.9759178797489,
        "y" : -573.2445496754643
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1321",
        "shared_name" : "Screech",
        "name" : "Screech",
        "SUID" : 1321,
        "selected" : false
      },
      "position" : {
        "x" : -836.2974701563602,
        "y" : -433.61043636369675
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1317",
        "shared_name" : "Scratch",
        "name" : "Scratch",
        "SUID" : 1317,
        "selected" : false
      },
      "position" : {
        "x" : -355.91839987437777,
        "y" : -556.0848473744389
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1313",
        "shared_name" : "Sand Attack",
        "name" : "Sand Attack",
        "SUID" : 1313,
        "selected" : false
      },
      "position" : {
        "x" : -759.7444449106937,
        "y" : -437.9587334828374
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1309",
        "shared_name" : "Rolling Kick",
        "name" : "Rolling Kick",
        "SUID" : 1309,
        "selected" : false
      },
      "position" : {
        "x" : -636.5217629114871,
        "y" : -499.32943050432175
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1305",
        "shared_name" : "Rock Throw",
        "name" : "Rock Throw",
        "SUID" : 1305,
        "selected" : false
      },
      "position" : {
        "x" : -864.1669655482059,
        "y" : -385.0144280629155
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1301",
        "shared_name" : "Rock Slide",
        "name" : "Rock Slide",
        "SUID" : 1301,
        "selected" : false
      },
      "position" : {
        "x" : -868.3326683680301,
        "y" : -538.0806054310796
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1297",
        "shared_name" : "Roar",
        "name" : "Roar",
        "SUID" : 1297,
        "selected" : false
      },
      "position" : {
        "x" : -421.11737448375277,
        "y" : -700.1685647206303
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1293",
        "shared_name" : "Rest",
        "name" : "Rest",
        "SUID" : 1293,
        "selected" : false
      },
      "position" : {
        "x" : -464.98688131969027,
        "y" : -677.1184777455327
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1289",
        "shared_name" : "Reflect",
        "name" : "Reflect",
        "SUID" : 1289,
        "selected" : false
      },
      "position" : {
        "x" : -507.6248818079715,
        "y" : -789.5749291615483
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1285",
        "shared_name" : "Recover",
        "name" : "Recover",
        "SUID" : 1285,
        "selected" : false
      },
      "position" : {
        "x" : -463.86380392711214,
        "y" : -378.04358760881394
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1281",
        "shared_name" : "Razor Wind",
        "name" : "Razor Wind",
        "SUID" : 1281,
        "selected" : false
      },
      "position" : {
        "x" : -501.001224581409,
        "y" : -736.4619073109624
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1277",
        "shared_name" : "Razor Leaf",
        "name" : "Razor Leaf",
        "SUID" : 1277,
        "selected" : false
      },
      "position" : {
        "x" : -849.120365206409,
        "y" : -481.6797417836186
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1273",
        "shared_name" : "Rage",
        "name" : "Rage",
        "SUID" : 1273,
        "selected" : false
      },
      "position" : {
        "x" : -438.31500631969027,
        "y" : -557.8137597279546
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1269",
        "shared_name" : "Quick Attack",
        "name" : "Quick Attack",
        "SUID" : 1269,
        "selected" : false
      },
      "position" : {
        "x" : -637.6576424280887,
        "y" : -629.4249514775273
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1265",
        "shared_name" : "Psywave",
        "name" : "Psywave",
        "SUID" : 1265,
        "selected" : false
      },
      "position" : {
        "x" : -451.3453102747684,
        "y" : -606.5515431599614
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1261",
        "shared_name" : "Psychic",
        "name" : "Psychic",
        "SUID" : 1261,
        "selected" : false
      },
      "position" : {
        "x" : -316.92276388804964,
        "y" : -717.2367028431889
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1257",
        "shared_name" : "Psybeam",
        "name" : "Psybeam",
        "SUID" : 1257,
        "selected" : false
      },
      "position" : {
        "x" : -753.7854939142948,
        "y" : -284.6913842396733
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1253",
        "shared_name" : "Pound",
        "name" : "Pound",
        "SUID" : 1253,
        "selected" : false
      },
      "position" : {
        "x" : -761.1563568751102,
        "y" : -493.52442256975144
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1249",
        "shared_name" : "Poison Sting",
        "name" : "Poison Sting",
        "SUID" : 1249,
        "selected" : false
      },
      "position" : {
        "x" : -363.5547829310184,
        "y" : -509.6801537709233
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1245",
        "shared_name" : "Poison Powder",
        "name" : "Poison Powder",
        "SUID" : 1245,
        "selected" : false
      },
      "position" : {
        "x" : -744.357519213367,
        "y" : -341.77787105607956
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1241",
        "shared_name" : "Poison Gas",
        "name" : "Poison Gas",
        "SUID" : 1241,
        "selected" : false
      },
      "position" : {
        "x" : -673.4425316492801,
        "y" : -644.3104571537968
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1237",
        "shared_name" : "Pin Missile",
        "name" : "Pin Missile",
        "SUID" : 1237,
        "selected" : false
      },
      "position" : {
        "x" : -420.80667502086214,
        "y" : -244.02307979631394
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1233",
        "shared_name" : "Petal Dance",
        "name" : "Petal Dance",
        "SUID" : 1233,
        "selected" : false
      },
      "position" : {
        "x" : -633.8283272425418,
        "y" : -694.8899926381108
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1229",
        "shared_name" : "Peck",
        "name" : "Peck",
        "SUID" : 1229,
        "selected" : false
      },
      "position" : {
        "x" : -751.0469952265506,
        "y" : -685.401081963062
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1225",
        "shared_name" : "Pay Day",
        "name" : "Pay Day",
        "SUID" : 1225,
        "selected" : false
      },
      "position" : {
        "x" : -795.7612000147586,
        "y" : -453.61463253068894
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1221",
        "shared_name" : "Night Shade",
        "name" : "Night Shade",
        "SUID" : 1221,
        "selected" : false
      },
      "position" : {
        "x" : -590.9803200403934,
        "y" : -459.17118160295456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1217",
        "shared_name" : "Mist",
        "name" : "Mist",
        "SUID" : 1217,
        "selected" : false
      },
      "position" : {
        "x" : -337.3031044642215,
        "y" : -674.1382760243413
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1213",
        "shared_name" : "Mirror Move",
        "name" : "Mirror Move",
        "SUID" : 1213,
        "selected" : false
      },
      "position" : {
        "x" : -386.97476584117464,
        "y" : -627.0106248097417
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1209",
        "shared_name" : "Minimize",
        "name" : "Minimize",
        "SUID" : 1209,
        "selected" : false
      },
      "position" : {
        "x" : -682.1261406580692,
        "y" : -222.61710445451706
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1205",
        "shared_name" : "Mimic",
        "name" : "Mimic",
        "SUID" : 1205,
        "selected" : false
      },
      "position" : {
        "x" : -271.2659950892215,
        "y" : -611.5870351033208
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1201",
        "shared_name" : "Metronome",
        "name" : "Metronome",
        "SUID" : 1201,
        "selected" : false
      },
      "position" : {
        "x" : -382.3375282923465,
        "y" : -673.5187882618901
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1197",
        "shared_name" : "Mega Punch",
        "name" : "Mega Punch",
        "SUID" : 1197,
        "selected" : false
      },
      "position" : {
        "x" : -534.9927406946903,
        "y" : -464.0916527943608
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1193",
        "shared_name" : "Mega Kick",
        "name" : "Mega Kick",
        "SUID" : 1193,
        "selected" : false
      },
      "position" : {
        "x" : -680.8230400721317,
        "y" : -478.61621944475144
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1189",
        "shared_name" : "Mega Drain",
        "name" : "Mega Drain",
        "SUID" : 1189,
        "selected" : false
      },
      "position" : {
        "x" : -713.6262360255008,
        "y" : -306.74427120256394
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1185",
        "shared_name" : "Meditate",
        "name" : "Meditate",
        "SUID" : 1185,
        "selected" : false
      },
      "position" : {
        "x" : -518.9727211634403,
        "y" : -251.6575402455327
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1181",
        "shared_name" : "Low Kick",
        "name" : "Low Kick",
        "SUID" : 1181,
        "selected" : false
      },
      "position" : {
        "x" : -551.1847267786746,
        "y" : -373.4974145131108
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1177",
        "shared_name" : "Lovely Kiss",
        "name" : "Lovely Kiss",
        "SUID" : 1177,
        "selected" : false
      },
      "position" : {
        "x" : -769.4767132441287,
        "y" : -537.5050210194585
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1173",
        "shared_name" : "Light Screen",
        "name" : "Light Screen",
        "SUID" : 1173,
        "selected" : false
      },
      "position" : {
        "x" : -585.014408175159,
        "y" : -749.2647866444585
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1169",
        "shared_name" : "Lick",
        "name" : "Lick",
        "SUID" : 1169,
        "selected" : false
      },
      "position" : {
        "x" : -756.6701450983768,
        "y" : -788.9467248158452
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1165",
        "shared_name" : "Leer",
        "name" : "Leer",
        "SUID" : 1165,
        "selected" : false
      },
      "position" : {
        "x" : -798.4141350428348,
        "y" : -657.8697613911626
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1161",
        "shared_name" : "Leech Seed",
        "name" : "Leech Seed",
        "SUID" : 1161,
        "selected" : false
      },
      "position" : {
        "x" : -801.7447434107547,
        "y" : -288.2755822377202
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1157",
        "shared_name" : "Leech Life",
        "name" : "Leech Life",
        "SUID" : 1157,
        "selected" : false
      },
      "position" : {
        "x" : -884.0324364344364,
        "y" : -442.2057580189702
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1153",
        "shared_name" : "Kinesis",
        "name" : "Kinesis",
        "SUID" : 1153,
        "selected" : false
      },
      "position" : {
        "x" : -713.4282074610477,
        "y" : -618.6720380024907
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1149",
        "shared_name" : "Karate Chop",
        "name" : "Karate Chop",
        "SUID" : 1149,
        "selected" : false
      },
      "position" : {
        "x" : -611.6674538294559,
        "y" : -791.9261864857671
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1145",
        "shared_name" : "Jump Kick",
        "name" : "Jump Kick",
        "SUID" : 1145,
        "selected" : false
      },
      "position" : {
        "x" : -625.6064949671512,
        "y" : -205.78531734514206
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1141",
        "shared_name" : "Ice Punch",
        "name" : "Ice Punch",
        "SUID" : 1141,
        "selected" : false
      },
      "position" : {
        "x" : -565.6073647181278,
        "y" : -591.5033234791753
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1137",
        "shared_name" : "Ice Beam",
        "name" : "Ice Beam",
        "SUID" : 1137,
        "selected" : false
      },
      "position" : {
        "x" : -608.5428658167606,
        "y" : -657.7271336750981
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1133",
        "shared_name" : "Hypnosis",
        "name" : "Hypnosis",
        "SUID" : 1133,
        "selected" : false
      },
      "position" : {
        "x" : -533.1536751429325,
        "y" : -837.5593957142827
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1129",
        "shared_name" : "Hyper Fang",
        "name" : "Hyper Fang",
        "SUID" : 1129,
        "selected" : false
      },
      "position" : {
        "x" : -528.4125557581668,
        "y" : -202.9026574330327
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1125",
        "shared_name" : "Hyper Beam",
        "name" : "Hyper Beam",
        "SUID" : 1125,
        "selected" : false
      },
      "position" : {
        "x" : -606.8359566370731,
        "y" : -261.04325191545456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1121",
        "shared_name" : "Hydro Pump",
        "name" : "Hydro Pump",
        "SUID" : 1121,
        "selected" : false
      },
      "position" : {
        "x" : -575.0968514124637,
        "y" : -222.9472130970952
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1117",
        "shared_name" : "Horn Drill",
        "name" : "Horn Drill",
        "SUID" : 1117,
        "selected" : false
      },
      "position" : {
        "x" : -714.1613617579227,
        "y" : -716.8011788563725
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1113",
        "shared_name" : "Horn Attack",
        "name" : "Horn Attack",
        "SUID" : 1113,
        "selected" : false
      },
      "position" : {
        "x" : -592.0213356653934,
        "y" : -701.1877145009038
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1109",
        "shared_name" : "High Jump Kick",
        "name" : "High Jump Kick",
        "SUID" : 1109,
        "selected" : false
      },
      "position" : {
        "x" : -748.6868363062625,
        "y" : -585.7874116139409
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1105",
        "shared_name" : "Headbutt",
        "name" : "Headbutt",
        "SUID" : 1105,
        "selected" : false
      },
      "position" : {
        "x" : -675.8803139368778,
        "y" : -287.1174096302983
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1101",
        "shared_name" : "Haze",
        "name" : "Haze",
        "SUID" : 1101,
        "selected" : false
      },
      "position" : {
        "x" : -767.3587675730472,
        "y" : -389.7179955677983
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1097",
        "shared_name" : "Harden",
        "name" : "Harden",
        "SUID" : 1097,
        "selected" : false
      },
      "position" : {
        "x" : -407.72879416148714,
        "y" : -332.4191369252202
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1093",
        "shared_name" : "Gust",
        "name" : "Gust",
        "SUID" : 1093,
        "selected" : false
      },
      "position" : {
        "x" : -328.11673361461214,
        "y" : -393.61161129045456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1089",
        "shared_name" : "Guillotine",
        "name" : "Guillotine",
        "SUID" : 1089,
        "selected" : false
      },
      "position" : {
        "x" : -668.0323982874637,
        "y" : -384.8157738881108
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1085",
        "shared_name" : "Growth",
        "name" : "Growth",
        "SUID" : 1085,
        "selected" : false
      },
      "position" : {
        "x" : -496.79425436656527,
        "y" : -336.64908687639206
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1081",
        "shared_name" : "Growl",
        "name" : "Growl",
        "SUID" : 1081,
        "selected" : false
      },
      "position" : {
        "x" : -725.9586029688602,
        "y" : -394.819725914478
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1077",
        "shared_name" : "Glare",
        "name" : "Glare",
        "SUID" : 1077,
        "selected" : false
      },
      "position" : {
        "x" : -627.4628487269168,
        "y" : -412.2594994740483
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1073",
        "shared_name" : "Fury Swipes",
        "name" : "Fury Swipes",
        "SUID" : 1073,
        "selected" : false
      },
      "position" : {
        "x" : -470.6692848841434,
        "y" : -224.57218257951706
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1069",
        "shared_name" : "Fury Attack",
        "name" : "Fury Attack",
        "SUID" : 1069,
        "selected" : false
      },
      "position" : {
        "x" : -890.4119682947879,
        "y" : -584.4578484730717
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1065",
        "shared_name" : "Focus Energy",
        "name" : "Focus Energy",
        "SUID" : 1065,
        "selected" : false
      },
      "position" : {
        "x" : -551.7830849329715,
        "y" : -665.6675423817632
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1061",
        "shared_name" : "Fly",
        "name" : "Fly",
        "SUID" : 1061,
        "selected" : false
      },
      "position" : {
        "x" : -670.2326622645145,
        "y" : -335.66825191545456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1057",
        "shared_name" : "Flash",
        "name" : "Flash",
        "SUID" : 1057,
        "selected" : false
      },
      "position" : {
        "x" : -519.8976479212528,
        "y" : -595.065388603687
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1053",
        "shared_name" : "Flamethrower",
        "name" : "Flamethrower",
        "SUID" : 1053,
        "selected" : false
      },
      "position" : {
        "x" : -708.9726906458621,
        "y" : -359.7868127064702
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1049",
        "shared_name" : "Fissure",
        "name" : "Fissure",
        "SUID" : 1049,
        "selected" : false
      },
      "position" : {
        "x" : -413.57538229625277,
        "y" : -377.24857418107956
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1045",
        "shared_name" : "Fire Spin",
        "name" : "Fire Spin",
        "SUID" : 1045,
        "selected" : false
      },
      "position" : {
        "x" : -480.01715475719027,
        "y" : -436.6567925648686
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1041",
        "shared_name" : "Fire Punch",
        "name" : "Fire Punch",
        "SUID" : 1041,
        "selected" : false
      },
      "position" : {
        "x" : -681.8518334070926,
        "y" : -428.93131343889206
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1037",
        "shared_name" : "Fire Blast",
        "name" : "Fire Blast",
        "SUID" : 1037,
        "selected" : false
      },
      "position" : {
        "x" : -562.3617592493778,
        "y" : -424.7091607289311
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1033",
        "shared_name" : "Explosion",
        "name" : "Explosion",
        "SUID" : 1033,
        "selected" : false
      },
      "position" : {
        "x" : -366.49466330211214,
        "y" : -348.1260766224858
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1029",
        "shared_name" : "Ember",
        "name" : "Ember",
        "SUID" : 1029,
        "selected" : false
      },
      "position" : {
        "x" : -399.97354513804964,
        "y" : -532.2975243763921
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1025",
        "shared_name" : "Egg Bomb",
        "name" : "Egg Bomb",
        "SUID" : 1025,
        "selected" : false
      },
      "position" : {
        "x" : -455.4915505091434,
        "y" : -336.4952172474858
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1021",
        "shared_name" : "Earthquake",
        "name" : "Earthquake",
        "SUID" : 1021,
        "selected" : false
      },
      "position" : {
        "x" : -720.1419258753543,
        "y" : -440.71988765764206
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1017",
        "shared_name" : "Drill Peck",
        "name" : "Drill Peck",
        "SUID" : 1017,
        "selected" : false
      },
      "position" : {
        "x" : -343.46210104625277,
        "y" : -435.125145836353
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1013",
        "shared_name" : "Dream Eater",
        "name" : "Dream Eater",
        "SUID" : 1013,
        "selected" : false
      },
      "position" : {
        "x" : -289.82083517711214,
        "y" : -450.63098995256394
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1009",
        "shared_name" : "Dragon Rage",
        "name" : "Dragon Rage",
        "SUID" : 1009,
        "selected" : false
      },
      "position" : {
        "x" : -823.4928856531864,
        "y" : -533.4522027211186
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1005",
        "shared_name" : "Double-Edge",
        "name" : "Double-Edge",
        "SUID" : 1005,
        "selected" : false
      },
      "position" : {
        "x" : -879.0027733484989,
        "y" : -637.3359150128362
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1001",
        "shared_name" : "Double Team",
        "name" : "Double Team",
        "SUID" : 1001,
        "selected" : false
      },
      "position" : {
        "x" : -674.1863518397098,
        "y" : -530.9153527455327
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "997",
        "shared_name" : "Double Slap",
        "name" : "Double Slap",
        "SUID" : 997,
        "selected" : false
      },
      "position" : {
        "x" : -423.2967568079715,
        "y" : -499.7957238392827
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "993",
        "shared_name" : "Double Kick",
        "name" : "Double Kick",
        "SUID" : 993,
        "selected" : false
      },
      "position" : {
        "x" : -320.98431784312777,
        "y" : -531.2373666005132
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "989",
        "shared_name" : "Dizzy Punch",
        "name" : "Dizzy Punch",
        "SUID" : 989,
        "selected" : false
      },
      "position" : {
        "x" : -540.3362770716434,
        "y" : -750.1148232655522
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "985",
        "shared_name" : "Disable",
        "name" : "Disable",
        "SUID" : 985,
        "selected" : false
      },
      "position" : {
        "x" : -422.0330544153934,
        "y" : -456.6612481312749
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "981",
        "shared_name" : "Dig",
        "name" : "Dig",
        "SUID" : 981,
        "selected" : false
      },
      "position" : {
        "x" : -787.4832783381229,
        "y" : -339.2992943959233
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "977",
        "shared_name" : "Defense Curl",
        "name" : "Defense Curl",
        "SUID" : 977,
        "selected" : false
      },
      "position" : {
        "x" : -247.85074240367464,
        "y" : -560.8807458119389
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "973",
        "shared_name" : "Cut",
        "name" : "Cut",
        "SUID" : 973,
        "selected" : false
      },
      "position" : {
        "x" : -594.6297188441043,
        "y" : -345.5719689564702
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "969",
        "shared_name" : "Crabhammer",
        "name" : "Crabhammer",
        "SUID" : 969,
        "selected" : false
      },
      "position" : {
        "x" : -375.7764626185184,
        "y" : -588.2631730275151
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "965",
        "shared_name" : "Counter",
        "name" : "Counter",
        "SUID" : 965,
        "selected" : false
      },
      "position" : {
        "x" : -710.3373680750614,
        "y" : -763.2104882435796
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "961",
        "shared_name" : "Conversion",
        "name" : "Conversion",
        "SUID" : 961,
        "selected" : false
      },
      "position" : {
        "x" : -615.5348702112918,
        "y" : -594.2745255665776
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "957",
        "shared_name" : "Constrict",
        "name" : "Constrict",
        "SUID" : 957,
        "selected" : false
      },
      "position" : {
        "x" : -423.9883766810184,
        "y" : -647.1882466511723
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "953",
        "shared_name" : "Confusion",
        "name" : "Confusion",
        "SUID" : 953,
        "selected" : false
      },
      "position" : {
        "x" : -661.0440712610965,
        "y" : -782.6010827260014
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "949",
        "shared_name" : "Confuse Ray",
        "name" : "Confuse Ray",
        "SUID" : 949,
        "selected" : false
      },
      "position" : {
        "x" : -312.30572897594027,
        "y" : -589.5046509938237
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "945",
        "shared_name" : "Comet Punch",
        "name" : "Comet Punch",
        "SUID" : 945,
        "selected" : false
      },
      "position" : {
        "x" : -252.57657248179964,
        "y" : -480.9006585316655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "941",
        "shared_name" : "Clamp",
        "name" : "Clamp",
        "SUID" : 941,
        "selected" : false
      },
      "position" : {
        "x" : -784.6026850382572,
        "y" : -612.1577004628178
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "937",
        "shared_name" : "Bubble Beam",
        "name" : "Bubble Beam",
        "SUID" : 937,
        "selected" : false
      },
      "position" : {
        "x" : -575.8859291712528,
        "y" : -633.6833440499303
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "933",
        "shared_name" : "Bubble",
        "name" : "Bubble",
        "SUID" : 933,
        "selected" : false
      },
      "position" : {
        "x" : -808.920902315784,
        "y" : -393.6832207875249
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "929",
        "shared_name" : "Bonemerang",
        "name" : "Bonemerang",
        "SUID" : 929,
        "selected" : false
      },
      "position" : {
        "x" : -722.7531548182254,
        "y" : -531.7270364003178
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "925",
        "shared_name" : "Bone Club",
        "name" : "Bone Club",
        "SUID" : 925,
        "selected" : false
      },
      "position" : {
        "x" : -371.79547506969027,
        "y" : -391.7731255726811
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "921",
        "shared_name" : "Body Slam",
        "name" : "Body Slam",
        "SUID" : 921,
        "selected" : false
      },
      "position" : {
        "x" : -758.7151833216434,
        "y" : -738.3741234974858
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "917",
        "shared_name" : "Blizzard",
        "name" : "Blizzard",
        "SUID" : 917,
        "selected" : false
      },
      "position" : {
        "x" : -507.40008932750277,
        "y" : -691.8732384877202
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "913",
        "shared_name" : "Bite",
        "name" : "Bite",
        "SUID" : 913,
        "selected" : false
      },
      "position" : {
        "x" : -475.0010719935184,
        "y" : -825.9253777699467
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "909",
        "shared_name" : "Bind",
        "name" : "Bind",
        "SUID" : 909,
        "selected" : false
      },
      "position" : {
        "x" : -516.3128700892215,
        "y" : -537.103531761646
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "905",
        "shared_name" : "Bide",
        "name" : "Bide",
        "SUID" : 905,
        "selected" : false
      },
      "position" : {
        "x" : -546.5233498255496,
        "y" : -323.88724605607956
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "901",
        "shared_name" : "Barrier",
        "name" : "Barrier",
        "SUID" : 901,
        "selected" : false
      },
      "position" : {
        "x" : -418.96088034312777,
        "y" : -746.6082467274663
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "897",
        "shared_name" : "Barrage",
        "name" : "Barrage",
        "SUID" : 897,
        "selected" : false
      },
      "position" : {
        "x" : -470.7239723841434,
        "y" : -273.61658565568894
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "893",
        "shared_name" : "Aurora Beam",
        "name" : "Aurora Beam",
        "SUID" : 893,
        "selected" : false
      },
      "position" : {
        "x" : -387.12897116344027,
        "y" : -280.9495324330327
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "889",
        "shared_name" : "Amnesia",
        "name" : "Amnesia",
        "SUID" : 889,
        "selected" : false
      },
      "position" : {
        "x" : -517.3915749232059,
        "y" : -636.0897297101018
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "885",
        "shared_name" : "Agility",
        "name" : "Agility",
        "SUID" : 885,
        "selected" : false
      },
      "position" : {
        "x" : -626.1856575648075,
        "y" : -744.1822671132085
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "881",
        "shared_name" : "Acid Armor",
        "name" : "Acid Armor",
        "SUID" : 881,
        "selected" : false
      },
      "position" : {
        "x" : -797.0459156672244,
        "y" : -571.5196274952885
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "877",
        "shared_name" : "Acid",
        "name" : "Acid",
        "SUID" : 877,
        "selected" : false
      },
      "position" : {
        "x" : -633.5700264612918,
        "y" : -359.07483760881394
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "873",
        "shared_name" : "Absorb",
        "name" : "Absorb",
        "SUID" : 873,
        "selected" : false
      },
      "position" : {
        "x" : -590.5576363245731,
        "y" : -837.6981286244389
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "871",
        "shared_name" : "gen1",
        "name" : "gen1",
        "SUID" : 871,
        "selected" : false
      },
      "position" : {
        "x" : -565.4611550013309,
        "y" : -515.6305779652592
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "867",
        "shared_name" : "Zippy Zap",
        "name" : "Zippy Zap",
        "SUID" : 867,
        "selected" : false
      },
      "position" : {
        "x" : 156.91627114613004,
        "y" : 63.23784549665481
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "863",
        "shared_name" : "Zing Zap",
        "name" : "Zing Zap",
        "SUID" : 863,
        "selected" : false
      },
      "position" : {
        "x" : 128.34073251087614,
        "y" : 276.253027991772
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "859",
        "shared_name" : "Veevee Volley",
        "name" : "Veevee Volley",
        "SUID" : 859,
        "selected" : false
      },
      "position" : {
        "x" : -193.2129631678348,
        "y" : 228.9162359995845
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "855",
        "shared_name" : "Twinkle Tackle",
        "name" : "Twinkle Tackle",
        "SUID" : 855,
        "selected" : false
      },
      "position" : {
        "x" : 221.82699197132536,
        "y" : 15.760916785717313
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "851",
        "shared_name" : "Trop Kick",
        "name" : "Trop Kick",
        "SUID" : 851,
        "selected" : false
      },
      "position" : {
        "x" : 157.43541329700895,
        "y" : 414.5836172862056
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "847",
        "shared_name" : "Toxic Thread",
        "name" : "Toxic Thread",
        "SUID" : 847,
        "selected" : false
      },
      "position" : {
        "x" : 258.0201396306271,
        "y" : 97.41744144392044
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "843",
        "shared_name" : "Throat Chop",
        "name" : "Throat Chop",
        "SUID" : 843,
        "selected" : false
      },
      "position" : {
        "x" : -169.74961477916293,
        "y" : 181.8773413462642
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "839",
        "shared_name" : "Tectonic Rage",
        "name" : "Tectonic Rage",
        "SUID" : 839,
        "selected" : false
      },
      "position" : {
        "x" : 185.29696267445036,
        "y" : 226.59940250349075
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "835",
        "shared_name" : "Tearful Look",
        "name" : "Tearful Look",
        "SUID" : 835,
        "selected" : false
      },
      "position" : {
        "x" : 117.65719979603239,
        "y" : 22.514212684154813
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "831",
        "shared_name" : "Supersonic Skystrike",
        "name" : "Supersonic Skystrike",
        "SUID" : 831,
        "selected" : false
      },
      "position" : {
        "x" : -93.44895559947543,
        "y" : 7.636679725170438
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "827",
        "shared_name" : "Sunsteel Strike",
        "name" : "Sunsteel Strike",
        "SUID" : 827,
        "selected" : false
      },
      "position" : {
        "x" : 211.42220681507536,
        "y" : 182.0312720103267
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "823",
        "shared_name" : "Subzero Slammer",
        "name" : "Subzero Slammer",
        "SUID" : 823,
        "selected" : false
      },
      "position" : {
        "x" : 253.82419579822965,
        "y" : 157.2942419810298
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "819",
        "shared_name" : "Strength Sap",
        "name" : "Strength Sap",
        "SUID" : 819,
        "selected" : false
      },
      "position" : {
        "x" : 29.469562466930824,
        "y" : 289.1812964243892
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "815",
        "shared_name" : "Stomping Tantrum",
        "name" : "Stomping Tantrum",
        "SUID" : 815,
        "selected" : false
      },
      "position" : {
        "x" : 100.59737008411832,
        "y" : -94.52539913225144
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "811",
        "shared_name" : "Stoked Sparksurfer",
        "name" : "Stoked Sparksurfer",
        "SUID" : 811,
        "selected" : false
      },
      "position" : {
        "x" : 30.684635098766762,
        "y" : 70.43819339704544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "807",
        "shared_name" : "Spotlight",
        "name" : "Spotlight",
        "SUID" : 807,
        "selected" : false
      },
      "position" : {
        "x" : 76.11238473255582,
        "y" : 261.36397464704544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "803",
        "shared_name" : "Splishy Splash",
        "name" : "Splishy Splash",
        "SUID" : 803,
        "selected" : false
      },
      "position" : {
        "x" : -71.62168509166293,
        "y" : 309.1274481577876
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "799",
        "shared_name" : "Splintered Stormshards",
        "name" : "Splintered Stormshards",
        "SUID" : 799,
        "selected" : false
      },
      "position" : {
        "x" : 140.1119880040402,
        "y" : 188.0513220591548
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "795",
        "shared_name" : "Spirit Shackle",
        "name" : "Spirit Shackle",
        "SUID" : 795,
        "selected" : false
      },
      "position" : {
        "x" : -46.6537590662723,
        "y" : 212.6097937388423
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "791",
        "shared_name" : "Speed Swap",
        "name" : "Speed Swap",
        "SUID" : 791,
        "selected" : false
      },
      "position" : {
        "x" : 49.16942208607145,
        "y" : -75.01032344865769
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "787",
        "shared_name" : "Spectral Thief",
        "name" : "Spectral Thief",
        "SUID" : 787,
        "selected" : false
      },
      "position" : {
        "x" : 75.36700814564176,
        "y" : 307.5438452525142
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "783",
        "shared_name" : "Sparkly Swirl",
        "name" : "Sparkly Swirl",
        "SUID" : 783,
        "selected" : false
      },
      "position" : {
        "x" : 297.9012183507199,
        "y" : 137.7211218638423
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "779",
        "shared_name" : "Sparkling Aria",
        "name" : "Sparkling Aria",
        "SUID" : 779,
        "selected" : false
      },
      "position" : {
        "x" : -140.22022635142855,
        "y" : -8.768380089282687
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "775",
        "shared_name" : "Soul-Stealing 7-Star Strike",
        "name" : "Soul-Stealing 7-Star Strike",
        "SUID" : 775,
        "selected" : false
      },
      "position" : {
        "x" : 236.9514884312863,
        "y" : 220.58385379743606
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "771",
        "shared_name" : "Solar Blade",
        "name" : "Solar Blade",
        "SUID" : 771,
        "selected" : false
      },
      "position" : {
        "x" : -19.2155266443973,
        "y" : -64.66254512834519
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "767",
        "shared_name" : "Smart Strike",
        "name" : "Smart Strike",
        "SUID" : 767,
        "selected" : false
      },
      "position" : {
        "x" : 219.68010705311247,
        "y" : 274.1868201060298
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "763",
        "shared_name" : "Sizzly Slide",
        "name" : "Sizzly Slide",
        "SUID" : 763,
        "selected" : false
      },
      "position" : {
        "x" : 99.4326667149777,
        "y" : 430.20295246076614
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "759",
        "shared_name" : "Sinister Arrow Raid",
        "name" : "Sinister Arrow Raid",
        "SUID" : 759,
        "selected" : false
      },
      "position" : {
        "x" : 136.312869962048,
        "y" : -19.077828331470187
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "755",
        "shared_name" : "Shore Up",
        "name" : "Shore Up",
        "SUID" : 755,
        "selected" : false
      },
      "position" : {
        "x" : -65.22349173228793,
        "y" : 158.0005408091548
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "751",
        "shared_name" : "Shell Trap",
        "name" : "Shell Trap",
        "SUID" : 751,
        "selected" : false
      },
      "position" : {
        "x" : -116.90455252330355,
        "y" : 272.1878882212642
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "747",
        "shared_name" : "Shattered Psyche",
        "name" : "Shattered Psyche",
        "SUID" : 747,
        "selected" : false
      },
      "position" : {
        "x" : -63.026104036975426,
        "y" : -31.097603722095187
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "743",
        "shared_name" : "Shadow Bone",
        "name" : "Shadow Bone",
        "SUID" : 743,
        "selected" : false
      },
      "position" : {
        "x" : -188.03220755260043,
        "y" : -11.746468468188937
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "739",
        "shared_name" : "Searing Sunraze Smash",
        "name" : "Searing Sunraze Smash",
        "SUID" : 739,
        "selected" : false
      },
      "position" : {
        "x" : -134.00852591197543,
        "y" : 40.83803470563919
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "735",
        "shared_name" : "Savage Spin-Out",
        "name" : "Savage Spin-Out",
        "SUID" : 735,
        "selected" : false
      },
      "position" : {
        "x" : 33.91769784290739,
        "y" : 446.4192534251216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "731",
        "shared_name" : "Sappy Seed",
        "name" : "Sappy Seed",
        "SUID" : 731,
        "selected" : false
      },
      "position" : {
        "x" : -73.3565178553348,
        "y" : 56.31163700056106
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "727",
        "shared_name" : "Revelation Dance",
        "name" : "Revelation Dance",
        "SUID" : 727,
        "selected" : false
      },
      "position" : {
        "x" : -67.82200247447543,
        "y" : 261.21251590681106
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "723",
        "shared_name" : "Purify",
        "name" : "Purify",
        "SUID" : 723,
        "selected" : false
      },
      "position" : {
        "x" : -224.70347220103793,
        "y" : 82.01119144392044
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "719",
        "shared_name" : "Pulverizing Pancake",
        "name" : "Pulverizing Pancake",
        "SUID" : 719,
        "selected" : false
      },
      "position" : {
        "x" : 209.648319180798,
        "y" : 63.74822147321731
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "715",
        "shared_name" : "Psychic Terrain",
        "name" : "Psychic Terrain",
        "SUID" : 715,
        "selected" : false
      },
      "position" : {
        "x" : 113.59053414661832,
        "y" : 78.60591800642044
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "711",
        "shared_name" : "Psychic Fangs",
        "name" : "Psychic Fangs",
        "SUID" : 711,
        "selected" : false
      },
      "position" : {
        "x" : 136.67044442493864,
        "y" : 233.86551578474075
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "707",
        "shared_name" : "Prismatic Laser",
        "name" : "Prismatic Laser",
        "SUID" : 707,
        "selected" : false
      },
      "position" : {
        "x" : -106.30375296275668,
        "y" : 131.6965552134517
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "703",
        "shared_name" : "Power Trip",
        "name" : "Power Trip",
        "SUID" : 703,
        "selected" : false
      },
      "position" : {
        "x" : -198.35898977916293,
        "y" : 38.01045902204544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "699",
        "shared_name" : "Pollen Puff",
        "name" : "Pollen Puff",
        "SUID" : 699,
        "selected" : false
      },
      "position" : {
        "x" : 92.27817147571989,
        "y" : 157.4551001353267
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "695",
        "shared_name" : "Plasma Fists",
        "name" : "Plasma Fists",
        "SUID" : 695,
        "selected" : false
      },
      "position" : {
        "x" : 35.3324469884152,
        "y" : 346.9273138804439
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "691",
        "shared_name" : "Pika Papow",
        "name" : "Pika Papow",
        "SUID" : 691,
        "selected" : false
      },
      "position" : {
        "x" : 266.44846337635465,
        "y" : 47.70192630720169
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "687",
        "shared_name" : "Photon Geyser",
        "name" : "Photon Geyser",
        "SUID" : 687,
        "selected" : false
      },
      "position" : {
        "x" : 93.66759103138395,
        "y" : -44.40204708147019
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "683",
        "shared_name" : "Oceanic Operetta",
        "name" : "Oceanic Operetta",
        "SUID" : 683,
        "selected" : false
      },
      "position" : {
        "x" : -122.26084524791293,
        "y" : -56.19525997209519
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "679",
        "shared_name" : "Never-Ending Nightmare",
        "name" : "Never-Ending Nightmare",
        "SUID" : 679,
        "selected" : false
      },
      "position" : {
        "x" : -117.49619681041293,
        "y" : 86.36498172712356
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "675",
        "shared_name" : "Nature's Madness",
        "name" : "Nature's Madness",
        "SUID" : 675,
        "selected" : false
      },
      "position" : {
        "x" : -220.6182366053348,
        "y" : 180.7226782603267
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "671",
        "shared_name" : "Multi-Attack",
        "name" : "Multi-Attack",
        "SUID" : 671,
        "selected" : false
      },
      "position" : {
        "x" : -153.4033928553348,
        "y" : 134.91344364118606
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "667",
        "shared_name" : "Moongeist Beam",
        "name" : "Moongeist Beam",
        "SUID" : 667,
        "selected" : false
      },
      "position" : {
        "x" : 207.75472634632536,
        "y" : -31.73313228654831
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "663",
        "shared_name" : "Mind Blown",
        "name" : "Mind Blown",
        "SUID" : 663,
        "selected" : false
      },
      "position" : {
        "x" : 14.2688483556027,
        "y" : 240.19470889997513
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "659",
        "shared_name" : "Menacing Moonraze Maelstrom",
        "name" : "Menacing Moonraze Maelstrom",
        "SUID" : 659,
        "selected" : false
      },
      "position" : {
        "x" : -144.9759026209598,
        "y" : 225.00333316755325
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "655",
        "shared_name" : "Malicious Moonsault",
        "name" : "Malicious Moonsault",
        "SUID" : 655,
        "selected" : false
      },
      "position" : {
        "x" : 131.21365731556364,
        "y" : 126.31856449079544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "651",
        "shared_name" : "Lunge",
        "name" : "Lunge",
        "SUID" : 651,
        "selected" : false
      },
      "position" : {
        "x" : -69.9398918787723,
        "y" : 389.54646976423294
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "647",
        "shared_name" : "Liquidation",
        "name" : "Liquidation",
        "SUID" : 647,
        "selected" : false
      },
      "position" : {
        "x" : -166.59775931041293,
        "y" : 271.52994449567825
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "643",
        "shared_name" : "Light That Burns the Sky",
        "name" : "Light That Burns the Sky",
        "SUID" : 643,
        "selected" : false
      },
      "position" : {
        "x" : 160.8314475377316,
        "y" : 346.3377753062251
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "639",
        "shared_name" : "Let's Snuggle Forever",
        "name" : "Let's Snuggle Forever",
        "SUID" : 639,
        "selected" : false
      },
      "position" : {
        "x" : 68.93562692005582,
        "y" : 0.7373877329829384
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "635",
        "shared_name" : "Leafage",
        "name" : "Leafage",
        "SUID" : 635,
        "selected" : false
      },
      "position" : {
        "x" : 287.9931191762204,
        "y" : 208.65152652692825
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "631",
        "shared_name" : "Laser Focus",
        "name" : "Laser Focus",
        "SUID" : 631,
        "selected" : false
      },
      "position" : {
        "x" : 120.81647103626676,
        "y" : 322.12100894880325
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "627",
        "shared_name" : "Instruct",
        "name" : "Instruct",
        "SUID" : 627,
        "selected" : false
      },
      "position" : {
        "x" : 84.88901131946989,
        "y" : 212.1864538950923
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "623",
        "shared_name" : "Inferno Overdrive",
        "name" : "Inferno Overdrive",
        "SUID" : 623,
        "selected" : false
      },
      "position" : {
        "x" : 33.36401742298551,
        "y" : -27.91574947404831
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "619",
        "shared_name" : "Ice Hammer",
        "name" : "Ice Hammer",
        "SUID" : 619,
        "selected" : false
      },
      "position" : {
        "x" : -167.15501028697543,
        "y" : 82.80431278181106
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "615",
        "shared_name" : "Hydro Vortex",
        "name" : "Hydro Vortex",
        "SUID" : 615,
        "selected" : false
      },
      "position" : {
        "x" : -198.91166311900668,
        "y" : 130.0968542857173
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "611",
        "shared_name" : "High Horsepower",
        "name" : "High Horsepower",
        "SUID" : 611,
        "selected" : false
      },
      "position" : {
        "x" : 74.34193795521207,
        "y" : 107.26369388532669
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "607",
        "shared_name" : "Guardian of Alola",
        "name" : "Guardian of Alola",
        "SUID" : 607,
        "selected" : false
      },
      "position" : {
        "x" : 215.6448706944699,
        "y" : 125.80486209821731
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "603",
        "shared_name" : "Glitzy Glow",
        "name" : "Glitzy Glow",
        "SUID" : 603,
        "selected" : false
      },
      "position" : {
        "x" : 171.2205542882199,
        "y" : 16.500113563061063
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "599",
        "shared_name" : "Gigavolt Havoc",
        "name" : "Gigavolt Havoc",
        "SUID" : 599,
        "selected" : false
      },
      "position" : {
        "x" : 258.42010110218473,
        "y" : 314.9226141734126
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "595",
        "shared_name" : "Genesis Supernova",
        "name" : "Genesis Supernova",
        "SUID" : 595,
        "selected" : false
      },
      "position" : {
        "x" : -135.2320061365848,
        "y" : 319.5238104624751
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "591",
        "shared_name" : "Gear Up",
        "name" : "Gear Up",
        "SUID" : 591,
        "selected" : false
      },
      "position" : {
        "x" : -220.05173880260043,
        "y" : 274.6959753794673
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "587",
        "shared_name" : "Freezy Frost",
        "name" : "Freezy Frost",
        "SUID" : 587,
        "selected" : false
      },
      "position" : {
        "x" : 159.0964621861691,
        "y" : -64.83338253068894
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "583",
        "shared_name" : "Floral Healing",
        "name" : "Floral Healing",
        "SUID" : 583,
        "selected" : false
      },
      "position" : {
        "x" : 171.9740485509152,
        "y" : 155.36803348493606
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "579",
        "shared_name" : "Floaty Fall",
        "name" : "Floaty Fall",
        "SUID" : 579,
        "selected" : false
      },
      "position" : {
        "x" : -15.67261892955355,
        "y" : 425.3688727183345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "575",
        "shared_name" : "Fleur Cannon",
        "name" : "Fleur Cannon",
        "SUID" : 575,
        "selected" : false
      },
      "position" : {
        "x" : 9.17186349232145,
        "y" : -102.90265743303269
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "571",
        "shared_name" : "First Impression",
        "name" : "First Impression",
        "SUID" : 571,
        "selected" : false
      },
      "position" : {
        "x" : -10.7381096522098,
        "y" : -16.05246822404831
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "567",
        "shared_name" : "Fire Lash",
        "name" : "Fire Lash",
        "SUID" : 567,
        "selected" : false
      },
      "position" : {
        "x" : -41.2182121912723,
        "y" : 354.50245578718216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "563",
        "shared_name" : "Extreme Evoboost",
        "name" : "Extreme Evoboost",
        "SUID" : 563,
        "selected" : false
      },
      "position" : {
        "x" : 119.36449044544645,
        "y" : 379.2637472910884
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "559",
        "shared_name" : "Dragon Hammer",
        "name" : "Dragon Hammer",
        "SUID" : 559,
        "selected" : false
      },
      "position" : {
        "x" : 272.4923247655148,
        "y" : 260.94026859235794
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "555",
        "shared_name" : "Double Iron Bash",
        "name" : "Double Iron Bash",
        "SUID" : 555,
        "selected" : false
      },
      "position" : {
        "x" : -195.3793450037723,
        "y" : 319.9490423960689
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "551",
        "shared_name" : "Devastating Drake",
        "name" : "Devastating Drake",
        "SUID" : 551,
        "selected" : false
      },
      "position" : {
        "x" : -66.13651663463168,
        "y" : 437.74884517622024
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "547",
        "shared_name" : "Darkest Lariat",
        "name" : "Darkest Lariat",
        "SUID" : 547,
        "selected" : false
      },
      "position" : {
        "x" : 203.65851205189176,
        "y" : 326.07149417829544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "543",
        "shared_name" : "Corkscrew Crash",
        "name" : "Corkscrew Crash",
        "SUID" : 543,
        "selected" : false
      },
      "position" : {
        "x" : -25.01160818736605,
        "y" : 274.35909183454544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "539",
        "shared_name" : "Core Enforcer",
        "name" : "Core Enforcer",
        "SUID" : 539,
        "selected" : false
      },
      "position" : {
        "x" : 80.75563424427457,
        "y" : 354.9366980357173
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "535",
        "shared_name" : "Continental Crush",
        "name" : "Continental Crush",
        "SUID" : 535,
        "selected" : false
      },
      "position" : {
        "x" : 55.96603768665739,
        "y" : 398.67718418073684
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "531",
        "shared_name" : "Clangorous Soulblaze",
        "name" : "Clangorous Soulblaze",
        "SUID" : 531,
        "selected" : false
      },
      "position" : {
        "x" : -21.488811556506676,
        "y" : 62.61501224470169
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "527",
        "shared_name" : "Clanging Scales",
        "name" : "Clanging Scales",
        "SUID" : 527,
        "selected" : false
      },
      "position" : {
        "x" : -11.27076346080355,
        "y" : 111.04750736188919
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "523",
        "shared_name" : "Catastropika",
        "name" : "Catastropika",
        "SUID" : 523,
        "selected" : false
      },
      "position" : {
        "x" : 2.9806098302120745,
        "y" : 379.09163577985794
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "519",
        "shared_name" : "Buzzy Buzz",
        "name" : "Buzzy Buzz",
        "SUID" : 519,
        "selected" : false
      },
      "position" : {
        "x" : -95.09183890025668,
        "y" : 224.0156012339595
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "515",
        "shared_name" : "Burn Up",
        "name" : "Burn Up",
        "SUID" : 515,
        "selected" : false
      },
      "position" : {
        "x" : 175.18859475452848,
        "y" : 104.60246952009231
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "511",
        "shared_name" : "Brutal Swing",
        "name" : "Brutal Swing",
        "SUID" : 511,
        "selected" : false
      },
      "position" : {
        "x" : -64.38206106822543,
        "y" : 104.38115604352981
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "507",
        "shared_name" : "Breakneck Blitz",
        "name" : "Breakneck Blitz",
        "SUID" : 507,
        "selected" : false
      },
      "position" : {
        "x" : -69.61893850963168,
        "y" : -83.34217159318894
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "503",
        "shared_name" : "Bouncy Bubble",
        "name" : "Bouncy Bubble",
        "SUID" : 503,
        "selected" : false
      },
      "position" : {
        "x" : 171.3572501500363,
        "y" : 283.10965640974075
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "499",
        "shared_name" : "Bloom Doom",
        "name" : "Bloom Doom",
        "SUID" : 499,
        "selected" : false
      },
      "position" : {
        "x" : -124.5149651209598,
        "y" : 396.4285116953853
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "495",
        "shared_name" : "Black Hole Eclipse",
        "name" : "Black Hole Eclipse",
        "SUID" : 495,
        "selected" : false
      },
      "position" : {
        "x" : -11.596904818225426,
        "y" : 322.7423315806392
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "491",
        "shared_name" : "Beak Blast",
        "name" : "Beak Blast",
        "SUID" : 491,
        "selected" : false
      },
      "position" : {
        "x" : -168.12281424205355,
        "y" : 362.36817844343216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "487",
        "shared_name" : "Baneful Bunker",
        "name" : "Baneful Bunker",
        "SUID" : 487,
        "selected" : false
      },
      "position" : {
        "x" : 75.26520150501676,
        "y" : 46.86455448102981
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "483",
        "shared_name" : "Baddy Bad",
        "name" : "Baddy Bad",
        "SUID" : 483,
        "selected" : false
      },
      "position" : {
        "x" : 17.4106940587277,
        "y" : 26.09682376813919
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "479",
        "shared_name" : "Aurora Veil",
        "name" : "Aurora Veil",
        "SUID" : 479,
        "selected" : false
      },
      "position" : {
        "x" : -41.68604666392855,
        "y" : 16.66060550642044
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "475",
        "shared_name" : "Anchor Shot",
        "name" : "Anchor Shot",
        "SUID" : 475,
        "selected" : false
      },
      "position" : {
        "x" : -248.25321585338168,
        "y" : 225.49567325544388
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "471",
        "shared_name" : "All-Out Pummeling",
        "name" : "All-Out Pummeling",
        "SUID" : 471,
        "selected" : false
      },
      "position" : {
        "x" : -248.77659231822543,
        "y" : 135.5339575572017
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "467",
        "shared_name" : "Acid Downpour",
        "name" : "Acid Downpour",
        "SUID" : 467,
        "selected" : false
      },
      "position" : {
        "x" : -100.87708670299105,
        "y" : 348.94512851667434
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "463",
        "shared_name" : "Accelerock",
        "name" : "Accelerock",
        "SUID" : 463,
        "selected" : false
      },
      "position" : {
        "x" : 210.28828805286832,
        "y" : 376.2412176890376
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "459",
        "shared_name" : "10,000,000 Volt Thunderbolt",
        "name" : "10,000,000 Volt Thunderbolt",
        "SUID" : 459,
        "selected" : false
      },
      "position" : {
        "x" : -115.1054192225223,
        "y" : 179.30672367048294
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "457",
        "shared_name" : "gen7",
        "name" : "gen7",
        "SUID" : 457,
        "selected" : false
      },
      "position" : {
        "x" : 21.166889127087074,
        "y" : 167.7651587290767
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "453",
        "shared_name" : "Water Shuriken",
        "name" : "Water Shuriken",
        "SUID" : 453,
        "selected" : false
      },
      "position" : {
        "x" : 680.8221315701718,
        "y" : 649.8707686228755
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "449",
        "shared_name" : "Venom Drench",
        "name" : "Venom Drench",
        "SUID" : 449,
        "selected" : false
      },
      "position" : {
        "x" : 542.1548647244687,
        "y" : 918.3703642649654
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "445",
        "shared_name" : "Trick-or-Treat",
        "name" : "Trick-or-Treat",
        "SUID" : 445,
        "selected" : false
      },
      "position" : {
        "x" : 492.6518434842343,
        "y" : 930.5972319407466
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "441",
        "shared_name" : "Topsy-Turvy",
        "name" : "Topsy-Turvy",
        "SUID" : 441,
        "selected" : false
      },
      "position" : {
        "x" : 489.2599520047421,
        "y" : 695.9860411448482
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "437",
        "shared_name" : "Thousand Waves",
        "name" : "Thousand Waves",
        "SUID" : 437,
        "selected" : false
      },
      "position" : {
        "x" : 469.57797568638273,
        "y" : 608.2451353831294
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "433",
        "shared_name" : "Thousand Arrows",
        "name" : "Thousand Arrows",
        "SUID" : 433,
        "selected" : false
      },
      "position" : {
        "x" : 415.3984255154843,
        "y" : 832.8850966258052
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "429",
        "shared_name" : "Sticky Web",
        "name" : "Sticky Web",
        "SUID" : 429,
        "selected" : false
      },
      "position" : {
        "x" : 416.6427873929257,
        "y" : 595.1306792063716
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "425",
        "shared_name" : "Steam Eruption",
        "name" : "Steam Eruption",
        "SUID" : 425,
        "selected" : false
      },
      "position" : {
        "x" : 750.0036501248593,
        "y" : 670.5847807688716
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "421",
        "shared_name" : "Spiky Shield",
        "name" : "Spiky Shield",
        "SUID" : 421,
        "selected" : false
      },
      "position" : {
        "x" : 545.3243593533749,
        "y" : 701.6283903880122
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "417",
        "shared_name" : "Rototiller",
        "name" : "Rototiller",
        "SUID" : 417,
        "selected" : false
      },
      "position" : {
        "x" : 315.69328301746793,
        "y" : 729.3370428843501
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "413",
        "shared_name" : "Precipice Blades",
        "name" : "Precipice Blades",
        "SUID" : 413,
        "selected" : false
      },
      "position" : {
        "x" : 534.552401955914,
        "y" : 980.2597685618404
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "409",
        "shared_name" : "Power-Up Punch",
        "name" : "Power-Up Punch",
        "SUID" : 409,
        "selected" : false
      },
      "position" : {
        "x" : 384.4160341580624,
        "y" : 797.2757254405025
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "405",
        "shared_name" : "Powder",
        "name" : "Powder",
        "SUID" : 405,
        "selected" : false
      },
      "position" : {
        "x" : 467.3651003201718,
        "y" : 825.8037977976802
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "401",
        "shared_name" : "Play Rough",
        "name" : "Play Rough",
        "SUID" : 401,
        "selected" : false
      },
      "position" : {
        "x" : 636.1503481229062,
        "y" : 807.1496382517818
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "397",
        "shared_name" : "Play Nice",
        "name" : "Play Nice",
        "SUID" : 397,
        "selected" : false
      },
      "position" : {
        "x" : 487.64331382114835,
        "y" : 557.6950712962154
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "393",
        "shared_name" : "Phantom Force",
        "name" : "Phantom Force",
        "SUID" : 393,
        "selected" : false
      },
      "position" : {
        "x" : 751.6760134061093,
        "y" : 816.8838568491939
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "389",
        "shared_name" : "Petal Blizzard",
        "name" : "Petal Blizzard",
        "SUID" : 389,
        "selected" : false
      },
      "position" : {
        "x" : 353.98282569248624,
        "y" : 687.6190062327388
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "385",
        "shared_name" : "Parting Shot",
        "name" : "Parting Shot",
        "SUID" : 385,
        "selected" : false
      },
      "position" : {
        "x" : 729.4701723416562,
        "y" : 920.1390105051997
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "381",
        "shared_name" : "Parabolic Charge",
        "name" : "Parabolic Charge",
        "SUID" : 381,
        "selected" : false
      },
      "position" : {
        "x" : 580.0821108182187,
        "y" : 875.9006987376216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "377",
        "shared_name" : "Origin Pulse",
        "name" : "Origin Pulse",
        "SUID" : 377,
        "selected" : false
      },
      "position" : {
        "x" : 712.693286355328,
        "y" : 609.269442634106
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "373",
        "shared_name" : "Oblivion Wing",
        "name" : "Oblivion Wing",
        "SUID" : 373,
        "selected" : false
      },
      "position" : {
        "x" : 769.383227761578,
        "y" : 723.1162901682857
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "369",
        "shared_name" : "Nuzzle",
        "name" : "Nuzzle",
        "SUID" : 369,
        "selected" : false
      },
      "position" : {
        "x" : 616.6595339139218,
        "y" : 918.0114470286372
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "365",
        "shared_name" : "Noble Roar",
        "name" : "Noble Roar",
        "SUID" : 365,
        "selected" : false
      },
      "position" : {
        "x" : 652.0949282010312,
        "y" : 585.0547209544185
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "361",
        "shared_name" : "Mystical Fire",
        "name" : "Mystical Fire",
        "SUID" : 361,
        "selected" : false
      },
      "position" : {
        "x" : 696.7792543729062,
        "y" : 811.1330443186763
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "357",
        "shared_name" : "Moonblast",
        "name" : "Moonblast",
        "SUID" : 357,
        "selected" : false
      },
      "position" : {
        "x" : 324.52286475498624,
        "y" : 808.9541044993404
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "353",
        "shared_name" : "Misty Terrain",
        "name" : "Misty Terrain",
        "SUID" : 353,
        "selected" : false
      },
      "position" : {
        "x" : 457.9033846219296,
        "y" : 876.9769850535396
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "349",
        "shared_name" : "Mat Block",
        "name" : "Mat Block",
        "SUID" : 349,
        "selected" : false
      },
      "position" : {
        "x" : 669.6695131619687,
        "y" : 915.2618284983638
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "345",
        "shared_name" : "Magnetic Flux",
        "name" : "Magnetic Flux",
        "SUID" : 345,
        "selected" : false
      },
      "position" : {
        "x" : 399.62883323032804,
        "y" : 965.1562834544185
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "341",
        "shared_name" : "Light of Ruin",
        "name" : "Light of Ruin",
        "SUID" : 341,
        "selected" : false
      },
      "position" : {
        "x" : 514.742846902203,
        "y" : 647.9754744334224
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "337",
        "shared_name" : "Land's Wrath",
        "name" : "Land's Wrath",
        "SUID" : 337,
        "selected" : false
      },
      "position" : {
        "x" : 589.927905495953,
        "y" : 1009.9678831858638
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "333",
        "shared_name" : "King's Shield",
        "name" : "King's Shield",
        "SUID" : 333,
        "selected" : false
      },
      "position" : {
        "x" : 448.5689577420468,
        "y" : 726.965113715649
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "329",
        "shared_name" : "Ion Deluge",
        "name" : "Ion Deluge",
        "SUID" : 329,
        "selected" : false
      },
      "position" : {
        "x" : 689.9948305447812,
        "y" : 863.8736830515865
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "325",
        "shared_name" : "Infestation",
        "name" : "Infestation",
        "SUID" : 325,
        "selected" : false
      },
      "position" : {
        "x" : 635.6111635525937,
        "y" : 977.6692992014888
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "321",
        "shared_name" : "Hyperspace Hole",
        "name" : "Hyperspace Hole",
        "SUID" : 321,
        "selected" : false
      },
      "position" : {
        "x" : 635.254321511578,
        "y" : 859.2551832957271
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "317",
        "shared_name" : "Hyperspace Fury",
        "name" : "Hyperspace Fury",
        "SUID" : 317,
        "selected" : false
      },
      "position" : {
        "x" : 570.2514376004452,
        "y" : 633.8012114329341
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "313",
        "shared_name" : "Hold Hands",
        "name" : "Hold Hands",
        "SUID" : 313,
        "selected" : false
      },
      "position" : {
        "x" : 355.52033561069914,
        "y" : 762.8088184161189
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "309",
        "shared_name" : "Hold Back",
        "name" : "Hold Back",
        "SUID" : 309,
        "selected" : false
      },
      "position" : {
        "x" : 569.0240358670468,
        "y" : 546.4192534251216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "305",
        "shared_name" : "Happy Hour",
        "name" : "Happy Hour",
        "SUID" : 305,
        "selected" : false
      },
      "position" : {
        "x" : 466.0573610623593,
        "y" : 776.0036116404536
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "301",
        "shared_name" : "Grassy Terrain",
        "name" : "Grassy Terrain",
        "SUID" : 301,
        "selected" : false
      },
      "position" : {
        "x" : 624.9322389920468,
        "y" : 638.6389952464107
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "297",
        "shared_name" : "Geomancy",
        "name" : "Geomancy",
        "SUID" : 297,
        "selected" : false
      },
      "position" : {
        "x" : 517.3713259061093,
        "y" : 867.700221137524
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "293",
        "shared_name" : "Freeze-Dry",
        "name" : "Freeze-Dry",
        "SUID" : 293,
        "selected" : false
      },
      "position" : {
        "x" : 457.37036460239835,
        "y" : 972.793383674145
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "289",
        "shared_name" : "Forest's Curse",
        "name" : "Forest's Curse",
        "SUID" : 289,
        "selected" : false
      },
      "position" : {
        "x" : 654.171069558453,
        "y" : 690.047160224438
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "285",
        "shared_name" : "Flying Press",
        "name" : "Flying Press",
        "SUID" : 285,
        "selected" : false
      },
      "position" : {
        "x" : 595.3987917264218,
        "y" : 689.4127074046138
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "281",
        "shared_name" : "Flower Shield",
        "name" : "Flower Shield",
        "SUID" : 281,
        "selected" : false
      },
      "position" : {
        "x" : 673.9282106717343,
        "y" : 761.1327060027126
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "277",
        "shared_name" : "Fell Stinger",
        "name" : "Fell Stinger",
        "SUID" : 277,
        "selected" : false
      },
      "position" : {
        "x" : 599.7733339627499,
        "y" : 588.5699339671138
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "273",
        "shared_name" : "Fairy Wind",
        "name" : "Fairy Wind",
        "SUID" : 273,
        "selected" : false
      },
      "position" : {
        "x" : 451.2233766873593,
        "y" : 655.7875014109615
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "269",
        "shared_name" : "Fairy Lock",
        "name" : "Fairy Lock",
        "SUID" : 269,
        "selected" : false
      },
      "position" : {
        "x" : 691.9002260525937,
        "y" : 967.9339018626216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "265",
        "shared_name" : "Electrify",
        "name" : "Electrify",
        "SUID" : 265,
        "selected" : false
      },
      "position" : {
        "x" : 393.03915732700773,
        "y" : 872.6979475779536
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "261",
        "shared_name" : "Electric Terrain",
        "name" : "Electric Terrain",
        "SUID" : 261,
        "selected" : false
      },
      "position" : {
        "x" : 334.8560022671933,
        "y" : 862.4112120432857
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "257",
        "shared_name" : "Eerie Impulse",
        "name" : "Eerie Impulse",
        "SUID" : 257,
        "selected" : false
      },
      "position" : {
        "x" : 418.3371538480038,
        "y" : 687.417895392895
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "253",
        "shared_name" : "Draining Kiss",
        "name" : "Draining Kiss",
        "SUID" : 253,
        "selected" : false
      },
      "position" : {
        "x" : 701.942798074078,
        "y" : 709.5721884531978
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "249",
        "shared_name" : "Dragon Ascent",
        "name" : "Dragon Ascent",
        "SUID" : 249,
        "selected" : false
      },
      "position" : {
        "x" : 436.2031816800351,
        "y" : 923.0428496165279
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "245",
        "shared_name" : "Disarming Voice",
        "name" : "Disarming Voice",
        "SUID" : 245,
        "selected" : false
      },
      "position" : {
        "x" : 527.894931252789,
        "y" : 590.8015623850825
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "241",
        "shared_name" : "Diamond Storm",
        "name" : "Diamond Storm",
        "SUID" : 241,
        "selected" : false
      },
      "position" : {
        "x" : 725.9881166775937,
        "y" : 761.3870836062434
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "237",
        "shared_name" : "Dazzling Gleam",
        "name" : "Dazzling Gleam",
        "SUID" : 237,
        "selected" : false
      },
      "position" : {
        "x" : 398.9578508694882,
        "y" : 741.8972712321284
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "233",
        "shared_name" : "Crafty Shield",
        "name" : "Crafty Shield",
        "SUID" : 233,
        "selected" : false
      },
      "position" : {
        "x" : 786.669360574078,
        "y" : 781.0660391612056
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "229",
        "shared_name" : "Confide",
        "name" : "Confide",
        "SUID" : 229,
        "selected" : false
      },
      "position" : {
        "x" : 369.72211783726164,
        "y" : 916.0154600901607
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "225",
        "shared_name" : "Celebrate",
        "name" : "Celebrate",
        "SUID" : 225,
        "selected" : false
      },
      "position" : {
        "x" : 622.2978090604062,
        "y" : 740.7929716868404
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "221",
        "shared_name" : "Boomburst",
        "name" : "Boomburst",
        "SUID" : 221,
        "selected" : false
      },
      "position" : {
        "x" : 748.4069399197812,
        "y" : 867.0007429881099
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "217",
        "shared_name" : "Belch",
        "name" : "Belch",
        "SUID" : 217,
        "selected" : false
      },
      "position" : {
        "x" : 377.53004401524015,
        "y" : 638.996378974438
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "213",
        "shared_name" : "Baby-Doll Eyes",
        "name" : "Baby-Doll Eyes",
        "SUID" : 213,
        "selected" : false
      },
      "position" : {
        "x" : 577.3998598416562,
        "y" : 949.2793455882075
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "209",
        "shared_name" : "Aromatic Mist",
        "name" : "Aromatic Mist",
        "SUID" : 209,
        "selected" : false
      },
      "position" : {
        "x" : 499.4373964627499,
        "y" : 1016.1780577464107
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "207",
        "shared_name" : "gen6",
        "name" : "gen6",
        "SUID" : 207,
        "selected" : false
      },
      "position" : {
        "x" : 548.9790987332577,
        "y" : 783.0235873026851
      },
      "selected" : false
    } ],
    "edges" : [ {
      "data" : {
        "id" : "3959",
        "source" : "3591",
        "target" : "3957",
        "shared_name" : "gen5 (interacts with) Work Up",
        "name" : "gen5 (interacts with) Work Up",
        "interaction" : "interacts with",
        "SUID" : 3959,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3955",
        "source" : "3591",
        "target" : "3953",
        "shared_name" : "gen5 (interacts with) Wonder Room",
        "name" : "gen5 (interacts with) Wonder Room",
        "interaction" : "interacts with",
        "SUID" : 3955,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3951",
        "source" : "3591",
        "target" : "3949",
        "shared_name" : "gen5 (interacts with) Wild Charge",
        "name" : "gen5 (interacts with) Wild Charge",
        "interaction" : "interacts with",
        "SUID" : 3951,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3947",
        "source" : "3591",
        "target" : "3945",
        "shared_name" : "gen5 (interacts with) Wide Guard",
        "name" : "gen5 (interacts with) Wide Guard",
        "interaction" : "interacts with",
        "SUID" : 3947,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3943",
        "source" : "3591",
        "target" : "3941",
        "shared_name" : "gen5 (interacts with) Water Pledge",
        "name" : "gen5 (interacts with) Water Pledge",
        "interaction" : "interacts with",
        "SUID" : 3943,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3939",
        "source" : "3591",
        "target" : "3937",
        "shared_name" : "gen5 (interacts with) Volt Switch",
        "name" : "gen5 (interacts with) Volt Switch",
        "interaction" : "interacts with",
        "SUID" : 3939,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3935",
        "source" : "3591",
        "target" : "3933",
        "shared_name" : "gen5 (interacts with) Venoshock",
        "name" : "gen5 (interacts with) Venoshock",
        "interaction" : "interacts with",
        "SUID" : 3935,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3931",
        "source" : "3591",
        "target" : "3929",
        "shared_name" : "gen5 (interacts with) V-create",
        "name" : "gen5 (interacts with) V-create",
        "interaction" : "interacts with",
        "SUID" : 3931,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3927",
        "source" : "3591",
        "target" : "3925",
        "shared_name" : "gen5 (interacts with) Telekinesis",
        "name" : "gen5 (interacts with) Telekinesis",
        "interaction" : "interacts with",
        "SUID" : 3927,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3923",
        "source" : "3591",
        "target" : "3921",
        "shared_name" : "gen5 (interacts with) Techno Blast",
        "name" : "gen5 (interacts with) Techno Blast",
        "interaction" : "interacts with",
        "SUID" : 3923,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3919",
        "source" : "3591",
        "target" : "3917",
        "shared_name" : "gen5 (interacts with) Tail Slap",
        "name" : "gen5 (interacts with) Tail Slap",
        "interaction" : "interacts with",
        "SUID" : 3919,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3915",
        "source" : "3591",
        "target" : "3913",
        "shared_name" : "gen5 (interacts with) Synchronoise",
        "name" : "gen5 (interacts with) Synchronoise",
        "interaction" : "interacts with",
        "SUID" : 3915,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3911",
        "source" : "3591",
        "target" : "3909",
        "shared_name" : "gen5 (interacts with) Struggle Bug",
        "name" : "gen5 (interacts with) Struggle Bug",
        "interaction" : "interacts with",
        "SUID" : 3911,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3907",
        "source" : "3591",
        "target" : "3905",
        "shared_name" : "gen5 (interacts with) Storm Throw",
        "name" : "gen5 (interacts with) Storm Throw",
        "interaction" : "interacts with",
        "SUID" : 3907,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3903",
        "source" : "3591",
        "target" : "3901",
        "shared_name" : "gen5 (interacts with) Stored Power",
        "name" : "gen5 (interacts with) Stored Power",
        "interaction" : "interacts with",
        "SUID" : 3903,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3899",
        "source" : "3591",
        "target" : "3897",
        "shared_name" : "gen5 (interacts with) Steamroller",
        "name" : "gen5 (interacts with) Steamroller",
        "interaction" : "interacts with",
        "SUID" : 3899,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3895",
        "source" : "3591",
        "target" : "3893",
        "shared_name" : "gen5 (interacts with) Soak",
        "name" : "gen5 (interacts with) Soak",
        "interaction" : "interacts with",
        "SUID" : 3895,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3891",
        "source" : "3591",
        "target" : "3889",
        "shared_name" : "gen5 (interacts with) Snarl",
        "name" : "gen5 (interacts with) Snarl",
        "interaction" : "interacts with",
        "SUID" : 3891,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3887",
        "source" : "3591",
        "target" : "3885",
        "shared_name" : "gen5 (interacts with) Smack Down",
        "name" : "gen5 (interacts with) Smack Down",
        "interaction" : "interacts with",
        "SUID" : 3887,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3883",
        "source" : "3591",
        "target" : "3881",
        "shared_name" : "gen5 (interacts with) Sludge Wave",
        "name" : "gen5 (interacts with) Sludge Wave",
        "interaction" : "interacts with",
        "SUID" : 3883,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3879",
        "source" : "3591",
        "target" : "3877",
        "shared_name" : "gen5 (interacts with) Sky Drop",
        "name" : "gen5 (interacts with) Sky Drop",
        "interaction" : "interacts with",
        "SUID" : 3879,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3875",
        "source" : "3591",
        "target" : "3873",
        "shared_name" : "gen5 (interacts with) Simple Beam",
        "name" : "gen5 (interacts with) Simple Beam",
        "interaction" : "interacts with",
        "SUID" : 3875,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3871",
        "source" : "3591",
        "target" : "3869",
        "shared_name" : "gen5 (interacts with) Shift Gear",
        "name" : "gen5 (interacts with) Shift Gear",
        "interaction" : "interacts with",
        "SUID" : 3871,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3867",
        "source" : "3591",
        "target" : "3865",
        "shared_name" : "gen5 (interacts with) Shell Smash",
        "name" : "gen5 (interacts with) Shell Smash",
        "interaction" : "interacts with",
        "SUID" : 3867,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3863",
        "source" : "3591",
        "target" : "3861",
        "shared_name" : "gen5 (interacts with) Secret Sword",
        "name" : "gen5 (interacts with) Secret Sword",
        "interaction" : "interacts with",
        "SUID" : 3863,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3859",
        "source" : "3591",
        "target" : "3857",
        "shared_name" : "gen5 (interacts with) Searing Shot",
        "name" : "gen5 (interacts with) Searing Shot",
        "interaction" : "interacts with",
        "SUID" : 3859,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3855",
        "source" : "3591",
        "target" : "3853",
        "shared_name" : "gen5 (interacts with) Scald",
        "name" : "gen5 (interacts with) Scald",
        "interaction" : "interacts with",
        "SUID" : 3855,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3851",
        "source" : "3591",
        "target" : "3849",
        "shared_name" : "gen5 (interacts with) Sacred Sword",
        "name" : "gen5 (interacts with) Sacred Sword",
        "interaction" : "interacts with",
        "SUID" : 3851,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3847",
        "source" : "3591",
        "target" : "3845",
        "shared_name" : "gen5 (interacts with) Round",
        "name" : "gen5 (interacts with) Round",
        "interaction" : "interacts with",
        "SUID" : 3847,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3843",
        "source" : "3591",
        "target" : "3841",
        "shared_name" : "gen5 (interacts with) Retaliate",
        "name" : "gen5 (interacts with) Retaliate",
        "interaction" : "interacts with",
        "SUID" : 3843,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3839",
        "source" : "3591",
        "target" : "3837",
        "shared_name" : "gen5 (interacts with) Relic Song",
        "name" : "gen5 (interacts with) Relic Song",
        "interaction" : "interacts with",
        "SUID" : 3839,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3835",
        "source" : "3591",
        "target" : "3833",
        "shared_name" : "gen5 (interacts with) Reflect Type",
        "name" : "gen5 (interacts with) Reflect Type",
        "interaction" : "interacts with",
        "SUID" : 3835,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3831",
        "source" : "3591",
        "target" : "3829",
        "shared_name" : "gen5 (interacts with) Razor Shell",
        "name" : "gen5 (interacts with) Razor Shell",
        "interaction" : "interacts with",
        "SUID" : 3831,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3827",
        "source" : "3591",
        "target" : "3825",
        "shared_name" : "gen5 (interacts with) Rage Powder",
        "name" : "gen5 (interacts with) Rage Powder",
        "interaction" : "interacts with",
        "SUID" : 3827,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3823",
        "source" : "3591",
        "target" : "3821",
        "shared_name" : "gen5 (interacts with) Quiver Dance",
        "name" : "gen5 (interacts with) Quiver Dance",
        "interaction" : "interacts with",
        "SUID" : 3823,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3819",
        "source" : "3591",
        "target" : "3817",
        "shared_name" : "gen5 (interacts with) Quick Guard",
        "name" : "gen5 (interacts with) Quick Guard",
        "interaction" : "interacts with",
        "SUID" : 3819,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3815",
        "source" : "3591",
        "target" : "3813",
        "shared_name" : "gen5 (interacts with) Quash",
        "name" : "gen5 (interacts with) Quash",
        "interaction" : "interacts with",
        "SUID" : 3815,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3811",
        "source" : "3591",
        "target" : "3809",
        "shared_name" : "gen5 (interacts with) Psystrike",
        "name" : "gen5 (interacts with) Psystrike",
        "interaction" : "interacts with",
        "SUID" : 3811,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3807",
        "source" : "3591",
        "target" : "3805",
        "shared_name" : "gen5 (interacts with) Psyshock",
        "name" : "gen5 (interacts with) Psyshock",
        "interaction" : "interacts with",
        "SUID" : 3807,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3803",
        "source" : "3591",
        "target" : "3801",
        "shared_name" : "gen5 (interacts with) Power Split",
        "name" : "gen5 (interacts with) Power Split",
        "interaction" : "interacts with",
        "SUID" : 3803,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3799",
        "source" : "3591",
        "target" : "3797",
        "shared_name" : "gen5 (interacts with) Night Daze",
        "name" : "gen5 (interacts with) Night Daze",
        "interaction" : "interacts with",
        "SUID" : 3799,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3795",
        "source" : "3591",
        "target" : "3793",
        "shared_name" : "gen5 (interacts with) Magic Room",
        "name" : "gen5 (interacts with) Magic Room",
        "interaction" : "interacts with",
        "SUID" : 3795,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3791",
        "source" : "3591",
        "target" : "3789",
        "shared_name" : "gen5 (interacts with) Low Sweep",
        "name" : "gen5 (interacts with) Low Sweep",
        "interaction" : "interacts with",
        "SUID" : 3791,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3787",
        "source" : "3591",
        "target" : "3785",
        "shared_name" : "gen5 (interacts with) Leaf Tornado",
        "name" : "gen5 (interacts with) Leaf Tornado",
        "interaction" : "interacts with",
        "SUID" : 3787,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3783",
        "source" : "3591",
        "target" : "3781",
        "shared_name" : "gen5 (interacts with) Inferno",
        "name" : "gen5 (interacts with) Inferno",
        "interaction" : "interacts with",
        "SUID" : 3783,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3779",
        "source" : "3591",
        "target" : "3777",
        "shared_name" : "gen5 (interacts with) Incinerate",
        "name" : "gen5 (interacts with) Incinerate",
        "interaction" : "interacts with",
        "SUID" : 3779,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3775",
        "source" : "3591",
        "target" : "3773",
        "shared_name" : "gen5 (interacts with) Icicle Crash",
        "name" : "gen5 (interacts with) Icicle Crash",
        "interaction" : "interacts with",
        "SUID" : 3775,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3771",
        "source" : "3591",
        "target" : "3769",
        "shared_name" : "gen5 (interacts with) Ice Burn",
        "name" : "gen5 (interacts with) Ice Burn",
        "interaction" : "interacts with",
        "SUID" : 3771,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3767",
        "source" : "3591",
        "target" : "3765",
        "shared_name" : "gen5 (interacts with) Hurricane",
        "name" : "gen5 (interacts with) Hurricane",
        "interaction" : "interacts with",
        "SUID" : 3767,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3763",
        "source" : "3591",
        "target" : "3761",
        "shared_name" : "gen5 (interacts with) Horn Leech",
        "name" : "gen5 (interacts with) Horn Leech",
        "interaction" : "interacts with",
        "SUID" : 3763,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3759",
        "source" : "3591",
        "target" : "3757",
        "shared_name" : "gen5 (interacts with) Hone Claws",
        "name" : "gen5 (interacts with) Hone Claws",
        "interaction" : "interacts with",
        "SUID" : 3759,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3755",
        "source" : "3591",
        "target" : "3753",
        "shared_name" : "gen5 (interacts with) Hex",
        "name" : "gen5 (interacts with) Hex",
        "interaction" : "interacts with",
        "SUID" : 3755,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3751",
        "source" : "3591",
        "target" : "3749",
        "shared_name" : "gen5 (interacts with) Heavy Slam",
        "name" : "gen5 (interacts with) Heavy Slam",
        "interaction" : "interacts with",
        "SUID" : 3751,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3747",
        "source" : "3591",
        "target" : "3745",
        "shared_name" : "gen5 (interacts with) Heat Crash",
        "name" : "gen5 (interacts with) Heat Crash",
        "interaction" : "interacts with",
        "SUID" : 3747,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3743",
        "source" : "3591",
        "target" : "3741",
        "shared_name" : "gen5 (interacts with) Heart Stamp",
        "name" : "gen5 (interacts with) Heart Stamp",
        "interaction" : "interacts with",
        "SUID" : 3743,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3739",
        "source" : "3591",
        "target" : "3737",
        "shared_name" : "gen5 (interacts with) Heal Pulse",
        "name" : "gen5 (interacts with) Heal Pulse",
        "interaction" : "interacts with",
        "SUID" : 3739,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3735",
        "source" : "3591",
        "target" : "3733",
        "shared_name" : "gen5 (interacts with) Head Charge",
        "name" : "gen5 (interacts with) Head Charge",
        "interaction" : "interacts with",
        "SUID" : 3735,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3731",
        "source" : "3591",
        "target" : "3729",
        "shared_name" : "gen5 (interacts with) Guard Split",
        "name" : "gen5 (interacts with) Guard Split",
        "interaction" : "interacts with",
        "SUID" : 3731,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3727",
        "source" : "3591",
        "target" : "3725",
        "shared_name" : "gen5 (interacts with) Grass Pledge",
        "name" : "gen5 (interacts with) Grass Pledge",
        "interaction" : "interacts with",
        "SUID" : 3727,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3723",
        "source" : "3591",
        "target" : "3721",
        "shared_name" : "gen5 (interacts with) Glaciate",
        "name" : "gen5 (interacts with) Glaciate",
        "interaction" : "interacts with",
        "SUID" : 3723,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3719",
        "source" : "3591",
        "target" : "3717",
        "shared_name" : "gen5 (interacts with) Gear Grind",
        "name" : "gen5 (interacts with) Gear Grind",
        "interaction" : "interacts with",
        "SUID" : 3719,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3715",
        "source" : "3591",
        "target" : "3713",
        "shared_name" : "gen5 (interacts with) Fusion Flare",
        "name" : "gen5 (interacts with) Fusion Flare",
        "interaction" : "interacts with",
        "SUID" : 3715,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3711",
        "source" : "3591",
        "target" : "3709",
        "shared_name" : "gen5 (interacts with) Fusion Bolt",
        "name" : "gen5 (interacts with) Fusion Bolt",
        "interaction" : "interacts with",
        "SUID" : 3711,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3707",
        "source" : "3591",
        "target" : "3705",
        "shared_name" : "gen5 (interacts with) Frost Breath",
        "name" : "gen5 (interacts with) Frost Breath",
        "interaction" : "interacts with",
        "SUID" : 3707,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3703",
        "source" : "3591",
        "target" : "3701",
        "shared_name" : "gen5 (interacts with) Freeze Shock",
        "name" : "gen5 (interacts with) Freeze Shock",
        "interaction" : "interacts with",
        "SUID" : 3703,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3699",
        "source" : "3591",
        "target" : "3697",
        "shared_name" : "gen5 (interacts with) Foul Play",
        "name" : "gen5 (interacts with) Foul Play",
        "interaction" : "interacts with",
        "SUID" : 3699,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3695",
        "source" : "3591",
        "target" : "3693",
        "shared_name" : "gen5 (interacts with) Flame Charge",
        "name" : "gen5 (interacts with) Flame Charge",
        "interaction" : "interacts with",
        "SUID" : 3695,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3691",
        "source" : "3591",
        "target" : "3689",
        "shared_name" : "gen5 (interacts with) Flame Burst",
        "name" : "gen5 (interacts with) Flame Burst",
        "interaction" : "interacts with",
        "SUID" : 3691,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3687",
        "source" : "3591",
        "target" : "3685",
        "shared_name" : "gen5 (interacts with) Fire Pledge",
        "name" : "gen5 (interacts with) Fire Pledge",
        "interaction" : "interacts with",
        "SUID" : 3687,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3683",
        "source" : "3591",
        "target" : "3681",
        "shared_name" : "gen5 (interacts with) Final Gambit",
        "name" : "gen5 (interacts with) Final Gambit",
        "interaction" : "interacts with",
        "SUID" : 3683,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3679",
        "source" : "3591",
        "target" : "3677",
        "shared_name" : "gen5 (interacts with) Fiery Dance",
        "name" : "gen5 (interacts with) Fiery Dance",
        "interaction" : "interacts with",
        "SUID" : 3679,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3675",
        "source" : "3591",
        "target" : "3673",
        "shared_name" : "gen5 (interacts with) Entrainment",
        "name" : "gen5 (interacts with) Entrainment",
        "interaction" : "interacts with",
        "SUID" : 3675,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3671",
        "source" : "3591",
        "target" : "3669",
        "shared_name" : "gen5 (interacts with) Electroweb",
        "name" : "gen5 (interacts with) Electroweb",
        "interaction" : "interacts with",
        "SUID" : 3671,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3667",
        "source" : "3591",
        "target" : "3665",
        "shared_name" : "gen5 (interacts with) Electro Ball",
        "name" : "gen5 (interacts with) Electro Ball",
        "interaction" : "interacts with",
        "SUID" : 3667,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3663",
        "source" : "3591",
        "target" : "3661",
        "shared_name" : "gen5 (interacts with) Echoed Voice",
        "name" : "gen5 (interacts with) Echoed Voice",
        "interaction" : "interacts with",
        "SUID" : 3663,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3659",
        "source" : "3591",
        "target" : "3657",
        "shared_name" : "gen5 (interacts with) Dual Chop",
        "name" : "gen5 (interacts with) Dual Chop",
        "interaction" : "interacts with",
        "SUID" : 3659,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3655",
        "source" : "3591",
        "target" : "3653",
        "shared_name" : "gen5 (interacts with) Drill Run",
        "name" : "gen5 (interacts with) Drill Run",
        "interaction" : "interacts with",
        "SUID" : 3655,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3651",
        "source" : "3591",
        "target" : "3649",
        "shared_name" : "gen5 (interacts with) Dragon Tail",
        "name" : "gen5 (interacts with) Dragon Tail",
        "interaction" : "interacts with",
        "SUID" : 3651,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3647",
        "source" : "3591",
        "target" : "3645",
        "shared_name" : "gen5 (interacts with) Cotton Guard",
        "name" : "gen5 (interacts with) Cotton Guard",
        "interaction" : "interacts with",
        "SUID" : 3647,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3643",
        "source" : "3591",
        "target" : "3641",
        "shared_name" : "gen5 (interacts with) Coil",
        "name" : "gen5 (interacts with) Coil",
        "interaction" : "interacts with",
        "SUID" : 3643,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3639",
        "source" : "3591",
        "target" : "3637",
        "shared_name" : "gen5 (interacts with) Clear Smog",
        "name" : "gen5 (interacts with) Clear Smog",
        "interaction" : "interacts with",
        "SUID" : 3639,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3635",
        "source" : "3591",
        "target" : "3633",
        "shared_name" : "gen5 (interacts with) Circle Throw",
        "name" : "gen5 (interacts with) Circle Throw",
        "interaction" : "interacts with",
        "SUID" : 3635,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3631",
        "source" : "3591",
        "target" : "3629",
        "shared_name" : "gen5 (interacts with) Chip Away",
        "name" : "gen5 (interacts with) Chip Away",
        "interaction" : "interacts with",
        "SUID" : 3631,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3627",
        "source" : "3591",
        "target" : "3625",
        "shared_name" : "gen5 (interacts with) Bulldoze",
        "name" : "gen5 (interacts with) Bulldoze",
        "interaction" : "interacts with",
        "SUID" : 3627,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3623",
        "source" : "3591",
        "target" : "3621",
        "shared_name" : "gen5 (interacts with) Bolt Strike",
        "name" : "gen5 (interacts with) Bolt Strike",
        "interaction" : "interacts with",
        "SUID" : 3623,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3619",
        "source" : "3591",
        "target" : "3617",
        "shared_name" : "gen5 (interacts with) Blue Flare",
        "name" : "gen5 (interacts with) Blue Flare",
        "interaction" : "interacts with",
        "SUID" : 3619,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3615",
        "source" : "3591",
        "target" : "3613",
        "shared_name" : "gen5 (interacts with) Bestow",
        "name" : "gen5 (interacts with) Bestow",
        "interaction" : "interacts with",
        "SUID" : 3615,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3611",
        "source" : "3591",
        "target" : "3609",
        "shared_name" : "gen5 (interacts with) Autotomize",
        "name" : "gen5 (interacts with) Autotomize",
        "interaction" : "interacts with",
        "SUID" : 3611,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3607",
        "source" : "3591",
        "target" : "3605",
        "shared_name" : "gen5 (interacts with) Ally Switch",
        "name" : "gen5 (interacts with) Ally Switch",
        "interaction" : "interacts with",
        "SUID" : 3607,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3603",
        "source" : "3591",
        "target" : "3601",
        "shared_name" : "gen5 (interacts with) After You",
        "name" : "gen5 (interacts with) After You",
        "interaction" : "interacts with",
        "SUID" : 3603,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3599",
        "source" : "3591",
        "target" : "3597",
        "shared_name" : "gen5 (interacts with) Acrobatics",
        "name" : "gen5 (interacts with) Acrobatics",
        "interaction" : "interacts with",
        "SUID" : 3599,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3595",
        "source" : "3591",
        "target" : "3593",
        "shared_name" : "gen5 (interacts with) Acid Spray",
        "name" : "gen5 (interacts with) Acid Spray",
        "interaction" : "interacts with",
        "SUID" : 3595,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3589",
        "source" : "3313",
        "target" : "3587",
        "shared_name" : "gen9 (interacts with) Wicked Torque",
        "name" : "gen9 (interacts with) Wicked Torque",
        "interaction" : "interacts with",
        "SUID" : 3589,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3585",
        "source" : "3313",
        "target" : "3583",
        "shared_name" : "gen9 (interacts with) Upper Hand",
        "name" : "gen9 (interacts with) Upper Hand",
        "interaction" : "interacts with",
        "SUID" : 3585,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3581",
        "source" : "3313",
        "target" : "3579",
        "shared_name" : "gen9 (interacts with) Twin Beam",
        "name" : "gen9 (interacts with) Twin Beam",
        "interaction" : "interacts with",
        "SUID" : 3581,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3577",
        "source" : "3313",
        "target" : "3575",
        "shared_name" : "gen9 (interacts with) Triple Dive",
        "name" : "gen9 (interacts with) Triple Dive",
        "interaction" : "interacts with",
        "SUID" : 3577,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3573",
        "source" : "3313",
        "target" : "3571",
        "shared_name" : "gen9 (interacts with) Trailblaze",
        "name" : "gen9 (interacts with) Trailblaze",
        "interaction" : "interacts with",
        "SUID" : 3573,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3569",
        "source" : "3313",
        "target" : "3567",
        "shared_name" : "gen9 (interacts with) Torch Song",
        "name" : "gen9 (interacts with) Torch Song",
        "interaction" : "interacts with",
        "SUID" : 3569,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3565",
        "source" : "3313",
        "target" : "3563",
        "shared_name" : "gen9 (interacts with) Tidy Up",
        "name" : "gen9 (interacts with) Tidy Up",
        "interaction" : "interacts with",
        "SUID" : 3565,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3561",
        "source" : "3313",
        "target" : "3559",
        "shared_name" : "gen9 (interacts with) Thunderclap",
        "name" : "gen9 (interacts with) Thunderclap",
        "interaction" : "interacts with",
        "SUID" : 3561,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3557",
        "source" : "3313",
        "target" : "3555",
        "shared_name" : "gen9 (interacts with) Tera Starstorm",
        "name" : "gen9 (interacts with) Tera Starstorm",
        "interaction" : "interacts with",
        "SUID" : 3557,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3553",
        "source" : "3313",
        "target" : "3551",
        "shared_name" : "gen9 (interacts with) Tera Blast",
        "name" : "gen9 (interacts with) Tera Blast",
        "interaction" : "interacts with",
        "SUID" : 3553,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3549",
        "source" : "3313",
        "target" : "3547",
        "shared_name" : "gen9 (interacts with) Temper Flare",
        "name" : "gen9 (interacts with) Temper Flare",
        "interaction" : "interacts with",
        "SUID" : 3549,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3545",
        "source" : "3313",
        "target" : "3543",
        "shared_name" : "gen9 (interacts with) Tachyon Cutter",
        "name" : "gen9 (interacts with) Tachyon Cutter",
        "interaction" : "interacts with",
        "SUID" : 3545,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3541",
        "source" : "3313",
        "target" : "3539",
        "shared_name" : "gen9 (interacts with) Syrup Bomb",
        "name" : "gen9 (interacts with) Syrup Bomb",
        "interaction" : "interacts with",
        "SUID" : 3541,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3537",
        "source" : "3313",
        "target" : "3535",
        "shared_name" : "gen9 (interacts with) Supercell Slam",
        "name" : "gen9 (interacts with) Supercell Slam",
        "interaction" : "interacts with",
        "SUID" : 3537,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3533",
        "source" : "3313",
        "target" : "3531",
        "shared_name" : "gen9 (interacts with) Spin Out",
        "name" : "gen9 (interacts with) Spin Out",
        "interaction" : "interacts with",
        "SUID" : 3533,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3529",
        "source" : "3313",
        "target" : "3527",
        "shared_name" : "gen9 (interacts with) Spicy Extract",
        "name" : "gen9 (interacts with) Spicy Extract",
        "interaction" : "interacts with",
        "SUID" : 3529,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3525",
        "source" : "3313",
        "target" : "3523",
        "shared_name" : "gen9 (interacts with) Snowscape",
        "name" : "gen9 (interacts with) Snowscape",
        "interaction" : "interacts with",
        "SUID" : 3525,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3521",
        "source" : "3313",
        "target" : "3519",
        "shared_name" : "gen9 (interacts with) Silk Trap",
        "name" : "gen9 (interacts with) Silk Trap",
        "interaction" : "interacts with",
        "SUID" : 3521,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3517",
        "source" : "3313",
        "target" : "3515",
        "shared_name" : "gen9 (interacts with) Shed Tail",
        "name" : "gen9 (interacts with) Shed Tail",
        "interaction" : "interacts with",
        "SUID" : 3517,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3513",
        "source" : "3313",
        "target" : "3511",
        "shared_name" : "gen9 (interacts with) Salt Cure",
        "name" : "gen9 (interacts with) Salt Cure",
        "interaction" : "interacts with",
        "SUID" : 3513,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3509",
        "source" : "3313",
        "target" : "3507",
        "shared_name" : "gen9 (interacts with) Ruination",
        "name" : "gen9 (interacts with) Ruination",
        "interaction" : "interacts with",
        "SUID" : 3509,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3505",
        "source" : "3313",
        "target" : "3503",
        "shared_name" : "gen9 (interacts with) Revival Blessing",
        "name" : "gen9 (interacts with) Revival Blessing",
        "interaction" : "interacts with",
        "SUID" : 3505,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3501",
        "source" : "3313",
        "target" : "3499",
        "shared_name" : "gen9 (interacts with) Raging Bull",
        "name" : "gen9 (interacts with) Raging Bull",
        "interaction" : "interacts with",
        "SUID" : 3501,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3497",
        "source" : "3313",
        "target" : "3495",
        "shared_name" : "gen9 (interacts with) Rage Fist",
        "name" : "gen9 (interacts with) Rage Fist",
        "interaction" : "interacts with",
        "SUID" : 3497,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3493",
        "source" : "3313",
        "target" : "3491",
        "shared_name" : "gen9 (interacts with) Psychic Noise",
        "name" : "gen9 (interacts with) Psychic Noise",
        "interaction" : "interacts with",
        "SUID" : 3493,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3489",
        "source" : "3313",
        "target" : "3487",
        "shared_name" : "gen9 (interacts with) Psyblade",
        "name" : "gen9 (interacts with) Psyblade",
        "interaction" : "interacts with",
        "SUID" : 3489,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3485",
        "source" : "3313",
        "target" : "3483",
        "shared_name" : "gen9 (interacts with) Pounce",
        "name" : "gen9 (interacts with) Pounce",
        "interaction" : "interacts with",
        "SUID" : 3485,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3481",
        "source" : "3313",
        "target" : "3479",
        "shared_name" : "gen9 (interacts with) Population Bomb",
        "name" : "gen9 (interacts with) Population Bomb",
        "interaction" : "interacts with",
        "SUID" : 3481,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3477",
        "source" : "3313",
        "target" : "3475",
        "shared_name" : "gen9 (interacts with) Order Up",
        "name" : "gen9 (interacts with) Order Up",
        "interaction" : "interacts with",
        "SUID" : 3477,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3473",
        "source" : "3313",
        "target" : "3471",
        "shared_name" : "gen9 (interacts with) Noxious Torque",
        "name" : "gen9 (interacts with) Noxious Torque",
        "interaction" : "interacts with",
        "SUID" : 3473,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3469",
        "source" : "3313",
        "target" : "3467",
        "shared_name" : "gen9 (interacts with) Mortal Spin",
        "name" : "gen9 (interacts with) Mortal Spin",
        "interaction" : "interacts with",
        "SUID" : 3469,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3465",
        "source" : "3313",
        "target" : "3463",
        "shared_name" : "gen9 (interacts with) Mighty Cleave",
        "name" : "gen9 (interacts with) Mighty Cleave",
        "interaction" : "interacts with",
        "SUID" : 3465,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3461",
        "source" : "3313",
        "target" : "3459",
        "shared_name" : "gen9 (interacts with) Matcha Gotcha",
        "name" : "gen9 (interacts with) Matcha Gotcha",
        "interaction" : "interacts with",
        "SUID" : 3461,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3457",
        "source" : "3313",
        "target" : "3455",
        "shared_name" : "gen9 (interacts with) Malignant Chain",
        "name" : "gen9 (interacts with) Malignant Chain",
        "interaction" : "interacts with",
        "SUID" : 3457,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3453",
        "source" : "3313",
        "target" : "3451",
        "shared_name" : "gen9 (interacts with) Make It Rain",
        "name" : "gen9 (interacts with) Make It Rain",
        "interaction" : "interacts with",
        "SUID" : 3453,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3449",
        "source" : "3313",
        "target" : "3447",
        "shared_name" : "gen9 (interacts with) Magical Torque",
        "name" : "gen9 (interacts with) Magical Torque",
        "interaction" : "interacts with",
        "SUID" : 3449,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3445",
        "source" : "3313",
        "target" : "3443",
        "shared_name" : "gen9 (interacts with) Lumina Crash",
        "name" : "gen9 (interacts with) Lumina Crash",
        "interaction" : "interacts with",
        "SUID" : 3445,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3441",
        "source" : "3313",
        "target" : "3439",
        "shared_name" : "gen9 (interacts with) Last Respects",
        "name" : "gen9 (interacts with) Last Respects",
        "interaction" : "interacts with",
        "SUID" : 3441,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3437",
        "source" : "3313",
        "target" : "3435",
        "shared_name" : "gen9 (interacts with) Kowtow Cleave",
        "name" : "gen9 (interacts with) Kowtow Cleave",
        "interaction" : "interacts with",
        "SUID" : 3437,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3433",
        "source" : "3313",
        "target" : "3431",
        "shared_name" : "gen9 (interacts with) Jet Punch",
        "name" : "gen9 (interacts with) Jet Punch",
        "interaction" : "interacts with",
        "SUID" : 3433,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3429",
        "source" : "3313",
        "target" : "3427",
        "shared_name" : "gen9 (interacts with) Ivy Cudgel",
        "name" : "gen9 (interacts with) Ivy Cudgel",
        "interaction" : "interacts with",
        "SUID" : 3429,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3425",
        "source" : "3313",
        "target" : "3423",
        "shared_name" : "gen9 (interacts with) Ice Spinner",
        "name" : "gen9 (interacts with) Ice Spinner",
        "interaction" : "interacts with",
        "SUID" : 3425,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3421",
        "source" : "3313",
        "target" : "3419",
        "shared_name" : "gen9 (interacts with) Hyper Drill",
        "name" : "gen9 (interacts with) Hyper Drill",
        "interaction" : "interacts with",
        "SUID" : 3421,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3417",
        "source" : "3313",
        "target" : "3415",
        "shared_name" : "gen9 (interacts with) Hydro Steam",
        "name" : "gen9 (interacts with) Hydro Steam",
        "interaction" : "interacts with",
        "SUID" : 3417,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3413",
        "source" : "3313",
        "target" : "3411",
        "shared_name" : "gen9 (interacts with) Hard Press",
        "name" : "gen9 (interacts with) Hard Press",
        "interaction" : "interacts with",
        "SUID" : 3413,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3409",
        "source" : "3313",
        "target" : "3407",
        "shared_name" : "gen9 (interacts with) Glaive Rush",
        "name" : "gen9 (interacts with) Glaive Rush",
        "interaction" : "interacts with",
        "SUID" : 3409,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3405",
        "source" : "3313",
        "target" : "3403",
        "shared_name" : "gen9 (interacts with) Gigaton Hammer",
        "name" : "gen9 (interacts with) Gigaton Hammer",
        "interaction" : "interacts with",
        "SUID" : 3405,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3401",
        "source" : "3313",
        "target" : "3399",
        "shared_name" : "gen9 (interacts with) Flower Trick",
        "name" : "gen9 (interacts with) Flower Trick",
        "interaction" : "interacts with",
        "SUID" : 3401,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3397",
        "source" : "3313",
        "target" : "3395",
        "shared_name" : "gen9 (interacts with) Fillet Away",
        "name" : "gen9 (interacts with) Fillet Away",
        "interaction" : "interacts with",
        "SUID" : 3397,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3393",
        "source" : "3313",
        "target" : "3391",
        "shared_name" : "gen9 (interacts with) Fickle Beam",
        "name" : "gen9 (interacts with) Fickle Beam",
        "interaction" : "interacts with",
        "SUID" : 3393,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3389",
        "source" : "3313",
        "target" : "3387",
        "shared_name" : "gen9 (interacts with) Electro Shot",
        "name" : "gen9 (interacts with) Electro Shot",
        "interaction" : "interacts with",
        "SUID" : 3389,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3385",
        "source" : "3313",
        "target" : "3383",
        "shared_name" : "gen9 (interacts with) Electro Drift",
        "name" : "gen9 (interacts with) Electro Drift",
        "interaction" : "interacts with",
        "SUID" : 3385,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3381",
        "source" : "3313",
        "target" : "3379",
        "shared_name" : "gen9 (interacts with) Dragon Cheer",
        "name" : "gen9 (interacts with) Dragon Cheer",
        "interaction" : "interacts with",
        "SUID" : 3381,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3377",
        "source" : "3313",
        "target" : "3375",
        "shared_name" : "gen9 (interacts with) Double Shock",
        "name" : "gen9 (interacts with) Double Shock",
        "interaction" : "interacts with",
        "SUID" : 3377,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3373",
        "source" : "3313",
        "target" : "3371",
        "shared_name" : "gen9 (interacts with) Doodle",
        "name" : "gen9 (interacts with) Doodle",
        "interaction" : "interacts with",
        "SUID" : 3373,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3369",
        "source" : "3313",
        "target" : "3367",
        "shared_name" : "gen9 (interacts with) Comeuppance",
        "name" : "gen9 (interacts with) Comeuppance",
        "interaction" : "interacts with",
        "SUID" : 3369,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3365",
        "source" : "3313",
        "target" : "3363",
        "shared_name" : "gen9 (interacts with) Combat Torque",
        "name" : "gen9 (interacts with) Combat Torque",
        "interaction" : "interacts with",
        "SUID" : 3365,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3361",
        "source" : "3313",
        "target" : "3359",
        "shared_name" : "gen9 (interacts with) Collision Course",
        "name" : "gen9 (interacts with) Collision Course",
        "interaction" : "interacts with",
        "SUID" : 3361,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3357",
        "source" : "3313",
        "target" : "3355",
        "shared_name" : "gen9 (interacts with) Chilly Reception",
        "name" : "gen9 (interacts with) Chilly Reception",
        "interaction" : "interacts with",
        "SUID" : 3357,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3353",
        "source" : "3313",
        "target" : "3351",
        "shared_name" : "gen9 (interacts with) Chilling Water",
        "name" : "gen9 (interacts with) Chilling Water",
        "interaction" : "interacts with",
        "SUID" : 3353,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3349",
        "source" : "3313",
        "target" : "3347",
        "shared_name" : "gen9 (interacts with) Burning Bulwark",
        "name" : "gen9 (interacts with) Burning Bulwark",
        "interaction" : "interacts with",
        "SUID" : 3349,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3345",
        "source" : "3313",
        "target" : "3343",
        "shared_name" : "gen9 (interacts with) Blood Moon",
        "name" : "gen9 (interacts with) Blood Moon",
        "interaction" : "interacts with",
        "SUID" : 3345,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3341",
        "source" : "3313",
        "target" : "3339",
        "shared_name" : "gen9 (interacts with) Blazing Torque",
        "name" : "gen9 (interacts with) Blazing Torque",
        "interaction" : "interacts with",
        "SUID" : 3341,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3337",
        "source" : "3313",
        "target" : "3335",
        "shared_name" : "gen9 (interacts with) Bitter Blade",
        "name" : "gen9 (interacts with) Bitter Blade",
        "interaction" : "interacts with",
        "SUID" : 3337,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3333",
        "source" : "3313",
        "target" : "3331",
        "shared_name" : "gen9 (interacts with) Axe Kick",
        "name" : "gen9 (interacts with) Axe Kick",
        "interaction" : "interacts with",
        "SUID" : 3333,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3329",
        "source" : "3313",
        "target" : "3327",
        "shared_name" : "gen9 (interacts with) Armor Cannon",
        "name" : "gen9 (interacts with) Armor Cannon",
        "interaction" : "interacts with",
        "SUID" : 3329,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3325",
        "source" : "3313",
        "target" : "3323",
        "shared_name" : "gen9 (interacts with) Aqua Step",
        "name" : "gen9 (interacts with) Aqua Step",
        "interaction" : "interacts with",
        "SUID" : 3325,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3321",
        "source" : "3313",
        "target" : "3319",
        "shared_name" : "gen9 (interacts with) Aqua Cutter",
        "name" : "gen9 (interacts with) Aqua Cutter",
        "interaction" : "interacts with",
        "SUID" : 3321,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3317",
        "source" : "3313",
        "target" : "3315",
        "shared_name" : "gen9 (interacts with) Alluring Voice",
        "name" : "gen9 (interacts with) Alluring Voice",
        "interaction" : "interacts with",
        "SUID" : 3317,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3311",
        "source" : "2747",
        "target" : "3309",
        "shared_name" : "gen8 (interacts with) Wildbolt Storm",
        "name" : "gen8 (interacts with) Wildbolt Storm",
        "interaction" : "interacts with",
        "SUID" : 3311,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3307",
        "source" : "2747",
        "target" : "3305",
        "shared_name" : "gen8 (interacts with) Wicked Blow",
        "name" : "gen8 (interacts with) Wicked Blow",
        "interaction" : "interacts with",
        "SUID" : 3307,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3303",
        "source" : "2747",
        "target" : "3301",
        "shared_name" : "gen8 (interacts with) Wave Crash",
        "name" : "gen8 (interacts with) Wave Crash",
        "interaction" : "interacts with",
        "SUID" : 3303,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3299",
        "source" : "2747",
        "target" : "3297",
        "shared_name" : "gen8 (interacts with) Victory Dance",
        "name" : "gen8 (interacts with) Victory Dance",
        "interaction" : "interacts with",
        "SUID" : 3299,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3295",
        "source" : "2747",
        "target" : "3293",
        "shared_name" : "gen8 (interacts with) Triple Axel",
        "name" : "gen8 (interacts with) Triple Axel",
        "interaction" : "interacts with",
        "SUID" : 3295,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3291",
        "source" : "2747",
        "target" : "3289",
        "shared_name" : "gen8 (interacts with) Triple Arrows",
        "name" : "gen8 (interacts with) Triple Arrows",
        "interaction" : "interacts with",
        "SUID" : 3291,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3287",
        "source" : "2747",
        "target" : "3285",
        "shared_name" : "gen8 (interacts with) Thunderous Kick",
        "name" : "gen8 (interacts with) Thunderous Kick",
        "interaction" : "interacts with",
        "SUID" : 3287,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3283",
        "source" : "2747",
        "target" : "3281",
        "shared_name" : "gen8 (interacts with) Thunder Cage",
        "name" : "gen8 (interacts with) Thunder Cage",
        "interaction" : "interacts with",
        "SUID" : 3283,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3279",
        "source" : "2747",
        "target" : "3277",
        "shared_name" : "gen8 (interacts with) Terrain Pulse",
        "name" : "gen8 (interacts with) Terrain Pulse",
        "interaction" : "interacts with",
        "SUID" : 3279,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3275",
        "source" : "2747",
        "target" : "3273",
        "shared_name" : "gen8 (interacts with) Teatime",
        "name" : "gen8 (interacts with) Teatime",
        "interaction" : "interacts with",
        "SUID" : 3275,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3271",
        "source" : "2747",
        "target" : "3269",
        "shared_name" : "gen8 (interacts with) Tar Shot",
        "name" : "gen8 (interacts with) Tar Shot",
        "interaction" : "interacts with",
        "SUID" : 3271,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3267",
        "source" : "2747",
        "target" : "3265",
        "shared_name" : "gen8 (interacts with) Take Heart",
        "name" : "gen8 (interacts with) Take Heart",
        "interaction" : "interacts with",
        "SUID" : 3267,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3263",
        "source" : "2747",
        "target" : "3261",
        "shared_name" : "gen8 (interacts with) Surging Strikes",
        "name" : "gen8 (interacts with) Surging Strikes",
        "interaction" : "interacts with",
        "SUID" : 3263,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3259",
        "source" : "2747",
        "target" : "3257",
        "shared_name" : "gen8 (interacts with) Stuff Cheeks",
        "name" : "gen8 (interacts with) Stuff Cheeks",
        "interaction" : "interacts with",
        "SUID" : 3259,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3255",
        "source" : "2747",
        "target" : "3253",
        "shared_name" : "gen8 (interacts with) Strange Steam",
        "name" : "gen8 (interacts with) Strange Steam",
        "interaction" : "interacts with",
        "SUID" : 3255,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3251",
        "source" : "2747",
        "target" : "3249",
        "shared_name" : "gen8 (interacts with) Stone Axe",
        "name" : "gen8 (interacts with) Stone Axe",
        "interaction" : "interacts with",
        "SUID" : 3251,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3247",
        "source" : "2747",
        "target" : "3245",
        "shared_name" : "gen8 (interacts with) Steel Roller",
        "name" : "gen8 (interacts with) Steel Roller",
        "interaction" : "interacts with",
        "SUID" : 3247,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3243",
        "source" : "2747",
        "target" : "3241",
        "shared_name" : "gen8 (interacts with) Steel Beam",
        "name" : "gen8 (interacts with) Steel Beam",
        "interaction" : "interacts with",
        "SUID" : 3243,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3239",
        "source" : "2747",
        "target" : "3237",
        "shared_name" : "gen8 (interacts with) Springtide Storm",
        "name" : "gen8 (interacts with) Springtide Storm",
        "interaction" : "interacts with",
        "SUID" : 3239,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3235",
        "source" : "2747",
        "target" : "3233",
        "shared_name" : "gen8 (interacts with) Spirit Break",
        "name" : "gen8 (interacts with) Spirit Break",
        "interaction" : "interacts with",
        "SUID" : 3235,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3231",
        "source" : "2747",
        "target" : "3229",
        "shared_name" : "gen8 (interacts with) Snipe Shot",
        "name" : "gen8 (interacts with) Snipe Shot",
        "interaction" : "interacts with",
        "SUID" : 3231,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3227",
        "source" : "2747",
        "target" : "3225",
        "shared_name" : "gen8 (interacts with) Snap Trap",
        "name" : "gen8 (interacts with) Snap Trap",
        "interaction" : "interacts with",
        "SUID" : 3227,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3223",
        "source" : "2747",
        "target" : "3221",
        "shared_name" : "gen8 (interacts with) Skitter Smack",
        "name" : "gen8 (interacts with) Skitter Smack",
        "interaction" : "interacts with",
        "SUID" : 3223,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3219",
        "source" : "2747",
        "target" : "3217",
        "shared_name" : "gen8 (interacts with) Shelter",
        "name" : "gen8 (interacts with) Shelter",
        "interaction" : "interacts with",
        "SUID" : 3219,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3215",
        "source" : "2747",
        "target" : "3213",
        "shared_name" : "gen8 (interacts with) Shell Side Arm",
        "name" : "gen8 (interacts with) Shell Side Arm",
        "interaction" : "interacts with",
        "SUID" : 3215,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3211",
        "source" : "2747",
        "target" : "3209",
        "shared_name" : "gen8 (interacts with) Scorching Sands",
        "name" : "gen8 (interacts with) Scorching Sands",
        "interaction" : "interacts with",
        "SUID" : 3211,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3207",
        "source" : "2747",
        "target" : "3205",
        "shared_name" : "gen8 (interacts with) Scale Shot",
        "name" : "gen8 (interacts with) Scale Shot",
        "interaction" : "interacts with",
        "SUID" : 3207,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3203",
        "source" : "2747",
        "target" : "3201",
        "shared_name" : "gen8 (interacts with) Sandsear Storm",
        "name" : "gen8 (interacts with) Sandsear Storm",
        "interaction" : "interacts with",
        "SUID" : 3203,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3199",
        "source" : "2747",
        "target" : "3197",
        "shared_name" : "gen8 (interacts with) Rising Voltage",
        "name" : "gen8 (interacts with) Rising Voltage",
        "interaction" : "interacts with",
        "SUID" : 3199,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3195",
        "source" : "2747",
        "target" : "3193",
        "shared_name" : "gen8 (interacts with) Raging Fury",
        "name" : "gen8 (interacts with) Raging Fury",
        "interaction" : "interacts with",
        "SUID" : 3195,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3191",
        "source" : "2747",
        "target" : "3189",
        "shared_name" : "gen8 (interacts with) Pyro Ball",
        "name" : "gen8 (interacts with) Pyro Ball",
        "interaction" : "interacts with",
        "SUID" : 3191,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3187",
        "source" : "2747",
        "target" : "3185",
        "shared_name" : "gen8 (interacts with) Psyshield Bash",
        "name" : "gen8 (interacts with) Psyshield Bash",
        "interaction" : "interacts with",
        "SUID" : 3187,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3183",
        "source" : "2747",
        "target" : "3181",
        "shared_name" : "gen8 (interacts with) Power Shift",
        "name" : "gen8 (interacts with) Power Shift",
        "interaction" : "interacts with",
        "SUID" : 3183,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3179",
        "source" : "2747",
        "target" : "3177",
        "shared_name" : "gen8 (interacts with) Poltergeist",
        "name" : "gen8 (interacts with) Poltergeist",
        "interaction" : "interacts with",
        "SUID" : 3179,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3175",
        "source" : "2747",
        "target" : "3173",
        "shared_name" : "gen8 (interacts with) Overdrive",
        "name" : "gen8 (interacts with) Overdrive",
        "interaction" : "interacts with",
        "SUID" : 3175,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3171",
        "source" : "2747",
        "target" : "3169",
        "shared_name" : "gen8 (interacts with) Octolock",
        "name" : "gen8 (interacts with) Octolock",
        "interaction" : "interacts with",
        "SUID" : 3171,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3167",
        "source" : "2747",
        "target" : "3165",
        "shared_name" : "gen8 (interacts with) Obstruct",
        "name" : "gen8 (interacts with) Obstruct",
        "interaction" : "interacts with",
        "SUID" : 3167,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3163",
        "source" : "2747",
        "target" : "3161",
        "shared_name" : "gen8 (interacts with) No Retreat",
        "name" : "gen8 (interacts with) No Retreat",
        "interaction" : "interacts with",
        "SUID" : 3163,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3159",
        "source" : "2747",
        "target" : "3157",
        "shared_name" : "gen8 (interacts with) Mystical Power",
        "name" : "gen8 (interacts with) Mystical Power",
        "interaction" : "interacts with",
        "SUID" : 3159,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3155",
        "source" : "2747",
        "target" : "3153",
        "shared_name" : "gen8 (interacts with) Mountain Gale",
        "name" : "gen8 (interacts with) Mountain Gale",
        "interaction" : "interacts with",
        "SUID" : 3155,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3151",
        "source" : "2747",
        "target" : "3149",
        "shared_name" : "gen8 (interacts with) Misty Explosion",
        "name" : "gen8 (interacts with) Misty Explosion",
        "interaction" : "interacts with",
        "SUID" : 3151,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3147",
        "source" : "2747",
        "target" : "3145",
        "shared_name" : "gen8 (interacts with) Meteor Beam",
        "name" : "gen8 (interacts with) Meteor Beam",
        "interaction" : "interacts with",
        "SUID" : 3147,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3143",
        "source" : "2747",
        "target" : "3141",
        "shared_name" : "gen8 (interacts with) Meteor Assault",
        "name" : "gen8 (interacts with) Meteor Assault",
        "interaction" : "interacts with",
        "SUID" : 3143,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3139",
        "source" : "2747",
        "target" : "3137",
        "shared_name" : "gen8 (interacts with) Max Wyrmwind",
        "name" : "gen8 (interacts with) Max Wyrmwind",
        "interaction" : "interacts with",
        "SUID" : 3139,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3135",
        "source" : "2747",
        "target" : "3133",
        "shared_name" : "gen8 (interacts with) Max Strike",
        "name" : "gen8 (interacts with) Max Strike",
        "interaction" : "interacts with",
        "SUID" : 3135,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3131",
        "source" : "2747",
        "target" : "3129",
        "shared_name" : "gen8 (interacts with) Max Steelspike",
        "name" : "gen8 (interacts with) Max Steelspike",
        "interaction" : "interacts with",
        "SUID" : 3131,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3127",
        "source" : "2747",
        "target" : "3125",
        "shared_name" : "gen8 (interacts with) Max Starfall",
        "name" : "gen8 (interacts with) Max Starfall",
        "interaction" : "interacts with",
        "SUID" : 3127,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3123",
        "source" : "2747",
        "target" : "3121",
        "shared_name" : "gen8 (interacts with) Max Rockfall",
        "name" : "gen8 (interacts with) Max Rockfall",
        "interaction" : "interacts with",
        "SUID" : 3123,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3119",
        "source" : "2747",
        "target" : "3117",
        "shared_name" : "gen8 (interacts with) Max Quake",
        "name" : "gen8 (interacts with) Max Quake",
        "interaction" : "interacts with",
        "SUID" : 3119,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3115",
        "source" : "2747",
        "target" : "3113",
        "shared_name" : "gen8 (interacts with) Max Phantasm",
        "name" : "gen8 (interacts with) Max Phantasm",
        "interaction" : "interacts with",
        "SUID" : 3115,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3111",
        "source" : "2747",
        "target" : "3109",
        "shared_name" : "gen8 (interacts with) Max Overgrowth",
        "name" : "gen8 (interacts with) Max Overgrowth",
        "interaction" : "interacts with",
        "SUID" : 3111,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3107",
        "source" : "2747",
        "target" : "3105",
        "shared_name" : "gen8 (interacts with) Max Ooze",
        "name" : "gen8 (interacts with) Max Ooze",
        "interaction" : "interacts with",
        "SUID" : 3107,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3103",
        "source" : "2747",
        "target" : "3101",
        "shared_name" : "gen8 (interacts with) Max Mindstorm",
        "name" : "gen8 (interacts with) Max Mindstorm",
        "interaction" : "interacts with",
        "SUID" : 3103,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3099",
        "source" : "2747",
        "target" : "3097",
        "shared_name" : "gen8 (interacts with) Max Lightning",
        "name" : "gen8 (interacts with) Max Lightning",
        "interaction" : "interacts with",
        "SUID" : 3099,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3095",
        "source" : "2747",
        "target" : "3093",
        "shared_name" : "gen8 (interacts with) Max Knuckle",
        "name" : "gen8 (interacts with) Max Knuckle",
        "interaction" : "interacts with",
        "SUID" : 3095,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3091",
        "source" : "2747",
        "target" : "3089",
        "shared_name" : "gen8 (interacts with) Max Hailstorm",
        "name" : "gen8 (interacts with) Max Hailstorm",
        "interaction" : "interacts with",
        "SUID" : 3091,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3087",
        "source" : "2747",
        "target" : "3085",
        "shared_name" : "gen8 (interacts with) Max Guard",
        "name" : "gen8 (interacts with) Max Guard",
        "interaction" : "interacts with",
        "SUID" : 3087,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3083",
        "source" : "2747",
        "target" : "3081",
        "shared_name" : "gen8 (interacts with) Max Geyser",
        "name" : "gen8 (interacts with) Max Geyser",
        "interaction" : "interacts with",
        "SUID" : 3083,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3079",
        "source" : "2747",
        "target" : "3077",
        "shared_name" : "gen8 (interacts with) Max Flutterby",
        "name" : "gen8 (interacts with) Max Flutterby",
        "interaction" : "interacts with",
        "SUID" : 3079,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3075",
        "source" : "2747",
        "target" : "3073",
        "shared_name" : "gen8 (interacts with) Max Flare",
        "name" : "gen8 (interacts with) Max Flare",
        "interaction" : "interacts with",
        "SUID" : 3075,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3071",
        "source" : "2747",
        "target" : "3069",
        "shared_name" : "gen8 (interacts with) Max Darkness",
        "name" : "gen8 (interacts with) Max Darkness",
        "interaction" : "interacts with",
        "SUID" : 3071,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3067",
        "source" : "2747",
        "target" : "3065",
        "shared_name" : "gen8 (interacts with) Max Airstream",
        "name" : "gen8 (interacts with) Max Airstream",
        "interaction" : "interacts with",
        "SUID" : 3067,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3063",
        "source" : "2747",
        "target" : "3061",
        "shared_name" : "gen8 (interacts with) Magic Powder",
        "name" : "gen8 (interacts with) Magic Powder",
        "interaction" : "interacts with",
        "SUID" : 3063,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3059",
        "source" : "2747",
        "target" : "3057",
        "shared_name" : "gen8 (interacts with) Lunar Blessing",
        "name" : "gen8 (interacts with) Lunar Blessing",
        "interaction" : "interacts with",
        "SUID" : 3059,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3055",
        "source" : "2747",
        "target" : "3053",
        "shared_name" : "gen8 (interacts with) Life Dew",
        "name" : "gen8 (interacts with) Life Dew",
        "interaction" : "interacts with",
        "SUID" : 3055,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3051",
        "source" : "2747",
        "target" : "3049",
        "shared_name" : "gen8 (interacts with) Lash Out",
        "name" : "gen8 (interacts with) Lash Out",
        "interaction" : "interacts with",
        "SUID" : 3051,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3047",
        "source" : "2747",
        "target" : "3045",
        "shared_name" : "gen8 (interacts with) Jungle Healing",
        "name" : "gen8 (interacts with) Jungle Healing",
        "interaction" : "interacts with",
        "SUID" : 3047,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3043",
        "source" : "2747",
        "target" : "3041",
        "shared_name" : "gen8 (interacts with) Jaw Lock",
        "name" : "gen8 (interacts with) Jaw Lock",
        "interaction" : "interacts with",
        "SUID" : 3043,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3039",
        "source" : "2747",
        "target" : "3037",
        "shared_name" : "gen8 (interacts with) Infernal Parade",
        "name" : "gen8 (interacts with) Infernal Parade",
        "interaction" : "interacts with",
        "SUID" : 3039,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3035",
        "source" : "2747",
        "target" : "3033",
        "shared_name" : "gen8 (interacts with) Headlong Rush",
        "name" : "gen8 (interacts with) Headlong Rush",
        "interaction" : "interacts with",
        "SUID" : 3035,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3031",
        "source" : "2747",
        "target" : "3029",
        "shared_name" : "gen8 (interacts with) Grav Apple",
        "name" : "gen8 (interacts with) Grav Apple",
        "interaction" : "interacts with",
        "SUID" : 3031,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3027",
        "source" : "2747",
        "target" : "3025",
        "shared_name" : "gen8 (interacts with) Grassy Glide",
        "name" : "gen8 (interacts with) Grassy Glide",
        "interaction" : "interacts with",
        "SUID" : 3027,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3023",
        "source" : "2747",
        "target" : "3021",
        "shared_name" : "gen8 (interacts with) Glacial Lance",
        "name" : "gen8 (interacts with) Glacial Lance",
        "interaction" : "interacts with",
        "SUID" : 3023,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3019",
        "source" : "2747",
        "target" : "3017",
        "shared_name" : "gen8 (interacts with) G-Max Wind Rage",
        "name" : "gen8 (interacts with) G-Max Wind Rage",
        "interaction" : "interacts with",
        "SUID" : 3019,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3015",
        "source" : "2747",
        "target" : "3013",
        "shared_name" : "gen8 (interacts with) G-Max Wildfire",
        "name" : "gen8 (interacts with) G-Max Wildfire",
        "interaction" : "interacts with",
        "SUID" : 3015,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3011",
        "source" : "2747",
        "target" : "3009",
        "shared_name" : "gen8 (interacts with) G-Max Volt Crash",
        "name" : "gen8 (interacts with) G-Max Volt Crash",
        "interaction" : "interacts with",
        "SUID" : 3011,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3007",
        "source" : "2747",
        "target" : "3005",
        "shared_name" : "gen8 (interacts with) G-Max Volcalith",
        "name" : "gen8 (interacts with) G-Max Volcalith",
        "interaction" : "interacts with",
        "SUID" : 3007,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3003",
        "source" : "2747",
        "target" : "3001",
        "shared_name" : "gen8 (interacts with) G-Max Vine Lash",
        "name" : "gen8 (interacts with) G-Max Vine Lash",
        "interaction" : "interacts with",
        "SUID" : 3003,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2999",
        "source" : "2747",
        "target" : "2997",
        "shared_name" : "gen8 (interacts with) G-Max Terror",
        "name" : "gen8 (interacts with) G-Max Terror",
        "interaction" : "interacts with",
        "SUID" : 2999,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2995",
        "source" : "2747",
        "target" : "2993",
        "shared_name" : "gen8 (interacts with) G-Max Tartness",
        "name" : "gen8 (interacts with) G-Max Tartness",
        "interaction" : "interacts with",
        "SUID" : 2995,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2991",
        "source" : "2747",
        "target" : "2989",
        "shared_name" : "gen8 (interacts with) G-Max Sweetness",
        "name" : "gen8 (interacts with) G-Max Sweetness",
        "interaction" : "interacts with",
        "SUID" : 2991,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2987",
        "source" : "2747",
        "target" : "2985",
        "shared_name" : "gen8 (interacts with) G-Max Stun Shock",
        "name" : "gen8 (interacts with) G-Max Stun Shock",
        "interaction" : "interacts with",
        "SUID" : 2987,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2983",
        "source" : "2747",
        "target" : "2981",
        "shared_name" : "gen8 (interacts with) G-Max Stonesurge",
        "name" : "gen8 (interacts with) G-Max Stonesurge",
        "interaction" : "interacts with",
        "SUID" : 2983,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2979",
        "source" : "2747",
        "target" : "2977",
        "shared_name" : "gen8 (interacts with) G-Max Steelsurge",
        "name" : "gen8 (interacts with) G-Max Steelsurge",
        "interaction" : "interacts with",
        "SUID" : 2979,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2975",
        "source" : "2747",
        "target" : "2973",
        "shared_name" : "gen8 (interacts with) G-Max Snooze",
        "name" : "gen8 (interacts with) G-Max Snooze",
        "interaction" : "interacts with",
        "SUID" : 2975,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2971",
        "source" : "2747",
        "target" : "2969",
        "shared_name" : "gen8 (interacts with) G-Max Smite",
        "name" : "gen8 (interacts with) G-Max Smite",
        "interaction" : "interacts with",
        "SUID" : 2971,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2967",
        "source" : "2747",
        "target" : "2965",
        "shared_name" : "gen8 (interacts with) G-Max Sandblast",
        "name" : "gen8 (interacts with) G-Max Sandblast",
        "interaction" : "interacts with",
        "SUID" : 2967,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2963",
        "source" : "2747",
        "target" : "2961",
        "shared_name" : "gen8 (interacts with) G-Max Resonance",
        "name" : "gen8 (interacts with) G-Max Resonance",
        "interaction" : "interacts with",
        "SUID" : 2963,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2959",
        "source" : "2747",
        "target" : "2957",
        "shared_name" : "gen8 (interacts with) G-Max Replenish",
        "name" : "gen8 (interacts with) G-Max Replenish",
        "interaction" : "interacts with",
        "SUID" : 2959,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2955",
        "source" : "2747",
        "target" : "2953",
        "shared_name" : "gen8 (interacts with) G-Max Rapid Flow",
        "name" : "gen8 (interacts with) G-Max Rapid Flow",
        "interaction" : "interacts with",
        "SUID" : 2955,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2951",
        "source" : "2747",
        "target" : "2949",
        "shared_name" : "gen8 (interacts with) G-Max One Blow",
        "name" : "gen8 (interacts with) G-Max One Blow",
        "interaction" : "interacts with",
        "SUID" : 2951,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2947",
        "source" : "2747",
        "target" : "2945",
        "shared_name" : "gen8 (interacts with) G-Max Meltdown",
        "name" : "gen8 (interacts with) G-Max Meltdown",
        "interaction" : "interacts with",
        "SUID" : 2947,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2943",
        "source" : "2747",
        "target" : "2941",
        "shared_name" : "gen8 (interacts with) G-Max Malodor",
        "name" : "gen8 (interacts with) G-Max Malodor",
        "interaction" : "interacts with",
        "SUID" : 2943,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2939",
        "source" : "2747",
        "target" : "2937",
        "shared_name" : "gen8 (interacts with) G-Max Hydrosnipe",
        "name" : "gen8 (interacts with) G-Max Hydrosnipe",
        "interaction" : "interacts with",
        "SUID" : 2939,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2935",
        "source" : "2747",
        "target" : "2933",
        "shared_name" : "gen8 (interacts with) G-Max Gravitas",
        "name" : "gen8 (interacts with) G-Max Gravitas",
        "interaction" : "interacts with",
        "SUID" : 2935,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2931",
        "source" : "2747",
        "target" : "2929",
        "shared_name" : "gen8 (interacts with) G-Max Gold Rush",
        "name" : "gen8 (interacts with) G-Max Gold Rush",
        "interaction" : "interacts with",
        "SUID" : 2931,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2927",
        "source" : "2747",
        "target" : "2925",
        "shared_name" : "gen8 (interacts with) G-Max Foam Burst",
        "name" : "gen8 (interacts with) G-Max Foam Burst",
        "interaction" : "interacts with",
        "SUID" : 2927,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2923",
        "source" : "2747",
        "target" : "2921",
        "shared_name" : "gen8 (interacts with) G-Max Fireball",
        "name" : "gen8 (interacts with) G-Max Fireball",
        "interaction" : "interacts with",
        "SUID" : 2923,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2919",
        "source" : "2747",
        "target" : "2917",
        "shared_name" : "gen8 (interacts with) G-Max Finale",
        "name" : "gen8 (interacts with) G-Max Finale",
        "interaction" : "interacts with",
        "SUID" : 2919,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2915",
        "source" : "2747",
        "target" : "2913",
        "shared_name" : "gen8 (interacts with) G-Max Drum Solo",
        "name" : "gen8 (interacts with) G-Max Drum Solo",
        "interaction" : "interacts with",
        "SUID" : 2915,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2911",
        "source" : "2747",
        "target" : "2909",
        "shared_name" : "gen8 (interacts with) G-Max Depletion",
        "name" : "gen8 (interacts with) G-Max Depletion",
        "interaction" : "interacts with",
        "SUID" : 2911,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2907",
        "source" : "2747",
        "target" : "2905",
        "shared_name" : "gen8 (interacts with) G-Max Cuddle",
        "name" : "gen8 (interacts with) G-Max Cuddle",
        "interaction" : "interacts with",
        "SUID" : 2907,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2903",
        "source" : "2747",
        "target" : "2901",
        "shared_name" : "gen8 (interacts with) G-Max Chi Strike",
        "name" : "gen8 (interacts with) G-Max Chi Strike",
        "interaction" : "interacts with",
        "SUID" : 2903,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2899",
        "source" : "2747",
        "target" : "2897",
        "shared_name" : "gen8 (interacts with) G-Max Centiferno",
        "name" : "gen8 (interacts with) G-Max Centiferno",
        "interaction" : "interacts with",
        "SUID" : 2899,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2895",
        "source" : "2747",
        "target" : "2893",
        "shared_name" : "gen8 (interacts with) G-Max Cannonade",
        "name" : "gen8 (interacts with) G-Max Cannonade",
        "interaction" : "interacts with",
        "SUID" : 2895,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2891",
        "source" : "2747",
        "target" : "2889",
        "shared_name" : "gen8 (interacts with) G-Max Befuddle",
        "name" : "gen8 (interacts with) G-Max Befuddle",
        "interaction" : "interacts with",
        "SUID" : 2891,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2887",
        "source" : "2747",
        "target" : "2885",
        "shared_name" : "gen8 (interacts with) Freezing Glare",
        "name" : "gen8 (interacts with) Freezing Glare",
        "interaction" : "interacts with",
        "SUID" : 2887,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2883",
        "source" : "2747",
        "target" : "2881",
        "shared_name" : "gen8 (interacts with) Flip Turn",
        "name" : "gen8 (interacts with) Flip Turn",
        "interaction" : "interacts with",
        "SUID" : 2883,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2879",
        "source" : "2747",
        "target" : "2877",
        "shared_name" : "gen8 (interacts with) Fishious Rend",
        "name" : "gen8 (interacts with) Fishious Rend",
        "interaction" : "interacts with",
        "SUID" : 2879,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2875",
        "source" : "2747",
        "target" : "2873",
        "shared_name" : "gen8 (interacts with) Fiery Wrath",
        "name" : "gen8 (interacts with) Fiery Wrath",
        "interaction" : "interacts with",
        "SUID" : 2875,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2871",
        "source" : "2747",
        "target" : "2869",
        "shared_name" : "gen8 (interacts with) False Surrender",
        "name" : "gen8 (interacts with) False Surrender",
        "interaction" : "interacts with",
        "SUID" : 2871,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2867",
        "source" : "2747",
        "target" : "2865",
        "shared_name" : "gen8 (interacts with) Expanding Force",
        "name" : "gen8 (interacts with) Expanding Force",
        "interaction" : "interacts with",
        "SUID" : 2867,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2863",
        "source" : "2747",
        "target" : "2861",
        "shared_name" : "gen8 (interacts with) Eternabeam",
        "name" : "gen8 (interacts with) Eternabeam",
        "interaction" : "interacts with",
        "SUID" : 2863,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2859",
        "source" : "2747",
        "target" : "2857",
        "shared_name" : "gen8 (interacts with) Esper Wing",
        "name" : "gen8 (interacts with) Esper Wing",
        "interaction" : "interacts with",
        "SUID" : 2859,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2855",
        "source" : "2747",
        "target" : "2853",
        "shared_name" : "gen8 (interacts with) Eerie Spell",
        "name" : "gen8 (interacts with) Eerie Spell",
        "interaction" : "interacts with",
        "SUID" : 2855,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2851",
        "source" : "2747",
        "target" : "2849",
        "shared_name" : "gen8 (interacts with) Dynamax Cannon",
        "name" : "gen8 (interacts with) Dynamax Cannon",
        "interaction" : "interacts with",
        "SUID" : 2851,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2847",
        "source" : "2747",
        "target" : "2845",
        "shared_name" : "gen8 (interacts with) Dual Wingbeat",
        "name" : "gen8 (interacts with) Dual Wingbeat",
        "interaction" : "interacts with",
        "SUID" : 2847,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2843",
        "source" : "2747",
        "target" : "2841",
        "shared_name" : "gen8 (interacts with) Drum Beating",
        "name" : "gen8 (interacts with) Drum Beating",
        "interaction" : "interacts with",
        "SUID" : 2843,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2839",
        "source" : "2747",
        "target" : "2837",
        "shared_name" : "gen8 (interacts with) Dragon Energy",
        "name" : "gen8 (interacts with) Dragon Energy",
        "interaction" : "interacts with",
        "SUID" : 2839,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2835",
        "source" : "2747",
        "target" : "2833",
        "shared_name" : "gen8 (interacts with) Dragon Darts",
        "name" : "gen8 (interacts with) Dragon Darts",
        "interaction" : "interacts with",
        "SUID" : 2835,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2831",
        "source" : "2747",
        "target" : "2829",
        "shared_name" : "gen8 (interacts with) Dire Claw",
        "name" : "gen8 (interacts with) Dire Claw",
        "interaction" : "interacts with",
        "SUID" : 2831,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2827",
        "source" : "2747",
        "target" : "2825",
        "shared_name" : "gen8 (interacts with) Decorate",
        "name" : "gen8 (interacts with) Decorate",
        "interaction" : "interacts with",
        "SUID" : 2827,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2823",
        "source" : "2747",
        "target" : "2821",
        "shared_name" : "gen8 (interacts with) Court Change",
        "name" : "gen8 (interacts with) Court Change",
        "interaction" : "interacts with",
        "SUID" : 2823,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2819",
        "source" : "2747",
        "target" : "2817",
        "shared_name" : "gen8 (interacts with) Corrosive Gas",
        "name" : "gen8 (interacts with) Corrosive Gas",
        "interaction" : "interacts with",
        "SUID" : 2819,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2815",
        "source" : "2747",
        "target" : "2813",
        "shared_name" : "gen8 (interacts with) Coaching",
        "name" : "gen8 (interacts with) Coaching",
        "interaction" : "interacts with",
        "SUID" : 2815,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2811",
        "source" : "2747",
        "target" : "2809",
        "shared_name" : "gen8 (interacts with) Clangorous Soul",
        "name" : "gen8 (interacts with) Clangorous Soul",
        "interaction" : "interacts with",
        "SUID" : 2811,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2807",
        "source" : "2747",
        "target" : "2805",
        "shared_name" : "gen8 (interacts with) Chloroblast",
        "name" : "gen8 (interacts with) Chloroblast",
        "interaction" : "interacts with",
        "SUID" : 2807,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2803",
        "source" : "2747",
        "target" : "2801",
        "shared_name" : "gen8 (interacts with) Ceaseless Edge",
        "name" : "gen8 (interacts with) Ceaseless Edge",
        "interaction" : "interacts with",
        "SUID" : 2803,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2799",
        "source" : "2747",
        "target" : "2797",
        "shared_name" : "gen8 (interacts with) Burning Jealousy",
        "name" : "gen8 (interacts with) Burning Jealousy",
        "interaction" : "interacts with",
        "SUID" : 2799,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2795",
        "source" : "2747",
        "target" : "2793",
        "shared_name" : "gen8 (interacts with) Breaking Swipe",
        "name" : "gen8 (interacts with) Breaking Swipe",
        "interaction" : "interacts with",
        "SUID" : 2795,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2791",
        "source" : "2747",
        "target" : "2789",
        "shared_name" : "gen8 (interacts with) Branch Poke",
        "name" : "gen8 (interacts with) Branch Poke",
        "interaction" : "interacts with",
        "SUID" : 2791,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2787",
        "source" : "2747",
        "target" : "2785",
        "shared_name" : "gen8 (interacts with) Bolt Beak",
        "name" : "gen8 (interacts with) Bolt Beak",
        "interaction" : "interacts with",
        "SUID" : 2787,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2783",
        "source" : "2747",
        "target" : "2781",
        "shared_name" : "gen8 (interacts with) Body Press",
        "name" : "gen8 (interacts with) Body Press",
        "interaction" : "interacts with",
        "SUID" : 2783,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2779",
        "source" : "2747",
        "target" : "2777",
        "shared_name" : "gen8 (interacts with) Bleakwind Storm",
        "name" : "gen8 (interacts with) Bleakwind Storm",
        "interaction" : "interacts with",
        "SUID" : 2779,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2775",
        "source" : "2747",
        "target" : "2773",
        "shared_name" : "gen8 (interacts with) Bitter Malice",
        "name" : "gen8 (interacts with) Bitter Malice",
        "interaction" : "interacts with",
        "SUID" : 2775,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2771",
        "source" : "2747",
        "target" : "2769",
        "shared_name" : "gen8 (interacts with) Behemoth Blade",
        "name" : "gen8 (interacts with) Behemoth Blade",
        "interaction" : "interacts with",
        "SUID" : 2771,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2767",
        "source" : "2747",
        "target" : "2765",
        "shared_name" : "gen8 (interacts with) Behemoth Bash",
        "name" : "gen8 (interacts with) Behemoth Bash",
        "interaction" : "interacts with",
        "SUID" : 2767,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2763",
        "source" : "2747",
        "target" : "2761",
        "shared_name" : "gen8 (interacts with) Barb Barrage",
        "name" : "gen8 (interacts with) Barb Barrage",
        "interaction" : "interacts with",
        "SUID" : 2763,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2759",
        "source" : "2747",
        "target" : "2757",
        "shared_name" : "gen8 (interacts with) Aura Wheel",
        "name" : "gen8 (interacts with) Aura Wheel",
        "interaction" : "interacts with",
        "SUID" : 2759,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2755",
        "source" : "2747",
        "target" : "2753",
        "shared_name" : "gen8 (interacts with) Astral Barrage",
        "name" : "gen8 (interacts with) Astral Barrage",
        "interaction" : "interacts with",
        "SUID" : 2755,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2751",
        "source" : "2747",
        "target" : "2749",
        "shared_name" : "gen8 (interacts with) Apple Acid",
        "name" : "gen8 (interacts with) Apple Acid",
        "interaction" : "interacts with",
        "SUID" : 2751,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2745",
        "source" : "2293",
        "target" : "2743",
        "shared_name" : "gen4 (interacts with) Zen Headbutt",
        "name" : "gen4 (interacts with) Zen Headbutt",
        "interaction" : "interacts with",
        "SUID" : 2745,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2741",
        "source" : "2293",
        "target" : "2739",
        "shared_name" : "gen4 (interacts with) X-Scissor",
        "name" : "gen4 (interacts with) X-Scissor",
        "interaction" : "interacts with",
        "SUID" : 2741,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2737",
        "source" : "2293",
        "target" : "2735",
        "shared_name" : "gen4 (interacts with) Wring Out",
        "name" : "gen4 (interacts with) Wring Out",
        "interaction" : "interacts with",
        "SUID" : 2737,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2733",
        "source" : "2293",
        "target" : "2731",
        "shared_name" : "gen4 (interacts with) Worry Seed",
        "name" : "gen4 (interacts with) Worry Seed",
        "interaction" : "interacts with",
        "SUID" : 2733,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2729",
        "source" : "2293",
        "target" : "2727",
        "shared_name" : "gen4 (interacts with) Wood Hammer",
        "name" : "gen4 (interacts with) Wood Hammer",
        "interaction" : "interacts with",
        "SUID" : 2729,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2725",
        "source" : "2293",
        "target" : "2723",
        "shared_name" : "gen4 (interacts with) Wake-Up Slap",
        "name" : "gen4 (interacts with) Wake-Up Slap",
        "interaction" : "interacts with",
        "SUID" : 2725,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2721",
        "source" : "2293",
        "target" : "2719",
        "shared_name" : "gen4 (interacts with) Vacuum Wave",
        "name" : "gen4 (interacts with) Vacuum Wave",
        "interaction" : "interacts with",
        "SUID" : 2721,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2717",
        "source" : "2293",
        "target" : "2715",
        "shared_name" : "gen4 (interacts with) U-turn",
        "name" : "gen4 (interacts with) U-turn",
        "interaction" : "interacts with",
        "SUID" : 2717,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2713",
        "source" : "2293",
        "target" : "2711",
        "shared_name" : "gen4 (interacts with) Trump Card",
        "name" : "gen4 (interacts with) Trump Card",
        "interaction" : "interacts with",
        "SUID" : 2713,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2709",
        "source" : "2293",
        "target" : "2707",
        "shared_name" : "gen4 (interacts with) Trick Room",
        "name" : "gen4 (interacts with) Trick Room",
        "interaction" : "interacts with",
        "SUID" : 2709,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2705",
        "source" : "2293",
        "target" : "2703",
        "shared_name" : "gen4 (interacts with) Toxic Spikes",
        "name" : "gen4 (interacts with) Toxic Spikes",
        "interaction" : "interacts with",
        "SUID" : 2705,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2701",
        "source" : "2293",
        "target" : "2699",
        "shared_name" : "gen4 (interacts with) Thunder Fang",
        "name" : "gen4 (interacts with) Thunder Fang",
        "interaction" : "interacts with",
        "SUID" : 2701,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2697",
        "source" : "2293",
        "target" : "2695",
        "shared_name" : "gen4 (interacts with) Tailwind",
        "name" : "gen4 (interacts with) Tailwind",
        "interaction" : "interacts with",
        "SUID" : 2697,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2693",
        "source" : "2293",
        "target" : "2691",
        "shared_name" : "gen4 (interacts with) Switcheroo",
        "name" : "gen4 (interacts with) Switcheroo",
        "interaction" : "interacts with",
        "SUID" : 2693,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2689",
        "source" : "2293",
        "target" : "2687",
        "shared_name" : "gen4 (interacts with) Sucker Punch",
        "name" : "gen4 (interacts with) Sucker Punch",
        "interaction" : "interacts with",
        "SUID" : 2689,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2685",
        "source" : "2293",
        "target" : "2683",
        "shared_name" : "gen4 (interacts with) Stone Edge",
        "name" : "gen4 (interacts with) Stone Edge",
        "interaction" : "interacts with",
        "SUID" : 2685,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2681",
        "source" : "2293",
        "target" : "2679",
        "shared_name" : "gen4 (interacts with) Stealth Rock",
        "name" : "gen4 (interacts with) Stealth Rock",
        "interaction" : "interacts with",
        "SUID" : 2681,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2677",
        "source" : "2293",
        "target" : "2675",
        "shared_name" : "gen4 (interacts with) Spacial Rend",
        "name" : "gen4 (interacts with) Spacial Rend",
        "interaction" : "interacts with",
        "SUID" : 2677,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2673",
        "source" : "2293",
        "target" : "2671",
        "shared_name" : "gen4 (interacts with) Shadow Sneak",
        "name" : "gen4 (interacts with) Shadow Sneak",
        "interaction" : "interacts with",
        "SUID" : 2673,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2669",
        "source" : "2293",
        "target" : "2667",
        "shared_name" : "gen4 (interacts with) Shadow Force",
        "name" : "gen4 (interacts with) Shadow Force",
        "interaction" : "interacts with",
        "SUID" : 2669,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2665",
        "source" : "2293",
        "target" : "2663",
        "shared_name" : "gen4 (interacts with) Shadow Claw",
        "name" : "gen4 (interacts with) Shadow Claw",
        "interaction" : "interacts with",
        "SUID" : 2665,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2661",
        "source" : "2293",
        "target" : "2659",
        "shared_name" : "gen4 (interacts with) Seed Flare",
        "name" : "gen4 (interacts with) Seed Flare",
        "interaction" : "interacts with",
        "SUID" : 2661,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2657",
        "source" : "2293",
        "target" : "2655",
        "shared_name" : "gen4 (interacts with) Seed Bomb",
        "name" : "gen4 (interacts with) Seed Bomb",
        "interaction" : "interacts with",
        "SUID" : 2657,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2653",
        "source" : "2293",
        "target" : "2651",
        "shared_name" : "gen4 (interacts with) Roost",
        "name" : "gen4 (interacts with) Roost",
        "interaction" : "interacts with",
        "SUID" : 2653,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2649",
        "source" : "2293",
        "target" : "2647",
        "shared_name" : "gen4 (interacts with) Rock Wrecker",
        "name" : "gen4 (interacts with) Rock Wrecker",
        "interaction" : "interacts with",
        "SUID" : 2649,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2645",
        "source" : "2293",
        "target" : "2643",
        "shared_name" : "gen4 (interacts with) Rock Polish",
        "name" : "gen4 (interacts with) Rock Polish",
        "interaction" : "interacts with",
        "SUID" : 2645,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2641",
        "source" : "2293",
        "target" : "2639",
        "shared_name" : "gen4 (interacts with) Rock Climb",
        "name" : "gen4 (interacts with) Rock Climb",
        "interaction" : "interacts with",
        "SUID" : 2641,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2637",
        "source" : "2293",
        "target" : "2635",
        "shared_name" : "gen4 (interacts with) Roar of Time",
        "name" : "gen4 (interacts with) Roar of Time",
        "interaction" : "interacts with",
        "SUID" : 2637,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2633",
        "source" : "2293",
        "target" : "2631",
        "shared_name" : "gen4 (interacts with) Punishment",
        "name" : "gen4 (interacts with) Punishment",
        "interaction" : "interacts with",
        "SUID" : 2633,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2629",
        "source" : "2293",
        "target" : "2627",
        "shared_name" : "gen4 (interacts with) Psycho Shift",
        "name" : "gen4 (interacts with) Psycho Shift",
        "interaction" : "interacts with",
        "SUID" : 2629,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2625",
        "source" : "2293",
        "target" : "2623",
        "shared_name" : "gen4 (interacts with) Psycho Cut",
        "name" : "gen4 (interacts with) Psycho Cut",
        "interaction" : "interacts with",
        "SUID" : 2625,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2621",
        "source" : "2293",
        "target" : "2619",
        "shared_name" : "gen4 (interacts with) Power Whip",
        "name" : "gen4 (interacts with) Power Whip",
        "interaction" : "interacts with",
        "SUID" : 2621,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2617",
        "source" : "2293",
        "target" : "2615",
        "shared_name" : "gen4 (interacts with) Power Trick",
        "name" : "gen4 (interacts with) Power Trick",
        "interaction" : "interacts with",
        "SUID" : 2617,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2613",
        "source" : "2293",
        "target" : "2611",
        "shared_name" : "gen4 (interacts with) Power Swap",
        "name" : "gen4 (interacts with) Power Swap",
        "interaction" : "interacts with",
        "SUID" : 2613,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2609",
        "source" : "2293",
        "target" : "2607",
        "shared_name" : "gen4 (interacts with) Power Gem",
        "name" : "gen4 (interacts with) Power Gem",
        "interaction" : "interacts with",
        "SUID" : 2609,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2605",
        "source" : "2293",
        "target" : "2603",
        "shared_name" : "gen4 (interacts with) Poison Jab",
        "name" : "gen4 (interacts with) Poison Jab",
        "interaction" : "interacts with",
        "SUID" : 2605,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2601",
        "source" : "2293",
        "target" : "2599",
        "shared_name" : "gen4 (interacts with) Pluck",
        "name" : "gen4 (interacts with) Pluck",
        "interaction" : "interacts with",
        "SUID" : 2601,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2597",
        "source" : "2293",
        "target" : "2595",
        "shared_name" : "gen4 (interacts with) Payback",
        "name" : "gen4 (interacts with) Payback",
        "interaction" : "interacts with",
        "SUID" : 2597,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2593",
        "source" : "2293",
        "target" : "2591",
        "shared_name" : "gen4 (interacts with) Ominous Wind",
        "name" : "gen4 (interacts with) Ominous Wind",
        "interaction" : "interacts with",
        "SUID" : 2593,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2589",
        "source" : "2293",
        "target" : "2587",
        "shared_name" : "gen4 (interacts with) Night Slash",
        "name" : "gen4 (interacts with) Night Slash",
        "interaction" : "interacts with",
        "SUID" : 2589,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2585",
        "source" : "2293",
        "target" : "2583",
        "shared_name" : "gen4 (interacts with) Natural Gift",
        "name" : "gen4 (interacts with) Natural Gift",
        "interaction" : "interacts with",
        "SUID" : 2585,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2581",
        "source" : "2293",
        "target" : "2579",
        "shared_name" : "gen4 (interacts with) Nasty Plot",
        "name" : "gen4 (interacts with) Nasty Plot",
        "interaction" : "interacts with",
        "SUID" : 2581,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2577",
        "source" : "2293",
        "target" : "2575",
        "shared_name" : "gen4 (interacts with) Mud Bomb",
        "name" : "gen4 (interacts with) Mud Bomb",
        "interaction" : "interacts with",
        "SUID" : 2577,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2573",
        "source" : "2293",
        "target" : "2571",
        "shared_name" : "gen4 (interacts with) Mirror Shot",
        "name" : "gen4 (interacts with) Mirror Shot",
        "interaction" : "interacts with",
        "SUID" : 2573,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2569",
        "source" : "2293",
        "target" : "2567",
        "shared_name" : "gen4 (interacts with) Miracle Eye",
        "name" : "gen4 (interacts with) Miracle Eye",
        "interaction" : "interacts with",
        "SUID" : 2569,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2565",
        "source" : "2293",
        "target" : "2563",
        "shared_name" : "gen4 (interacts with) Metal Burst",
        "name" : "gen4 (interacts with) Metal Burst",
        "interaction" : "interacts with",
        "SUID" : 2565,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2561",
        "source" : "2293",
        "target" : "2559",
        "shared_name" : "gen4 (interacts with) Me First",
        "name" : "gen4 (interacts with) Me First",
        "interaction" : "interacts with",
        "SUID" : 2561,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2557",
        "source" : "2293",
        "target" : "2555",
        "shared_name" : "gen4 (interacts with) Magnet Rise",
        "name" : "gen4 (interacts with) Magnet Rise",
        "interaction" : "interacts with",
        "SUID" : 2557,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2553",
        "source" : "2293",
        "target" : "2551",
        "shared_name" : "gen4 (interacts with) Magnet Bomb",
        "name" : "gen4 (interacts with) Magnet Bomb",
        "interaction" : "interacts with",
        "SUID" : 2553,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2549",
        "source" : "2293",
        "target" : "2547",
        "shared_name" : "gen4 (interacts with) Magma Storm",
        "name" : "gen4 (interacts with) Magma Storm",
        "interaction" : "interacts with",
        "SUID" : 2549,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2545",
        "source" : "2293",
        "target" : "2543",
        "shared_name" : "gen4 (interacts with) Lunar Dance",
        "name" : "gen4 (interacts with) Lunar Dance",
        "interaction" : "interacts with",
        "SUID" : 2545,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2541",
        "source" : "2293",
        "target" : "2539",
        "shared_name" : "gen4 (interacts with) Lucky Chant",
        "name" : "gen4 (interacts with) Lucky Chant",
        "interaction" : "interacts with",
        "SUID" : 2541,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2537",
        "source" : "2293",
        "target" : "2535",
        "shared_name" : "gen4 (interacts with) Leaf Storm",
        "name" : "gen4 (interacts with) Leaf Storm",
        "interaction" : "interacts with",
        "SUID" : 2537,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2533",
        "source" : "2293",
        "target" : "2531",
        "shared_name" : "gen4 (interacts with) Lava Plume",
        "name" : "gen4 (interacts with) Lava Plume",
        "interaction" : "interacts with",
        "SUID" : 2533,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2529",
        "source" : "2293",
        "target" : "2527",
        "shared_name" : "gen4 (interacts with) Last Resort",
        "name" : "gen4 (interacts with) Last Resort",
        "interaction" : "interacts with",
        "SUID" : 2529,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2525",
        "source" : "2293",
        "target" : "2523",
        "shared_name" : "gen4 (interacts with) Judgment",
        "name" : "gen4 (interacts with) Judgment",
        "interaction" : "interacts with",
        "SUID" : 2525,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2521",
        "source" : "2293",
        "target" : "2519",
        "shared_name" : "gen4 (interacts with) Iron Head",
        "name" : "gen4 (interacts with) Iron Head",
        "interaction" : "interacts with",
        "SUID" : 2521,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2517",
        "source" : "2293",
        "target" : "2515",
        "shared_name" : "gen4 (interacts with) Ice Shard",
        "name" : "gen4 (interacts with) Ice Shard",
        "interaction" : "interacts with",
        "SUID" : 2517,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2513",
        "source" : "2293",
        "target" : "2511",
        "shared_name" : "gen4 (interacts with) Ice Fang",
        "name" : "gen4 (interacts with) Ice Fang",
        "interaction" : "interacts with",
        "SUID" : 2513,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2509",
        "source" : "2293",
        "target" : "2507",
        "shared_name" : "gen4 (interacts with) Heart Swap",
        "name" : "gen4 (interacts with) Heart Swap",
        "interaction" : "interacts with",
        "SUID" : 2509,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2505",
        "source" : "2293",
        "target" : "2503",
        "shared_name" : "gen4 (interacts with) Healing Wish",
        "name" : "gen4 (interacts with) Healing Wish",
        "interaction" : "interacts with",
        "SUID" : 2505,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2501",
        "source" : "2293",
        "target" : "2499",
        "shared_name" : "gen4 (interacts with) Heal Order",
        "name" : "gen4 (interacts with) Heal Order",
        "interaction" : "interacts with",
        "SUID" : 2501,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2497",
        "source" : "2293",
        "target" : "2495",
        "shared_name" : "gen4 (interacts with) Heal Block",
        "name" : "gen4 (interacts with) Heal Block",
        "interaction" : "interacts with",
        "SUID" : 2497,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2493",
        "source" : "2293",
        "target" : "2491",
        "shared_name" : "gen4 (interacts with) Head Smash",
        "name" : "gen4 (interacts with) Head Smash",
        "interaction" : "interacts with",
        "SUID" : 2493,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2489",
        "source" : "2293",
        "target" : "2487",
        "shared_name" : "gen4 (interacts with) Hammer Arm",
        "name" : "gen4 (interacts with) Hammer Arm",
        "interaction" : "interacts with",
        "SUID" : 2489,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2485",
        "source" : "2293",
        "target" : "2483",
        "shared_name" : "gen4 (interacts with) Gyro Ball",
        "name" : "gen4 (interacts with) Gyro Ball",
        "interaction" : "interacts with",
        "SUID" : 2485,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2481",
        "source" : "2293",
        "target" : "2479",
        "shared_name" : "gen4 (interacts with) Gunk Shot",
        "name" : "gen4 (interacts with) Gunk Shot",
        "interaction" : "interacts with",
        "SUID" : 2481,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2477",
        "source" : "2293",
        "target" : "2475",
        "shared_name" : "gen4 (interacts with) Guard Swap",
        "name" : "gen4 (interacts with) Guard Swap",
        "interaction" : "interacts with",
        "SUID" : 2477,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2473",
        "source" : "2293",
        "target" : "2471",
        "shared_name" : "gen4 (interacts with) Gravity",
        "name" : "gen4 (interacts with) Gravity",
        "interaction" : "interacts with",
        "SUID" : 2473,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2469",
        "source" : "2293",
        "target" : "2467",
        "shared_name" : "gen4 (interacts with) Grass Knot",
        "name" : "gen4 (interacts with) Grass Knot",
        "interaction" : "interacts with",
        "SUID" : 2469,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2465",
        "source" : "2293",
        "target" : "2463",
        "shared_name" : "gen4 (interacts with) Giga Impact",
        "name" : "gen4 (interacts with) Giga Impact",
        "interaction" : "interacts with",
        "SUID" : 2465,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2461",
        "source" : "2293",
        "target" : "2459",
        "shared_name" : "gen4 (interacts with) Gastro Acid",
        "name" : "gen4 (interacts with) Gastro Acid",
        "interaction" : "interacts with",
        "SUID" : 2461,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2457",
        "source" : "2293",
        "target" : "2455",
        "shared_name" : "gen4 (interacts with) Force Palm",
        "name" : "gen4 (interacts with) Force Palm",
        "interaction" : "interacts with",
        "SUID" : 2457,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2453",
        "source" : "2293",
        "target" : "2451",
        "shared_name" : "gen4 (interacts with) Focus Blast",
        "name" : "gen4 (interacts with) Focus Blast",
        "interaction" : "interacts with",
        "SUID" : 2453,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2449",
        "source" : "2293",
        "target" : "2447",
        "shared_name" : "gen4 (interacts with) Fling",
        "name" : "gen4 (interacts with) Fling",
        "interaction" : "interacts with",
        "SUID" : 2449,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2445",
        "source" : "2293",
        "target" : "2443",
        "shared_name" : "gen4 (interacts with) Flash Cannon",
        "name" : "gen4 (interacts with) Flash Cannon",
        "interaction" : "interacts with",
        "SUID" : 2445,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2441",
        "source" : "2293",
        "target" : "2439",
        "shared_name" : "gen4 (interacts with) Flare Blitz",
        "name" : "gen4 (interacts with) Flare Blitz",
        "interaction" : "interacts with",
        "SUID" : 2441,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2437",
        "source" : "2293",
        "target" : "2435",
        "shared_name" : "gen4 (interacts with) Fire Fang",
        "name" : "gen4 (interacts with) Fire Fang",
        "interaction" : "interacts with",
        "SUID" : 2437,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2433",
        "source" : "2293",
        "target" : "2431",
        "shared_name" : "gen4 (interacts with) Feint",
        "name" : "gen4 (interacts with) Feint",
        "interaction" : "interacts with",
        "SUID" : 2433,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2429",
        "source" : "2293",
        "target" : "2427",
        "shared_name" : "gen4 (interacts with) Energy Ball",
        "name" : "gen4 (interacts with) Energy Ball",
        "interaction" : "interacts with",
        "SUID" : 2429,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2425",
        "source" : "2293",
        "target" : "2423",
        "shared_name" : "gen4 (interacts with) Embargo",
        "name" : "gen4 (interacts with) Embargo",
        "interaction" : "interacts with",
        "SUID" : 2425,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2421",
        "source" : "2293",
        "target" : "2419",
        "shared_name" : "gen4 (interacts with) Earth Power",
        "name" : "gen4 (interacts with) Earth Power",
        "interaction" : "interacts with",
        "SUID" : 2421,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2417",
        "source" : "2293",
        "target" : "2415",
        "shared_name" : "gen4 (interacts with) Drain Punch",
        "name" : "gen4 (interacts with) Drain Punch",
        "interaction" : "interacts with",
        "SUID" : 2417,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2413",
        "source" : "2293",
        "target" : "2411",
        "shared_name" : "gen4 (interacts with) Dragon Rush",
        "name" : "gen4 (interacts with) Dragon Rush",
        "interaction" : "interacts with",
        "SUID" : 2413,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2409",
        "source" : "2293",
        "target" : "2407",
        "shared_name" : "gen4 (interacts with) Dragon Pulse",
        "name" : "gen4 (interacts with) Dragon Pulse",
        "interaction" : "interacts with",
        "SUID" : 2409,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2405",
        "source" : "2293",
        "target" : "2403",
        "shared_name" : "gen4 (interacts with) Draco Meteor",
        "name" : "gen4 (interacts with) Draco Meteor",
        "interaction" : "interacts with",
        "SUID" : 2405,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2401",
        "source" : "2293",
        "target" : "2399",
        "shared_name" : "gen4 (interacts with) Double Hit",
        "name" : "gen4 (interacts with) Double Hit",
        "interaction" : "interacts with",
        "SUID" : 2401,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2397",
        "source" : "2293",
        "target" : "2395",
        "shared_name" : "gen4 (interacts with) Discharge",
        "name" : "gen4 (interacts with) Discharge",
        "interaction" : "interacts with",
        "SUID" : 2397,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2393",
        "source" : "2293",
        "target" : "2391",
        "shared_name" : "gen4 (interacts with) Defog",
        "name" : "gen4 (interacts with) Defog",
        "interaction" : "interacts with",
        "SUID" : 2393,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2389",
        "source" : "2293",
        "target" : "2387",
        "shared_name" : "gen4 (interacts with) Defend Order",
        "name" : "gen4 (interacts with) Defend Order",
        "interaction" : "interacts with",
        "SUID" : 2389,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2385",
        "source" : "2293",
        "target" : "2383",
        "shared_name" : "gen4 (interacts with) Dark Void",
        "name" : "gen4 (interacts with) Dark Void",
        "interaction" : "interacts with",
        "SUID" : 2385,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2381",
        "source" : "2293",
        "target" : "2379",
        "shared_name" : "gen4 (interacts with) Dark Pulse",
        "name" : "gen4 (interacts with) Dark Pulse",
        "interaction" : "interacts with",
        "SUID" : 2381,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2377",
        "source" : "2293",
        "target" : "2375",
        "shared_name" : "gen4 (interacts with) Crush Grip",
        "name" : "gen4 (interacts with) Crush Grip",
        "interaction" : "interacts with",
        "SUID" : 2377,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2373",
        "source" : "2293",
        "target" : "2371",
        "shared_name" : "gen4 (interacts with) Cross Poison",
        "name" : "gen4 (interacts with) Cross Poison",
        "interaction" : "interacts with",
        "SUID" : 2373,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2369",
        "source" : "2293",
        "target" : "2367",
        "shared_name" : "gen4 (interacts with) Copycat",
        "name" : "gen4 (interacts with) Copycat",
        "interaction" : "interacts with",
        "SUID" : 2369,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2365",
        "source" : "2293",
        "target" : "2363",
        "shared_name" : "gen4 (interacts with) Close Combat",
        "name" : "gen4 (interacts with) Close Combat",
        "interaction" : "interacts with",
        "SUID" : 2365,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2361",
        "source" : "2293",
        "target" : "2359",
        "shared_name" : "gen4 (interacts with) Chatter",
        "name" : "gen4 (interacts with) Chatter",
        "interaction" : "interacts with",
        "SUID" : 2361,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2357",
        "source" : "2293",
        "target" : "2355",
        "shared_name" : "gen4 (interacts with) Charge Beam",
        "name" : "gen4 (interacts with) Charge Beam",
        "interaction" : "interacts with",
        "SUID" : 2357,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2353",
        "source" : "2293",
        "target" : "2351",
        "shared_name" : "gen4 (interacts with) Captivate",
        "name" : "gen4 (interacts with) Captivate",
        "interaction" : "interacts with",
        "SUID" : 2353,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2349",
        "source" : "2293",
        "target" : "2347",
        "shared_name" : "gen4 (interacts with) Bullet Punch",
        "name" : "gen4 (interacts with) Bullet Punch",
        "interaction" : "interacts with",
        "SUID" : 2349,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2345",
        "source" : "2293",
        "target" : "2343",
        "shared_name" : "gen4 (interacts with) Bug Buzz",
        "name" : "gen4 (interacts with) Bug Buzz",
        "interaction" : "interacts with",
        "SUID" : 2345,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2341",
        "source" : "2293",
        "target" : "2339",
        "shared_name" : "gen4 (interacts with) Bug Bite",
        "name" : "gen4 (interacts with) Bug Bite",
        "interaction" : "interacts with",
        "SUID" : 2341,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2337",
        "source" : "2293",
        "target" : "2335",
        "shared_name" : "gen4 (interacts with) Brine",
        "name" : "gen4 (interacts with) Brine",
        "interaction" : "interacts with",
        "SUID" : 2337,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2333",
        "source" : "2293",
        "target" : "2331",
        "shared_name" : "gen4 (interacts with) Brave Bird",
        "name" : "gen4 (interacts with) Brave Bird",
        "interaction" : "interacts with",
        "SUID" : 2333,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2329",
        "source" : "2293",
        "target" : "2327",
        "shared_name" : "gen4 (interacts with) Avalanche",
        "name" : "gen4 (interacts with) Avalanche",
        "interaction" : "interacts with",
        "SUID" : 2329,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2325",
        "source" : "2293",
        "target" : "2323",
        "shared_name" : "gen4 (interacts with) Aura Sphere",
        "name" : "gen4 (interacts with) Aura Sphere",
        "interaction" : "interacts with",
        "SUID" : 2325,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2321",
        "source" : "2293",
        "target" : "2319",
        "shared_name" : "gen4 (interacts with) Attack Order",
        "name" : "gen4 (interacts with) Attack Order",
        "interaction" : "interacts with",
        "SUID" : 2321,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2317",
        "source" : "2293",
        "target" : "2315",
        "shared_name" : "gen4 (interacts with) Assurance",
        "name" : "gen4 (interacts with) Assurance",
        "interaction" : "interacts with",
        "SUID" : 2317,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2313",
        "source" : "2293",
        "target" : "2311",
        "shared_name" : "gen4 (interacts with) Aqua Tail",
        "name" : "gen4 (interacts with) Aqua Tail",
        "interaction" : "interacts with",
        "SUID" : 2313,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2309",
        "source" : "2293",
        "target" : "2307",
        "shared_name" : "gen4 (interacts with) Aqua Ring",
        "name" : "gen4 (interacts with) Aqua Ring",
        "interaction" : "interacts with",
        "SUID" : 2309,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2305",
        "source" : "2293",
        "target" : "2303",
        "shared_name" : "gen4 (interacts with) Aqua Jet",
        "name" : "gen4 (interacts with) Aqua Jet",
        "interaction" : "interacts with",
        "SUID" : 2305,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2301",
        "source" : "2293",
        "target" : "2299",
        "shared_name" : "gen4 (interacts with) Air Slash",
        "name" : "gen4 (interacts with) Air Slash",
        "interaction" : "interacts with",
        "SUID" : 2301,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2297",
        "source" : "2293",
        "target" : "2295",
        "shared_name" : "gen4 (interacts with) Acupressure",
        "name" : "gen4 (interacts with) Acupressure",
        "interaction" : "interacts with",
        "SUID" : 2297,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2291",
        "source" : "1879",
        "target" : "2289",
        "shared_name" : "gen3 (interacts with) Yawn",
        "name" : "gen3 (interacts with) Yawn",
        "interaction" : "interacts with",
        "SUID" : 2291,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2287",
        "source" : "1879",
        "target" : "2285",
        "shared_name" : "gen3 (interacts with) Wish",
        "name" : "gen3 (interacts with) Wish",
        "interaction" : "interacts with",
        "SUID" : 2287,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2283",
        "source" : "1879",
        "target" : "2281",
        "shared_name" : "gen3 (interacts with) Will-O-Wisp",
        "name" : "gen3 (interacts with) Will-O-Wisp",
        "interaction" : "interacts with",
        "SUID" : 2283,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2279",
        "source" : "1879",
        "target" : "2277",
        "shared_name" : "gen3 (interacts with) Weather Ball",
        "name" : "gen3 (interacts with) Weather Ball",
        "interaction" : "interacts with",
        "SUID" : 2279,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2275",
        "source" : "1879",
        "target" : "2273",
        "shared_name" : "gen3 (interacts with) Water Spout",
        "name" : "gen3 (interacts with) Water Spout",
        "interaction" : "interacts with",
        "SUID" : 2275,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2271",
        "source" : "1879",
        "target" : "2269",
        "shared_name" : "gen3 (interacts with) Water Sport",
        "name" : "gen3 (interacts with) Water Sport",
        "interaction" : "interacts with",
        "SUID" : 2271,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2267",
        "source" : "1879",
        "target" : "2265",
        "shared_name" : "gen3 (interacts with) Water Pulse",
        "name" : "gen3 (interacts with) Water Pulse",
        "interaction" : "interacts with",
        "SUID" : 2267,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2263",
        "source" : "1879",
        "target" : "2261",
        "shared_name" : "gen3 (interacts with) Volt Tackle",
        "name" : "gen3 (interacts with) Volt Tackle",
        "interaction" : "interacts with",
        "SUID" : 2263,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2259",
        "source" : "1879",
        "target" : "2257",
        "shared_name" : "gen3 (interacts with) Uproar",
        "name" : "gen3 (interacts with) Uproar",
        "interaction" : "interacts with",
        "SUID" : 2259,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2255",
        "source" : "1879",
        "target" : "2253",
        "shared_name" : "gen3 (interacts with) Trick",
        "name" : "gen3 (interacts with) Trick",
        "interaction" : "interacts with",
        "SUID" : 2255,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2251",
        "source" : "1879",
        "target" : "2249",
        "shared_name" : "gen3 (interacts with) Torment",
        "name" : "gen3 (interacts with) Torment",
        "interaction" : "interacts with",
        "SUID" : 2251,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2247",
        "source" : "1879",
        "target" : "2245",
        "shared_name" : "gen3 (interacts with) Tickle",
        "name" : "gen3 (interacts with) Tickle",
        "interaction" : "interacts with",
        "SUID" : 2247,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2243",
        "source" : "1879",
        "target" : "2241",
        "shared_name" : "gen3 (interacts with) Teeter Dance",
        "name" : "gen3 (interacts with) Teeter Dance",
        "interaction" : "interacts with",
        "SUID" : 2243,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2239",
        "source" : "1879",
        "target" : "2237",
        "shared_name" : "gen3 (interacts with) Taunt",
        "name" : "gen3 (interacts with) Taunt",
        "interaction" : "interacts with",
        "SUID" : 2239,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2235",
        "source" : "1879",
        "target" : "2233",
        "shared_name" : "gen3 (interacts with) Tail Glow",
        "name" : "gen3 (interacts with) Tail Glow",
        "interaction" : "interacts with",
        "SUID" : 2235,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2231",
        "source" : "1879",
        "target" : "2229",
        "shared_name" : "gen3 (interacts with) Swallow",
        "name" : "gen3 (interacts with) Swallow",
        "interaction" : "interacts with",
        "SUID" : 2231,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2227",
        "source" : "1879",
        "target" : "2225",
        "shared_name" : "gen3 (interacts with) Superpower",
        "name" : "gen3 (interacts with) Superpower",
        "interaction" : "interacts with",
        "SUID" : 2227,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2223",
        "source" : "1879",
        "target" : "2221",
        "shared_name" : "gen3 (interacts with) Stockpile",
        "name" : "gen3 (interacts with) Stockpile",
        "interaction" : "interacts with",
        "SUID" : 2223,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2219",
        "source" : "1879",
        "target" : "2217",
        "shared_name" : "gen3 (interacts with) Spit Up",
        "name" : "gen3 (interacts with) Spit Up",
        "interaction" : "interacts with",
        "SUID" : 2219,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2215",
        "source" : "1879",
        "target" : "2213",
        "shared_name" : "gen3 (interacts with) Snatch",
        "name" : "gen3 (interacts with) Snatch",
        "interaction" : "interacts with",
        "SUID" : 2215,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2211",
        "source" : "1879",
        "target" : "2209",
        "shared_name" : "gen3 (interacts with) Smelling Salts",
        "name" : "gen3 (interacts with) Smelling Salts",
        "interaction" : "interacts with",
        "SUID" : 2211,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2207",
        "source" : "1879",
        "target" : "2205",
        "shared_name" : "gen3 (interacts with) Slack Off",
        "name" : "gen3 (interacts with) Slack Off",
        "interaction" : "interacts with",
        "SUID" : 2207,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2203",
        "source" : "1879",
        "target" : "2201",
        "shared_name" : "gen3 (interacts with) Sky Uppercut",
        "name" : "gen3 (interacts with) Sky Uppercut",
        "interaction" : "interacts with",
        "SUID" : 2203,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2199",
        "source" : "1879",
        "target" : "2197",
        "shared_name" : "gen3 (interacts with) Skill Swap",
        "name" : "gen3 (interacts with) Skill Swap",
        "interaction" : "interacts with",
        "SUID" : 2199,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2195",
        "source" : "1879",
        "target" : "2193",
        "shared_name" : "gen3 (interacts with) Silver Wind",
        "name" : "gen3 (interacts with) Silver Wind",
        "interaction" : "interacts with",
        "SUID" : 2195,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2191",
        "source" : "1879",
        "target" : "2189",
        "shared_name" : "gen3 (interacts with) Signal Beam",
        "name" : "gen3 (interacts with) Signal Beam",
        "interaction" : "interacts with",
        "SUID" : 2191,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2187",
        "source" : "1879",
        "target" : "2185",
        "shared_name" : "gen3 (interacts with) Shock Wave",
        "name" : "gen3 (interacts with) Shock Wave",
        "interaction" : "interacts with",
        "SUID" : 2187,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2183",
        "source" : "1879",
        "target" : "2181",
        "shared_name" : "gen3 (interacts with) Sheer Cold",
        "name" : "gen3 (interacts with) Sheer Cold",
        "interaction" : "interacts with",
        "SUID" : 2183,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2179",
        "source" : "1879",
        "target" : "2177",
        "shared_name" : "gen3 (interacts with) Shadow Punch",
        "name" : "gen3 (interacts with) Shadow Punch",
        "interaction" : "interacts with",
        "SUID" : 2179,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2175",
        "source" : "1879",
        "target" : "2173",
        "shared_name" : "gen3 (interacts with) Secret Power",
        "name" : "gen3 (interacts with) Secret Power",
        "interaction" : "interacts with",
        "SUID" : 2175,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2171",
        "source" : "1879",
        "target" : "2169",
        "shared_name" : "gen3 (interacts with) Sand Tomb",
        "name" : "gen3 (interacts with) Sand Tomb",
        "interaction" : "interacts with",
        "SUID" : 2171,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2167",
        "source" : "1879",
        "target" : "2165",
        "shared_name" : "gen3 (interacts with) Role Play",
        "name" : "gen3 (interacts with) Role Play",
        "interaction" : "interacts with",
        "SUID" : 2167,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2163",
        "source" : "1879",
        "target" : "2161",
        "shared_name" : "gen3 (interacts with) Rock Tomb",
        "name" : "gen3 (interacts with) Rock Tomb",
        "interaction" : "interacts with",
        "SUID" : 2163,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2159",
        "source" : "1879",
        "target" : "2157",
        "shared_name" : "gen3 (interacts with) Rock Blast",
        "name" : "gen3 (interacts with) Rock Blast",
        "interaction" : "interacts with",
        "SUID" : 2159,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2155",
        "source" : "1879",
        "target" : "2153",
        "shared_name" : "gen3 (interacts with) Revenge",
        "name" : "gen3 (interacts with) Revenge",
        "interaction" : "interacts with",
        "SUID" : 2155,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2151",
        "source" : "1879",
        "target" : "2149",
        "shared_name" : "gen3 (interacts with) Refresh",
        "name" : "gen3 (interacts with) Refresh",
        "interaction" : "interacts with",
        "SUID" : 2151,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2147",
        "source" : "1879",
        "target" : "2145",
        "shared_name" : "gen3 (interacts with) Recycle",
        "name" : "gen3 (interacts with) Recycle",
        "interaction" : "interacts with",
        "SUID" : 2147,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2143",
        "source" : "1879",
        "target" : "2141",
        "shared_name" : "gen3 (interacts with) Psycho Boost",
        "name" : "gen3 (interacts with) Psycho Boost",
        "interaction" : "interacts with",
        "SUID" : 2143,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2139",
        "source" : "1879",
        "target" : "2137",
        "shared_name" : "gen3 (interacts with) Poison Tail",
        "name" : "gen3 (interacts with) Poison Tail",
        "interaction" : "interacts with",
        "SUID" : 2139,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2135",
        "source" : "1879",
        "target" : "2133",
        "shared_name" : "gen3 (interacts with) Poison Fang",
        "name" : "gen3 (interacts with) Poison Fang",
        "interaction" : "interacts with",
        "SUID" : 2135,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2131",
        "source" : "1879",
        "target" : "2129",
        "shared_name" : "gen3 (interacts with) Overheat",
        "name" : "gen3 (interacts with) Overheat",
        "interaction" : "interacts with",
        "SUID" : 2131,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2127",
        "source" : "1879",
        "target" : "2125",
        "shared_name" : "gen3 (interacts with) Odor Sleuth",
        "name" : "gen3 (interacts with) Odor Sleuth",
        "interaction" : "interacts with",
        "SUID" : 2127,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2123",
        "source" : "1879",
        "target" : "2121",
        "shared_name" : "gen3 (interacts with) Needle Arm",
        "name" : "gen3 (interacts with) Needle Arm",
        "interaction" : "interacts with",
        "SUID" : 2123,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2119",
        "source" : "1879",
        "target" : "2117",
        "shared_name" : "gen3 (interacts with) Nature Power",
        "name" : "gen3 (interacts with) Nature Power",
        "interaction" : "interacts with",
        "SUID" : 2119,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2115",
        "source" : "1879",
        "target" : "2113",
        "shared_name" : "gen3 (interacts with) Muddy Water",
        "name" : "gen3 (interacts with) Muddy Water",
        "interaction" : "interacts with",
        "SUID" : 2115,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2111",
        "source" : "1879",
        "target" : "2109",
        "shared_name" : "gen3 (interacts with) Mud Sport",
        "name" : "gen3 (interacts with) Mud Sport",
        "interaction" : "interacts with",
        "SUID" : 2111,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2107",
        "source" : "1879",
        "target" : "2105",
        "shared_name" : "gen3 (interacts with) Mud Shot",
        "name" : "gen3 (interacts with) Mud Shot",
        "interaction" : "interacts with",
        "SUID" : 2107,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2103",
        "source" : "1879",
        "target" : "2101",
        "shared_name" : "gen3 (interacts with) Mist Ball",
        "name" : "gen3 (interacts with) Mist Ball",
        "interaction" : "interacts with",
        "SUID" : 2103,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2099",
        "source" : "1879",
        "target" : "2097",
        "shared_name" : "gen3 (interacts with) Meteor Mash",
        "name" : "gen3 (interacts with) Meteor Mash",
        "interaction" : "interacts with",
        "SUID" : 2099,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2095",
        "source" : "1879",
        "target" : "2093",
        "shared_name" : "gen3 (interacts with) Metal Sound",
        "name" : "gen3 (interacts with) Metal Sound",
        "interaction" : "interacts with",
        "SUID" : 2095,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2091",
        "source" : "1879",
        "target" : "2089",
        "shared_name" : "gen3 (interacts with) Memento",
        "name" : "gen3 (interacts with) Memento",
        "interaction" : "interacts with",
        "SUID" : 2091,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2087",
        "source" : "1879",
        "target" : "2085",
        "shared_name" : "gen3 (interacts with) Magical Leaf",
        "name" : "gen3 (interacts with) Magical Leaf",
        "interaction" : "interacts with",
        "SUID" : 2087,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2083",
        "source" : "1879",
        "target" : "2081",
        "shared_name" : "gen3 (interacts with) Magic Coat",
        "name" : "gen3 (interacts with) Magic Coat",
        "interaction" : "interacts with",
        "SUID" : 2083,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2079",
        "source" : "1879",
        "target" : "2077",
        "shared_name" : "gen3 (interacts with) Luster Purge",
        "name" : "gen3 (interacts with) Luster Purge",
        "interaction" : "interacts with",
        "SUID" : 2079,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2075",
        "source" : "1879",
        "target" : "2073",
        "shared_name" : "gen3 (interacts with) Leaf Blade",
        "name" : "gen3 (interacts with) Leaf Blade",
        "interaction" : "interacts with",
        "SUID" : 2075,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2071",
        "source" : "1879",
        "target" : "2069",
        "shared_name" : "gen3 (interacts with) Knock Off",
        "name" : "gen3 (interacts with) Knock Off",
        "interaction" : "interacts with",
        "SUID" : 2071,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2067",
        "source" : "1879",
        "target" : "2065",
        "shared_name" : "gen3 (interacts with) Iron Defense",
        "name" : "gen3 (interacts with) Iron Defense",
        "interaction" : "interacts with",
        "SUID" : 2067,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2063",
        "source" : "1879",
        "target" : "2061",
        "shared_name" : "gen3 (interacts with) Ingrain",
        "name" : "gen3 (interacts with) Ingrain",
        "interaction" : "interacts with",
        "SUID" : 2063,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2059",
        "source" : "1879",
        "target" : "2057",
        "shared_name" : "gen3 (interacts with) Imprison",
        "name" : "gen3 (interacts with) Imprison",
        "interaction" : "interacts with",
        "SUID" : 2059,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2055",
        "source" : "1879",
        "target" : "2053",
        "shared_name" : "gen3 (interacts with) Icicle Spear",
        "name" : "gen3 (interacts with) Icicle Spear",
        "interaction" : "interacts with",
        "SUID" : 2055,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2051",
        "source" : "1879",
        "target" : "2049",
        "shared_name" : "gen3 (interacts with) Ice Ball",
        "name" : "gen3 (interacts with) Ice Ball",
        "interaction" : "interacts with",
        "SUID" : 2051,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2047",
        "source" : "1879",
        "target" : "2045",
        "shared_name" : "gen3 (interacts with) Hyper Voice",
        "name" : "gen3 (interacts with) Hyper Voice",
        "interaction" : "interacts with",
        "SUID" : 2047,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2043",
        "source" : "1879",
        "target" : "2041",
        "shared_name" : "gen3 (interacts with) Hydro Cannon",
        "name" : "gen3 (interacts with) Hydro Cannon",
        "interaction" : "interacts with",
        "SUID" : 2043,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2039",
        "source" : "1879",
        "target" : "2037",
        "shared_name" : "gen3 (interacts with) Howl",
        "name" : "gen3 (interacts with) Howl",
        "interaction" : "interacts with",
        "SUID" : 2039,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2035",
        "source" : "1879",
        "target" : "2033",
        "shared_name" : "gen3 (interacts with) Helping Hand",
        "name" : "gen3 (interacts with) Helping Hand",
        "interaction" : "interacts with",
        "SUID" : 2035,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2031",
        "source" : "1879",
        "target" : "2029",
        "shared_name" : "gen3 (interacts with) Heat Wave",
        "name" : "gen3 (interacts with) Heat Wave",
        "interaction" : "interacts with",
        "SUID" : 2031,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2027",
        "source" : "1879",
        "target" : "2025",
        "shared_name" : "gen3 (interacts with) Hail",
        "name" : "gen3 (interacts with) Hail",
        "interaction" : "interacts with",
        "SUID" : 2027,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2023",
        "source" : "1879",
        "target" : "2021",
        "shared_name" : "gen3 (interacts with) Grudge",
        "name" : "gen3 (interacts with) Grudge",
        "interaction" : "interacts with",
        "SUID" : 2023,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2019",
        "source" : "1879",
        "target" : "2017",
        "shared_name" : "gen3 (interacts with) Grass Whistle",
        "name" : "gen3 (interacts with) Grass Whistle",
        "interaction" : "interacts with",
        "SUID" : 2019,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2015",
        "source" : "1879",
        "target" : "2013",
        "shared_name" : "gen3 (interacts with) Frenzy Plant",
        "name" : "gen3 (interacts with) Frenzy Plant",
        "interaction" : "interacts with",
        "SUID" : 2015,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2011",
        "source" : "1879",
        "target" : "2009",
        "shared_name" : "gen3 (interacts with) Follow Me",
        "name" : "gen3 (interacts with) Follow Me",
        "interaction" : "interacts with",
        "SUID" : 2011,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2007",
        "source" : "1879",
        "target" : "2005",
        "shared_name" : "gen3 (interacts with) Focus Punch",
        "name" : "gen3 (interacts with) Focus Punch",
        "interaction" : "interacts with",
        "SUID" : 2007,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2003",
        "source" : "1879",
        "target" : "2001",
        "shared_name" : "gen3 (interacts with) Flatter",
        "name" : "gen3 (interacts with) Flatter",
        "interaction" : "interacts with",
        "SUID" : 2003,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1999",
        "source" : "1879",
        "target" : "1997",
        "shared_name" : "gen3 (interacts with) Feather Dance",
        "name" : "gen3 (interacts with) Feather Dance",
        "interaction" : "interacts with",
        "SUID" : 1999,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1995",
        "source" : "1879",
        "target" : "1993",
        "shared_name" : "gen3 (interacts with) Fake Tears",
        "name" : "gen3 (interacts with) Fake Tears",
        "interaction" : "interacts with",
        "SUID" : 1995,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1991",
        "source" : "1879",
        "target" : "1989",
        "shared_name" : "gen3 (interacts with) Fake Out",
        "name" : "gen3 (interacts with) Fake Out",
        "interaction" : "interacts with",
        "SUID" : 1991,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1987",
        "source" : "1879",
        "target" : "1985",
        "shared_name" : "gen3 (interacts with) Facade",
        "name" : "gen3 (interacts with) Facade",
        "interaction" : "interacts with",
        "SUID" : 1987,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1983",
        "source" : "1879",
        "target" : "1981",
        "shared_name" : "gen3 (interacts with) Extrasensory",
        "name" : "gen3 (interacts with) Extrasensory",
        "interaction" : "interacts with",
        "SUID" : 1983,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1979",
        "source" : "1879",
        "target" : "1977",
        "shared_name" : "gen3 (interacts with) Eruption",
        "name" : "gen3 (interacts with) Eruption",
        "interaction" : "interacts with",
        "SUID" : 1979,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1975",
        "source" : "1879",
        "target" : "1973",
        "shared_name" : "gen3 (interacts with) Endeavor",
        "name" : "gen3 (interacts with) Endeavor",
        "interaction" : "interacts with",
        "SUID" : 1975,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1971",
        "source" : "1879",
        "target" : "1969",
        "shared_name" : "gen3 (interacts with) Dragon Dance",
        "name" : "gen3 (interacts with) Dragon Dance",
        "interaction" : "interacts with",
        "SUID" : 1971,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1967",
        "source" : "1879",
        "target" : "1965",
        "shared_name" : "gen3 (interacts with) Dragon Claw",
        "name" : "gen3 (interacts with) Dragon Claw",
        "interaction" : "interacts with",
        "SUID" : 1967,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1963",
        "source" : "1879",
        "target" : "1961",
        "shared_name" : "gen3 (interacts with) Doom Desire",
        "name" : "gen3 (interacts with) Doom Desire",
        "interaction" : "interacts with",
        "SUID" : 1963,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1959",
        "source" : "1879",
        "target" : "1957",
        "shared_name" : "gen3 (interacts with) Dive",
        "name" : "gen3 (interacts with) Dive",
        "interaction" : "interacts with",
        "SUID" : 1959,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1955",
        "source" : "1879",
        "target" : "1953",
        "shared_name" : "gen3 (interacts with) Crush Claw",
        "name" : "gen3 (interacts with) Crush Claw",
        "interaction" : "interacts with",
        "SUID" : 1955,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1951",
        "source" : "1879",
        "target" : "1949",
        "shared_name" : "gen3 (interacts with) Covet",
        "name" : "gen3 (interacts with) Covet",
        "interaction" : "interacts with",
        "SUID" : 1951,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1947",
        "source" : "1879",
        "target" : "1945",
        "shared_name" : "gen3 (interacts with) Cosmic Power",
        "name" : "gen3 (interacts with) Cosmic Power",
        "interaction" : "interacts with",
        "SUID" : 1947,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1943",
        "source" : "1879",
        "target" : "1941",
        "shared_name" : "gen3 (interacts with) Charge",
        "name" : "gen3 (interacts with) Charge",
        "interaction" : "interacts with",
        "SUID" : 1943,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1939",
        "source" : "1879",
        "target" : "1937",
        "shared_name" : "gen3 (interacts with) Camouflage",
        "name" : "gen3 (interacts with) Camouflage",
        "interaction" : "interacts with",
        "SUID" : 1939,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1935",
        "source" : "1879",
        "target" : "1933",
        "shared_name" : "gen3 (interacts with) Calm Mind",
        "name" : "gen3 (interacts with) Calm Mind",
        "interaction" : "interacts with",
        "SUID" : 1935,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1931",
        "source" : "1879",
        "target" : "1929",
        "shared_name" : "gen3 (interacts with) Bullet Seed",
        "name" : "gen3 (interacts with) Bullet Seed",
        "interaction" : "interacts with",
        "SUID" : 1931,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1927",
        "source" : "1879",
        "target" : "1925",
        "shared_name" : "gen3 (interacts with) Bulk Up",
        "name" : "gen3 (interacts with) Bulk Up",
        "interaction" : "interacts with",
        "SUID" : 1927,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1923",
        "source" : "1879",
        "target" : "1921",
        "shared_name" : "gen3 (interacts with) Brick Break",
        "name" : "gen3 (interacts with) Brick Break",
        "interaction" : "interacts with",
        "SUID" : 1923,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1919",
        "source" : "1879",
        "target" : "1917",
        "shared_name" : "gen3 (interacts with) Bounce",
        "name" : "gen3 (interacts with) Bounce",
        "interaction" : "interacts with",
        "SUID" : 1919,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1915",
        "source" : "1879",
        "target" : "1913",
        "shared_name" : "gen3 (interacts with) Block",
        "name" : "gen3 (interacts with) Block",
        "interaction" : "interacts with",
        "SUID" : 1915,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1911",
        "source" : "1879",
        "target" : "1909",
        "shared_name" : "gen3 (interacts with) Blaze Kick",
        "name" : "gen3 (interacts with) Blaze Kick",
        "interaction" : "interacts with",
        "SUID" : 1911,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1907",
        "source" : "1879",
        "target" : "1905",
        "shared_name" : "gen3 (interacts with) Blast Burn",
        "name" : "gen3 (interacts with) Blast Burn",
        "interaction" : "interacts with",
        "SUID" : 1907,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1903",
        "source" : "1879",
        "target" : "1901",
        "shared_name" : "gen3 (interacts with) Astonish",
        "name" : "gen3 (interacts with) Astonish",
        "interaction" : "interacts with",
        "SUID" : 1903,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1899",
        "source" : "1879",
        "target" : "1897",
        "shared_name" : "gen3 (interacts with) Assist",
        "name" : "gen3 (interacts with) Assist",
        "interaction" : "interacts with",
        "SUID" : 1899,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1895",
        "source" : "1879",
        "target" : "1893",
        "shared_name" : "gen3 (interacts with) Aromatherapy",
        "name" : "gen3 (interacts with) Aromatherapy",
        "interaction" : "interacts with",
        "SUID" : 1895,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1891",
        "source" : "1879",
        "target" : "1889",
        "shared_name" : "gen3 (interacts with) Arm Thrust",
        "name" : "gen3 (interacts with) Arm Thrust",
        "interaction" : "interacts with",
        "SUID" : 1891,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1887",
        "source" : "1879",
        "target" : "1885",
        "shared_name" : "gen3 (interacts with) Air Cutter",
        "name" : "gen3 (interacts with) Air Cutter",
        "interaction" : "interacts with",
        "SUID" : 1887,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1883",
        "source" : "1879",
        "target" : "1881",
        "shared_name" : "gen3 (interacts with) Aerial Ace",
        "name" : "gen3 (interacts with) Aerial Ace",
        "interaction" : "interacts with",
        "SUID" : 1883,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1877",
        "source" : "1533",
        "target" : "1875",
        "shared_name" : "gen2 (interacts with) Zap Cannon",
        "name" : "gen2 (interacts with) Zap Cannon",
        "interaction" : "interacts with",
        "SUID" : 1877,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1873",
        "source" : "1533",
        "target" : "1871",
        "shared_name" : "gen2 (interacts with) Whirlpool",
        "name" : "gen2 (interacts with) Whirlpool",
        "interaction" : "interacts with",
        "SUID" : 1873,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1869",
        "source" : "1533",
        "target" : "1867",
        "shared_name" : "gen2 (interacts with) Vital Throw",
        "name" : "gen2 (interacts with) Vital Throw",
        "interaction" : "interacts with",
        "SUID" : 1869,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1865",
        "source" : "1533",
        "target" : "1863",
        "shared_name" : "gen2 (interacts with) Twister",
        "name" : "gen2 (interacts with) Twister",
        "interaction" : "interacts with",
        "SUID" : 1865,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1861",
        "source" : "1533",
        "target" : "1859",
        "shared_name" : "gen2 (interacts with) Triple Kick",
        "name" : "gen2 (interacts with) Triple Kick",
        "interaction" : "interacts with",
        "SUID" : 1861,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1857",
        "source" : "1533",
        "target" : "1855",
        "shared_name" : "gen2 (interacts with) Thief",
        "name" : "gen2 (interacts with) Thief",
        "interaction" : "interacts with",
        "SUID" : 1857,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1853",
        "source" : "1533",
        "target" : "1851",
        "shared_name" : "gen2 (interacts with) Synthesis",
        "name" : "gen2 (interacts with) Synthesis",
        "interaction" : "interacts with",
        "SUID" : 1853,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1849",
        "source" : "1533",
        "target" : "1847",
        "shared_name" : "gen2 (interacts with) Sweet Scent",
        "name" : "gen2 (interacts with) Sweet Scent",
        "interaction" : "interacts with",
        "SUID" : 1849,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1845",
        "source" : "1533",
        "target" : "1843",
        "shared_name" : "gen2 (interacts with) Sweet Kiss",
        "name" : "gen2 (interacts with) Sweet Kiss",
        "interaction" : "interacts with",
        "SUID" : 1845,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1841",
        "source" : "1533",
        "target" : "1839",
        "shared_name" : "gen2 (interacts with) Swagger",
        "name" : "gen2 (interacts with) Swagger",
        "interaction" : "interacts with",
        "SUID" : 1841,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1837",
        "source" : "1533",
        "target" : "1835",
        "shared_name" : "gen2 (interacts with) Sunny Day",
        "name" : "gen2 (interacts with) Sunny Day",
        "interaction" : "interacts with",
        "SUID" : 1837,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1833",
        "source" : "1533",
        "target" : "1831",
        "shared_name" : "gen2 (interacts with) Steel Wing",
        "name" : "gen2 (interacts with) Steel Wing",
        "interaction" : "interacts with",
        "SUID" : 1833,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1829",
        "source" : "1533",
        "target" : "1827",
        "shared_name" : "gen2 (interacts with) Spite",
        "name" : "gen2 (interacts with) Spite",
        "interaction" : "interacts with",
        "SUID" : 1829,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1825",
        "source" : "1533",
        "target" : "1823",
        "shared_name" : "gen2 (interacts with) Spikes",
        "name" : "gen2 (interacts with) Spikes",
        "interaction" : "interacts with",
        "SUID" : 1825,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1821",
        "source" : "1533",
        "target" : "1819",
        "shared_name" : "gen2 (interacts with) Spider Web",
        "name" : "gen2 (interacts with) Spider Web",
        "interaction" : "interacts with",
        "SUID" : 1821,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1817",
        "source" : "1533",
        "target" : "1815",
        "shared_name" : "gen2 (interacts with) Spark",
        "name" : "gen2 (interacts with) Spark",
        "interaction" : "interacts with",
        "SUID" : 1817,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1813",
        "source" : "1533",
        "target" : "1811",
        "shared_name" : "gen2 (interacts with) Snore",
        "name" : "gen2 (interacts with) Snore",
        "interaction" : "interacts with",
        "SUID" : 1813,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1809",
        "source" : "1533",
        "target" : "1807",
        "shared_name" : "gen2 (interacts with) Sludge Bomb",
        "name" : "gen2 (interacts with) Sludge Bomb",
        "interaction" : "interacts with",
        "SUID" : 1809,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1805",
        "source" : "1533",
        "target" : "1803",
        "shared_name" : "gen2 (interacts with) Sleep Talk",
        "name" : "gen2 (interacts with) Sleep Talk",
        "interaction" : "interacts with",
        "SUID" : 1805,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1801",
        "source" : "1533",
        "target" : "1799",
        "shared_name" : "gen2 (interacts with) Sketch",
        "name" : "gen2 (interacts with) Sketch",
        "interaction" : "interacts with",
        "SUID" : 1801,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1797",
        "source" : "1533",
        "target" : "1795",
        "shared_name" : "gen2 (interacts with) Shadow Ball",
        "name" : "gen2 (interacts with) Shadow Ball",
        "interaction" : "interacts with",
        "SUID" : 1797,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1793",
        "source" : "1533",
        "target" : "1791",
        "shared_name" : "gen2 (interacts with) Scary Face",
        "name" : "gen2 (interacts with) Scary Face",
        "interaction" : "interacts with",
        "SUID" : 1793,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1789",
        "source" : "1533",
        "target" : "1787",
        "shared_name" : "gen2 (interacts with) Sandstorm",
        "name" : "gen2 (interacts with) Sandstorm",
        "interaction" : "interacts with",
        "SUID" : 1789,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1785",
        "source" : "1533",
        "target" : "1783",
        "shared_name" : "gen2 (interacts with) Safeguard",
        "name" : "gen2 (interacts with) Safeguard",
        "interaction" : "interacts with",
        "SUID" : 1785,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1781",
        "source" : "1533",
        "target" : "1779",
        "shared_name" : "gen2 (interacts with) Sacred Fire",
        "name" : "gen2 (interacts with) Sacred Fire",
        "interaction" : "interacts with",
        "SUID" : 1781,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1777",
        "source" : "1533",
        "target" : "1775",
        "shared_name" : "gen2 (interacts with) Rollout",
        "name" : "gen2 (interacts with) Rollout",
        "interaction" : "interacts with",
        "SUID" : 1777,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1773",
        "source" : "1533",
        "target" : "1771",
        "shared_name" : "gen2 (interacts with) Rock Smash",
        "name" : "gen2 (interacts with) Rock Smash",
        "interaction" : "interacts with",
        "SUID" : 1773,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1769",
        "source" : "1533",
        "target" : "1767",
        "shared_name" : "gen2 (interacts with) Reversal",
        "name" : "gen2 (interacts with) Reversal",
        "interaction" : "interacts with",
        "SUID" : 1769,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1765",
        "source" : "1533",
        "target" : "1763",
        "shared_name" : "gen2 (interacts with) Return",
        "name" : "gen2 (interacts with) Return",
        "interaction" : "interacts with",
        "SUID" : 1765,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1761",
        "source" : "1533",
        "target" : "1759",
        "shared_name" : "gen2 (interacts with) Rapid Spin",
        "name" : "gen2 (interacts with) Rapid Spin",
        "interaction" : "interacts with",
        "SUID" : 1761,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1757",
        "source" : "1533",
        "target" : "1755",
        "shared_name" : "gen2 (interacts with) Rain Dance",
        "name" : "gen2 (interacts with) Rain Dance",
        "interaction" : "interacts with",
        "SUID" : 1757,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1753",
        "source" : "1533",
        "target" : "1751",
        "shared_name" : "gen2 (interacts with) Pursuit",
        "name" : "gen2 (interacts with) Pursuit",
        "interaction" : "interacts with",
        "SUID" : 1753,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1749",
        "source" : "1533",
        "target" : "1747",
        "shared_name" : "gen2 (interacts with) Psych Up",
        "name" : "gen2 (interacts with) Psych Up",
        "interaction" : "interacts with",
        "SUID" : 1749,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1745",
        "source" : "1533",
        "target" : "1743",
        "shared_name" : "gen2 (interacts with) Protect",
        "name" : "gen2 (interacts with) Protect",
        "interaction" : "interacts with",
        "SUID" : 1745,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1741",
        "source" : "1533",
        "target" : "1739",
        "shared_name" : "gen2 (interacts with) Present",
        "name" : "gen2 (interacts with) Present",
        "interaction" : "interacts with",
        "SUID" : 1741,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1737",
        "source" : "1533",
        "target" : "1735",
        "shared_name" : "gen2 (interacts with) Powder Snow",
        "name" : "gen2 (interacts with) Powder Snow",
        "interaction" : "interacts with",
        "SUID" : 1737,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1733",
        "source" : "1533",
        "target" : "1731",
        "shared_name" : "gen2 (interacts with) Perish Song",
        "name" : "gen2 (interacts with) Perish Song",
        "interaction" : "interacts with",
        "SUID" : 1733,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1729",
        "source" : "1533",
        "target" : "1727",
        "shared_name" : "gen2 (interacts with) Pain Split",
        "name" : "gen2 (interacts with) Pain Split",
        "interaction" : "interacts with",
        "SUID" : 1729,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1725",
        "source" : "1533",
        "target" : "1723",
        "shared_name" : "gen2 (interacts with) Outrage",
        "name" : "gen2 (interacts with) Outrage",
        "interaction" : "interacts with",
        "SUID" : 1725,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1721",
        "source" : "1533",
        "target" : "1719",
        "shared_name" : "gen2 (interacts with) Octazooka",
        "name" : "gen2 (interacts with) Octazooka",
        "interaction" : "interacts with",
        "SUID" : 1721,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1717",
        "source" : "1533",
        "target" : "1715",
        "shared_name" : "gen2 (interacts with) Nightmare",
        "name" : "gen2 (interacts with) Nightmare",
        "interaction" : "interacts with",
        "SUID" : 1717,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1713",
        "source" : "1533",
        "target" : "1711",
        "shared_name" : "gen2 (interacts with) Mud-Slap",
        "name" : "gen2 (interacts with) Mud-Slap",
        "interaction" : "interacts with",
        "SUID" : 1713,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1709",
        "source" : "1533",
        "target" : "1707",
        "shared_name" : "gen2 (interacts with) Morning Sun",
        "name" : "gen2 (interacts with) Morning Sun",
        "interaction" : "interacts with",
        "SUID" : 1709,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1705",
        "source" : "1533",
        "target" : "1703",
        "shared_name" : "gen2 (interacts with) Moonlight",
        "name" : "gen2 (interacts with) Moonlight",
        "interaction" : "interacts with",
        "SUID" : 1705,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1701",
        "source" : "1533",
        "target" : "1699",
        "shared_name" : "gen2 (interacts with) Mirror Coat",
        "name" : "gen2 (interacts with) Mirror Coat",
        "interaction" : "interacts with",
        "SUID" : 1701,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1697",
        "source" : "1533",
        "target" : "1695",
        "shared_name" : "gen2 (interacts with) Mind Reader",
        "name" : "gen2 (interacts with) Mind Reader",
        "interaction" : "interacts with",
        "SUID" : 1697,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1693",
        "source" : "1533",
        "target" : "1691",
        "shared_name" : "gen2 (interacts with) Milk Drink",
        "name" : "gen2 (interacts with) Milk Drink",
        "interaction" : "interacts with",
        "SUID" : 1693,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1689",
        "source" : "1533",
        "target" : "1687",
        "shared_name" : "gen2 (interacts with) Metal Claw",
        "name" : "gen2 (interacts with) Metal Claw",
        "interaction" : "interacts with",
        "SUID" : 1689,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1685",
        "source" : "1533",
        "target" : "1683",
        "shared_name" : "gen2 (interacts with) Megahorn",
        "name" : "gen2 (interacts with) Megahorn",
        "interaction" : "interacts with",
        "SUID" : 1685,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1681",
        "source" : "1533",
        "target" : "1679",
        "shared_name" : "gen2 (interacts with) Mean Look",
        "name" : "gen2 (interacts with) Mean Look",
        "interaction" : "interacts with",
        "SUID" : 1681,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1677",
        "source" : "1533",
        "target" : "1675",
        "shared_name" : "gen2 (interacts with) Magnitude",
        "name" : "gen2 (interacts with) Magnitude",
        "interaction" : "interacts with",
        "SUID" : 1677,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1673",
        "source" : "1533",
        "target" : "1671",
        "shared_name" : "gen2 (interacts with) Mach Punch",
        "name" : "gen2 (interacts with) Mach Punch",
        "interaction" : "interacts with",
        "SUID" : 1673,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1669",
        "source" : "1533",
        "target" : "1667",
        "shared_name" : "gen2 (interacts with) Lock-On",
        "name" : "gen2 (interacts with) Lock-On",
        "interaction" : "interacts with",
        "SUID" : 1669,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1665",
        "source" : "1533",
        "target" : "1663",
        "shared_name" : "gen2 (interacts with) Iron Tail",
        "name" : "gen2 (interacts with) Iron Tail",
        "interaction" : "interacts with",
        "SUID" : 1665,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1661",
        "source" : "1533",
        "target" : "1659",
        "shared_name" : "gen2 (interacts with) Icy Wind",
        "name" : "gen2 (interacts with) Icy Wind",
        "interaction" : "interacts with",
        "SUID" : 1661,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1657",
        "source" : "1533",
        "target" : "1655",
        "shared_name" : "gen2 (interacts with) Hidden Power",
        "name" : "gen2 (interacts with) Hidden Power",
        "interaction" : "interacts with",
        "SUID" : 1657,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1653",
        "source" : "1533",
        "target" : "1651",
        "shared_name" : "gen2 (interacts with) Heal Bell",
        "name" : "gen2 (interacts with) Heal Bell",
        "interaction" : "interacts with",
        "SUID" : 1653,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1649",
        "source" : "1533",
        "target" : "1647",
        "shared_name" : "gen2 (interacts with) Giga Drain",
        "name" : "gen2 (interacts with) Giga Drain",
        "interaction" : "interacts with",
        "SUID" : 1649,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1645",
        "source" : "1533",
        "target" : "1643",
        "shared_name" : "gen2 (interacts with) Future Sight",
        "name" : "gen2 (interacts with) Future Sight",
        "interaction" : "interacts with",
        "SUID" : 1645,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1641",
        "source" : "1533",
        "target" : "1639",
        "shared_name" : "gen2 (interacts with) Fury Cutter",
        "name" : "gen2 (interacts with) Fury Cutter",
        "interaction" : "interacts with",
        "SUID" : 1641,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1637",
        "source" : "1533",
        "target" : "1635",
        "shared_name" : "gen2 (interacts with) Frustration",
        "name" : "gen2 (interacts with) Frustration",
        "interaction" : "interacts with",
        "SUID" : 1637,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1633",
        "source" : "1533",
        "target" : "1631",
        "shared_name" : "gen2 (interacts with) Foresight",
        "name" : "gen2 (interacts with) Foresight",
        "interaction" : "interacts with",
        "SUID" : 1633,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1629",
        "source" : "1533",
        "target" : "1627",
        "shared_name" : "gen2 (interacts with) Flame Wheel",
        "name" : "gen2 (interacts with) Flame Wheel",
        "interaction" : "interacts with",
        "SUID" : 1629,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1625",
        "source" : "1533",
        "target" : "1623",
        "shared_name" : "gen2 (interacts with) Flail",
        "name" : "gen2 (interacts with) Flail",
        "interaction" : "interacts with",
        "SUID" : 1625,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1621",
        "source" : "1533",
        "target" : "1619",
        "shared_name" : "gen2 (interacts with) Feint Attack",
        "name" : "gen2 (interacts with) Feint Attack",
        "interaction" : "interacts with",
        "SUID" : 1621,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1617",
        "source" : "1533",
        "target" : "1615",
        "shared_name" : "gen2 (interacts with) False Swipe",
        "name" : "gen2 (interacts with) False Swipe",
        "interaction" : "interacts with",
        "SUID" : 1617,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1613",
        "source" : "1533",
        "target" : "1611",
        "shared_name" : "gen2 (interacts with) Extreme Speed",
        "name" : "gen2 (interacts with) Extreme Speed",
        "interaction" : "interacts with",
        "SUID" : 1613,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1609",
        "source" : "1533",
        "target" : "1607",
        "shared_name" : "gen2 (interacts with) Endure",
        "name" : "gen2 (interacts with) Endure",
        "interaction" : "interacts with",
        "SUID" : 1609,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1605",
        "source" : "1533",
        "target" : "1603",
        "shared_name" : "gen2 (interacts with) Encore",
        "name" : "gen2 (interacts with) Encore",
        "interaction" : "interacts with",
        "SUID" : 1605,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1601",
        "source" : "1533",
        "target" : "1599",
        "shared_name" : "gen2 (interacts with) Dynamic Punch",
        "name" : "gen2 (interacts with) Dynamic Punch",
        "interaction" : "interacts with",
        "SUID" : 1601,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1597",
        "source" : "1533",
        "target" : "1595",
        "shared_name" : "gen2 (interacts with) Dragon Breath",
        "name" : "gen2 (interacts with) Dragon Breath",
        "interaction" : "interacts with",
        "SUID" : 1597,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1593",
        "source" : "1533",
        "target" : "1591",
        "shared_name" : "gen2 (interacts with) Detect",
        "name" : "gen2 (interacts with) Detect",
        "interaction" : "interacts with",
        "SUID" : 1593,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1589",
        "source" : "1533",
        "target" : "1587",
        "shared_name" : "gen2 (interacts with) Destiny Bond",
        "name" : "gen2 (interacts with) Destiny Bond",
        "interaction" : "interacts with",
        "SUID" : 1589,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1585",
        "source" : "1533",
        "target" : "1583",
        "shared_name" : "gen2 (interacts with) Curse",
        "name" : "gen2 (interacts with) Curse",
        "interaction" : "interacts with",
        "SUID" : 1585,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1581",
        "source" : "1533",
        "target" : "1579",
        "shared_name" : "gen2 (interacts with) Crunch",
        "name" : "gen2 (interacts with) Crunch",
        "interaction" : "interacts with",
        "SUID" : 1581,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1577",
        "source" : "1533",
        "target" : "1575",
        "shared_name" : "gen2 (interacts with) Cross Chop",
        "name" : "gen2 (interacts with) Cross Chop",
        "interaction" : "interacts with",
        "SUID" : 1577,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1573",
        "source" : "1533",
        "target" : "1571",
        "shared_name" : "gen2 (interacts with) Cotton Spore",
        "name" : "gen2 (interacts with) Cotton Spore",
        "interaction" : "interacts with",
        "SUID" : 1573,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1569",
        "source" : "1533",
        "target" : "1567",
        "shared_name" : "gen2 (interacts with) Conversion 2",
        "name" : "gen2 (interacts with) Conversion 2",
        "interaction" : "interacts with",
        "SUID" : 1569,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1565",
        "source" : "1533",
        "target" : "1563",
        "shared_name" : "gen2 (interacts with) Charm",
        "name" : "gen2 (interacts with) Charm",
        "interaction" : "interacts with",
        "SUID" : 1565,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1561",
        "source" : "1533",
        "target" : "1559",
        "shared_name" : "gen2 (interacts with) Bone Rush",
        "name" : "gen2 (interacts with) Bone Rush",
        "interaction" : "interacts with",
        "SUID" : 1561,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1557",
        "source" : "1533",
        "target" : "1555",
        "shared_name" : "gen2 (interacts with) Belly Drum",
        "name" : "gen2 (interacts with) Belly Drum",
        "interaction" : "interacts with",
        "SUID" : 1557,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1553",
        "source" : "1533",
        "target" : "1551",
        "shared_name" : "gen2 (interacts with) Beat Up",
        "name" : "gen2 (interacts with) Beat Up",
        "interaction" : "interacts with",
        "SUID" : 1553,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1549",
        "source" : "1533",
        "target" : "1547",
        "shared_name" : "gen2 (interacts with) Baton Pass",
        "name" : "gen2 (interacts with) Baton Pass",
        "interaction" : "interacts with",
        "SUID" : 1549,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1545",
        "source" : "1533",
        "target" : "1543",
        "shared_name" : "gen2 (interacts with) Attract",
        "name" : "gen2 (interacts with) Attract",
        "interaction" : "interacts with",
        "SUID" : 1545,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1541",
        "source" : "1533",
        "target" : "1539",
        "shared_name" : "gen2 (interacts with) Ancient Power",
        "name" : "gen2 (interacts with) Ancient Power",
        "interaction" : "interacts with",
        "SUID" : 1541,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1537",
        "source" : "1533",
        "target" : "1535",
        "shared_name" : "gen2 (interacts with) Aeroblast",
        "name" : "gen2 (interacts with) Aeroblast",
        "interaction" : "interacts with",
        "SUID" : 1537,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1531",
        "source" : "871",
        "target" : "1529",
        "shared_name" : "gen1 (interacts with) Wrap",
        "name" : "gen1 (interacts with) Wrap",
        "interaction" : "interacts with",
        "SUID" : 1531,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1527",
        "source" : "871",
        "target" : "1525",
        "shared_name" : "gen1 (interacts with) Withdraw",
        "name" : "gen1 (interacts with) Withdraw",
        "interaction" : "interacts with",
        "SUID" : 1527,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1523",
        "source" : "871",
        "target" : "1521",
        "shared_name" : "gen1 (interacts with) Wing Attack",
        "name" : "gen1 (interacts with) Wing Attack",
        "interaction" : "interacts with",
        "SUID" : 1523,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1519",
        "source" : "871",
        "target" : "1517",
        "shared_name" : "gen1 (interacts with) Whirlwind",
        "name" : "gen1 (interacts with) Whirlwind",
        "interaction" : "interacts with",
        "SUID" : 1519,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1515",
        "source" : "871",
        "target" : "1513",
        "shared_name" : "gen1 (interacts with) Waterfall",
        "name" : "gen1 (interacts with) Waterfall",
        "interaction" : "interacts with",
        "SUID" : 1515,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1511",
        "source" : "871",
        "target" : "1509",
        "shared_name" : "gen1 (interacts with) Water Gun",
        "name" : "gen1 (interacts with) Water Gun",
        "interaction" : "interacts with",
        "SUID" : 1511,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1507",
        "source" : "871",
        "target" : "1505",
        "shared_name" : "gen1 (interacts with) Vise Grip",
        "name" : "gen1 (interacts with) Vise Grip",
        "interaction" : "interacts with",
        "SUID" : 1507,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1503",
        "source" : "871",
        "target" : "1501",
        "shared_name" : "gen1 (interacts with) Vine Whip",
        "name" : "gen1 (interacts with) Vine Whip",
        "interaction" : "interacts with",
        "SUID" : 1503,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1499",
        "source" : "871",
        "target" : "1497",
        "shared_name" : "gen1 (interacts with) Twineedle",
        "name" : "gen1 (interacts with) Twineedle",
        "interaction" : "interacts with",
        "SUID" : 1499,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1495",
        "source" : "871",
        "target" : "1493",
        "shared_name" : "gen1 (interacts with) Tri Attack",
        "name" : "gen1 (interacts with) Tri Attack",
        "interaction" : "interacts with",
        "SUID" : 1495,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1491",
        "source" : "871",
        "target" : "1489",
        "shared_name" : "gen1 (interacts with) Transform",
        "name" : "gen1 (interacts with) Transform",
        "interaction" : "interacts with",
        "SUID" : 1491,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1487",
        "source" : "871",
        "target" : "1485",
        "shared_name" : "gen1 (interacts with) Toxic",
        "name" : "gen1 (interacts with) Toxic",
        "interaction" : "interacts with",
        "SUID" : 1487,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1483",
        "source" : "871",
        "target" : "1481",
        "shared_name" : "gen1 (interacts with) Thunderbolt",
        "name" : "gen1 (interacts with) Thunderbolt",
        "interaction" : "interacts with",
        "SUID" : 1483,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1479",
        "source" : "871",
        "target" : "1477",
        "shared_name" : "gen1 (interacts with) Thunder Wave",
        "name" : "gen1 (interacts with) Thunder Wave",
        "interaction" : "interacts with",
        "SUID" : 1479,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1475",
        "source" : "871",
        "target" : "1473",
        "shared_name" : "gen1 (interacts with) Thunder Shock",
        "name" : "gen1 (interacts with) Thunder Shock",
        "interaction" : "interacts with",
        "SUID" : 1475,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1471",
        "source" : "871",
        "target" : "1469",
        "shared_name" : "gen1 (interacts with) Thunder Punch",
        "name" : "gen1 (interacts with) Thunder Punch",
        "interaction" : "interacts with",
        "SUID" : 1471,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1467",
        "source" : "871",
        "target" : "1465",
        "shared_name" : "gen1 (interacts with) Thunder",
        "name" : "gen1 (interacts with) Thunder",
        "interaction" : "interacts with",
        "SUID" : 1467,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1463",
        "source" : "871",
        "target" : "1461",
        "shared_name" : "gen1 (interacts with) Thrash",
        "name" : "gen1 (interacts with) Thrash",
        "interaction" : "interacts with",
        "SUID" : 1463,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1459",
        "source" : "871",
        "target" : "1457",
        "shared_name" : "gen1 (interacts with) Teleport",
        "name" : "gen1 (interacts with) Teleport",
        "interaction" : "interacts with",
        "SUID" : 1459,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1455",
        "source" : "871",
        "target" : "1453",
        "shared_name" : "gen1 (interacts with) Take Down",
        "name" : "gen1 (interacts with) Take Down",
        "interaction" : "interacts with",
        "SUID" : 1455,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1451",
        "source" : "871",
        "target" : "1449",
        "shared_name" : "gen1 (interacts with) Tail Whip",
        "name" : "gen1 (interacts with) Tail Whip",
        "interaction" : "interacts with",
        "SUID" : 1451,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1447",
        "source" : "871",
        "target" : "1445",
        "shared_name" : "gen1 (interacts with) Tackle",
        "name" : "gen1 (interacts with) Tackle",
        "interaction" : "interacts with",
        "SUID" : 1447,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1443",
        "source" : "871",
        "target" : "1441",
        "shared_name" : "gen1 (interacts with) Swords Dance",
        "name" : "gen1 (interacts with) Swords Dance",
        "interaction" : "interacts with",
        "SUID" : 1443,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1439",
        "source" : "871",
        "target" : "1437",
        "shared_name" : "gen1 (interacts with) Swift",
        "name" : "gen1 (interacts with) Swift",
        "interaction" : "interacts with",
        "SUID" : 1439,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1435",
        "source" : "871",
        "target" : "1433",
        "shared_name" : "gen1 (interacts with) Surf",
        "name" : "gen1 (interacts with) Surf",
        "interaction" : "interacts with",
        "SUID" : 1435,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1431",
        "source" : "871",
        "target" : "1429",
        "shared_name" : "gen1 (interacts with) Supersonic",
        "name" : "gen1 (interacts with) Supersonic",
        "interaction" : "interacts with",
        "SUID" : 1431,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1427",
        "source" : "871",
        "target" : "1425",
        "shared_name" : "gen1 (interacts with) Super Fang",
        "name" : "gen1 (interacts with) Super Fang",
        "interaction" : "interacts with",
        "SUID" : 1427,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1423",
        "source" : "871",
        "target" : "1421",
        "shared_name" : "gen1 (interacts with) Substitute",
        "name" : "gen1 (interacts with) Substitute",
        "interaction" : "interacts with",
        "SUID" : 1423,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1419",
        "source" : "871",
        "target" : "1417",
        "shared_name" : "gen1 (interacts with) Submission",
        "name" : "gen1 (interacts with) Submission",
        "interaction" : "interacts with",
        "SUID" : 1419,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1415",
        "source" : "871",
        "target" : "1413",
        "shared_name" : "gen1 (interacts with) Stun Spore",
        "name" : "gen1 (interacts with) Stun Spore",
        "interaction" : "interacts with",
        "SUID" : 1415,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1411",
        "source" : "871",
        "target" : "1409",
        "shared_name" : "gen1 (interacts with) Struggle",
        "name" : "gen1 (interacts with) Struggle",
        "interaction" : "interacts with",
        "SUID" : 1411,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1407",
        "source" : "871",
        "target" : "1405",
        "shared_name" : "gen1 (interacts with) String Shot",
        "name" : "gen1 (interacts with) String Shot",
        "interaction" : "interacts with",
        "SUID" : 1407,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1403",
        "source" : "871",
        "target" : "1401",
        "shared_name" : "gen1 (interacts with) Strength",
        "name" : "gen1 (interacts with) Strength",
        "interaction" : "interacts with",
        "SUID" : 1403,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1399",
        "source" : "871",
        "target" : "1397",
        "shared_name" : "gen1 (interacts with) Stomp",
        "name" : "gen1 (interacts with) Stomp",
        "interaction" : "interacts with",
        "SUID" : 1399,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1395",
        "source" : "871",
        "target" : "1393",
        "shared_name" : "gen1 (interacts with) Spore",
        "name" : "gen1 (interacts with) Spore",
        "interaction" : "interacts with",
        "SUID" : 1395,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1391",
        "source" : "871",
        "target" : "1389",
        "shared_name" : "gen1 (interacts with) Splash",
        "name" : "gen1 (interacts with) Splash",
        "interaction" : "interacts with",
        "SUID" : 1391,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1387",
        "source" : "871",
        "target" : "1385",
        "shared_name" : "gen1 (interacts with) Spike Cannon",
        "name" : "gen1 (interacts with) Spike Cannon",
        "interaction" : "interacts with",
        "SUID" : 1387,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1383",
        "source" : "871",
        "target" : "1381",
        "shared_name" : "gen1 (interacts with) Sonic Boom",
        "name" : "gen1 (interacts with) Sonic Boom",
        "interaction" : "interacts with",
        "SUID" : 1383,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1379",
        "source" : "871",
        "target" : "1377",
        "shared_name" : "gen1 (interacts with) Solar Beam",
        "name" : "gen1 (interacts with) Solar Beam",
        "interaction" : "interacts with",
        "SUID" : 1379,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1375",
        "source" : "871",
        "target" : "1373",
        "shared_name" : "gen1 (interacts with) Soft-Boiled",
        "name" : "gen1 (interacts with) Soft-Boiled",
        "interaction" : "interacts with",
        "SUID" : 1375,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1371",
        "source" : "871",
        "target" : "1369",
        "shared_name" : "gen1 (interacts with) Smokescreen",
        "name" : "gen1 (interacts with) Smokescreen",
        "interaction" : "interacts with",
        "SUID" : 1371,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1367",
        "source" : "871",
        "target" : "1365",
        "shared_name" : "gen1 (interacts with) Smog",
        "name" : "gen1 (interacts with) Smog",
        "interaction" : "interacts with",
        "SUID" : 1367,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1363",
        "source" : "871",
        "target" : "1361",
        "shared_name" : "gen1 (interacts with) Sludge",
        "name" : "gen1 (interacts with) Sludge",
        "interaction" : "interacts with",
        "SUID" : 1363,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1359",
        "source" : "871",
        "target" : "1357",
        "shared_name" : "gen1 (interacts with) Sleep Powder",
        "name" : "gen1 (interacts with) Sleep Powder",
        "interaction" : "interacts with",
        "SUID" : 1359,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1355",
        "source" : "871",
        "target" : "1353",
        "shared_name" : "gen1 (interacts with) Slash",
        "name" : "gen1 (interacts with) Slash",
        "interaction" : "interacts with",
        "SUID" : 1355,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1351",
        "source" : "871",
        "target" : "1349",
        "shared_name" : "gen1 (interacts with) Slam",
        "name" : "gen1 (interacts with) Slam",
        "interaction" : "interacts with",
        "SUID" : 1351,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1347",
        "source" : "871",
        "target" : "1345",
        "shared_name" : "gen1 (interacts with) Sky Attack",
        "name" : "gen1 (interacts with) Sky Attack",
        "interaction" : "interacts with",
        "SUID" : 1347,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1343",
        "source" : "871",
        "target" : "1341",
        "shared_name" : "gen1 (interacts with) Skull Bash",
        "name" : "gen1 (interacts with) Skull Bash",
        "interaction" : "interacts with",
        "SUID" : 1343,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1339",
        "source" : "871",
        "target" : "1337",
        "shared_name" : "gen1 (interacts with) Sing",
        "name" : "gen1 (interacts with) Sing",
        "interaction" : "interacts with",
        "SUID" : 1339,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1335",
        "source" : "871",
        "target" : "1333",
        "shared_name" : "gen1 (interacts with) Sharpen",
        "name" : "gen1 (interacts with) Sharpen",
        "interaction" : "interacts with",
        "SUID" : 1335,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1331",
        "source" : "871",
        "target" : "1329",
        "shared_name" : "gen1 (interacts with) Self-Destruct",
        "name" : "gen1 (interacts with) Self-Destruct",
        "interaction" : "interacts with",
        "SUID" : 1331,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1327",
        "source" : "871",
        "target" : "1325",
        "shared_name" : "gen1 (interacts with) Seismic Toss",
        "name" : "gen1 (interacts with) Seismic Toss",
        "interaction" : "interacts with",
        "SUID" : 1327,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1323",
        "source" : "871",
        "target" : "1321",
        "shared_name" : "gen1 (interacts with) Screech",
        "name" : "gen1 (interacts with) Screech",
        "interaction" : "interacts with",
        "SUID" : 1323,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1319",
        "source" : "871",
        "target" : "1317",
        "shared_name" : "gen1 (interacts with) Scratch",
        "name" : "gen1 (interacts with) Scratch",
        "interaction" : "interacts with",
        "SUID" : 1319,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1315",
        "source" : "871",
        "target" : "1313",
        "shared_name" : "gen1 (interacts with) Sand Attack",
        "name" : "gen1 (interacts with) Sand Attack",
        "interaction" : "interacts with",
        "SUID" : 1315,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1311",
        "source" : "871",
        "target" : "1309",
        "shared_name" : "gen1 (interacts with) Rolling Kick",
        "name" : "gen1 (interacts with) Rolling Kick",
        "interaction" : "interacts with",
        "SUID" : 1311,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1307",
        "source" : "871",
        "target" : "1305",
        "shared_name" : "gen1 (interacts with) Rock Throw",
        "name" : "gen1 (interacts with) Rock Throw",
        "interaction" : "interacts with",
        "SUID" : 1307,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1303",
        "source" : "871",
        "target" : "1301",
        "shared_name" : "gen1 (interacts with) Rock Slide",
        "name" : "gen1 (interacts with) Rock Slide",
        "interaction" : "interacts with",
        "SUID" : 1303,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1299",
        "source" : "871",
        "target" : "1297",
        "shared_name" : "gen1 (interacts with) Roar",
        "name" : "gen1 (interacts with) Roar",
        "interaction" : "interacts with",
        "SUID" : 1299,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1295",
        "source" : "871",
        "target" : "1293",
        "shared_name" : "gen1 (interacts with) Rest",
        "name" : "gen1 (interacts with) Rest",
        "interaction" : "interacts with",
        "SUID" : 1295,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1291",
        "source" : "871",
        "target" : "1289",
        "shared_name" : "gen1 (interacts with) Reflect",
        "name" : "gen1 (interacts with) Reflect",
        "interaction" : "interacts with",
        "SUID" : 1291,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1287",
        "source" : "871",
        "target" : "1285",
        "shared_name" : "gen1 (interacts with) Recover",
        "name" : "gen1 (interacts with) Recover",
        "interaction" : "interacts with",
        "SUID" : 1287,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1283",
        "source" : "871",
        "target" : "1281",
        "shared_name" : "gen1 (interacts with) Razor Wind",
        "name" : "gen1 (interacts with) Razor Wind",
        "interaction" : "interacts with",
        "SUID" : 1283,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1279",
        "source" : "871",
        "target" : "1277",
        "shared_name" : "gen1 (interacts with) Razor Leaf",
        "name" : "gen1 (interacts with) Razor Leaf",
        "interaction" : "interacts with",
        "SUID" : 1279,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1275",
        "source" : "871",
        "target" : "1273",
        "shared_name" : "gen1 (interacts with) Rage",
        "name" : "gen1 (interacts with) Rage",
        "interaction" : "interacts with",
        "SUID" : 1275,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1271",
        "source" : "871",
        "target" : "1269",
        "shared_name" : "gen1 (interacts with) Quick Attack",
        "name" : "gen1 (interacts with) Quick Attack",
        "interaction" : "interacts with",
        "SUID" : 1271,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1267",
        "source" : "871",
        "target" : "1265",
        "shared_name" : "gen1 (interacts with) Psywave",
        "name" : "gen1 (interacts with) Psywave",
        "interaction" : "interacts with",
        "SUID" : 1267,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1263",
        "source" : "871",
        "target" : "1261",
        "shared_name" : "gen1 (interacts with) Psychic",
        "name" : "gen1 (interacts with) Psychic",
        "interaction" : "interacts with",
        "SUID" : 1263,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1259",
        "source" : "871",
        "target" : "1257",
        "shared_name" : "gen1 (interacts with) Psybeam",
        "name" : "gen1 (interacts with) Psybeam",
        "interaction" : "interacts with",
        "SUID" : 1259,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1255",
        "source" : "871",
        "target" : "1253",
        "shared_name" : "gen1 (interacts with) Pound",
        "name" : "gen1 (interacts with) Pound",
        "interaction" : "interacts with",
        "SUID" : 1255,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1251",
        "source" : "871",
        "target" : "1249",
        "shared_name" : "gen1 (interacts with) Poison Sting",
        "name" : "gen1 (interacts with) Poison Sting",
        "interaction" : "interacts with",
        "SUID" : 1251,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1247",
        "source" : "871",
        "target" : "1245",
        "shared_name" : "gen1 (interacts with) Poison Powder",
        "name" : "gen1 (interacts with) Poison Powder",
        "interaction" : "interacts with",
        "SUID" : 1247,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1243",
        "source" : "871",
        "target" : "1241",
        "shared_name" : "gen1 (interacts with) Poison Gas",
        "name" : "gen1 (interacts with) Poison Gas",
        "interaction" : "interacts with",
        "SUID" : 1243,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1239",
        "source" : "871",
        "target" : "1237",
        "shared_name" : "gen1 (interacts with) Pin Missile",
        "name" : "gen1 (interacts with) Pin Missile",
        "interaction" : "interacts with",
        "SUID" : 1239,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1235",
        "source" : "871",
        "target" : "1233",
        "shared_name" : "gen1 (interacts with) Petal Dance",
        "name" : "gen1 (interacts with) Petal Dance",
        "interaction" : "interacts with",
        "SUID" : 1235,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1231",
        "source" : "871",
        "target" : "1229",
        "shared_name" : "gen1 (interacts with) Peck",
        "name" : "gen1 (interacts with) Peck",
        "interaction" : "interacts with",
        "SUID" : 1231,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1227",
        "source" : "871",
        "target" : "1225",
        "shared_name" : "gen1 (interacts with) Pay Day",
        "name" : "gen1 (interacts with) Pay Day",
        "interaction" : "interacts with",
        "SUID" : 1227,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1223",
        "source" : "871",
        "target" : "1221",
        "shared_name" : "gen1 (interacts with) Night Shade",
        "name" : "gen1 (interacts with) Night Shade",
        "interaction" : "interacts with",
        "SUID" : 1223,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1219",
        "source" : "871",
        "target" : "1217",
        "shared_name" : "gen1 (interacts with) Mist",
        "name" : "gen1 (interacts with) Mist",
        "interaction" : "interacts with",
        "SUID" : 1219,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1215",
        "source" : "871",
        "target" : "1213",
        "shared_name" : "gen1 (interacts with) Mirror Move",
        "name" : "gen1 (interacts with) Mirror Move",
        "interaction" : "interacts with",
        "SUID" : 1215,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1211",
        "source" : "871",
        "target" : "1209",
        "shared_name" : "gen1 (interacts with) Minimize",
        "name" : "gen1 (interacts with) Minimize",
        "interaction" : "interacts with",
        "SUID" : 1211,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1207",
        "source" : "871",
        "target" : "1205",
        "shared_name" : "gen1 (interacts with) Mimic",
        "name" : "gen1 (interacts with) Mimic",
        "interaction" : "interacts with",
        "SUID" : 1207,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1203",
        "source" : "871",
        "target" : "1201",
        "shared_name" : "gen1 (interacts with) Metronome",
        "name" : "gen1 (interacts with) Metronome",
        "interaction" : "interacts with",
        "SUID" : 1203,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1199",
        "source" : "871",
        "target" : "1197",
        "shared_name" : "gen1 (interacts with) Mega Punch",
        "name" : "gen1 (interacts with) Mega Punch",
        "interaction" : "interacts with",
        "SUID" : 1199,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1195",
        "source" : "871",
        "target" : "1193",
        "shared_name" : "gen1 (interacts with) Mega Kick",
        "name" : "gen1 (interacts with) Mega Kick",
        "interaction" : "interacts with",
        "SUID" : 1195,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1191",
        "source" : "871",
        "target" : "1189",
        "shared_name" : "gen1 (interacts with) Mega Drain",
        "name" : "gen1 (interacts with) Mega Drain",
        "interaction" : "interacts with",
        "SUID" : 1191,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1187",
        "source" : "871",
        "target" : "1185",
        "shared_name" : "gen1 (interacts with) Meditate",
        "name" : "gen1 (interacts with) Meditate",
        "interaction" : "interacts with",
        "SUID" : 1187,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1183",
        "source" : "871",
        "target" : "1181",
        "shared_name" : "gen1 (interacts with) Low Kick",
        "name" : "gen1 (interacts with) Low Kick",
        "interaction" : "interacts with",
        "SUID" : 1183,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1179",
        "source" : "871",
        "target" : "1177",
        "shared_name" : "gen1 (interacts with) Lovely Kiss",
        "name" : "gen1 (interacts with) Lovely Kiss",
        "interaction" : "interacts with",
        "SUID" : 1179,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1175",
        "source" : "871",
        "target" : "1173",
        "shared_name" : "gen1 (interacts with) Light Screen",
        "name" : "gen1 (interacts with) Light Screen",
        "interaction" : "interacts with",
        "SUID" : 1175,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1171",
        "source" : "871",
        "target" : "1169",
        "shared_name" : "gen1 (interacts with) Lick",
        "name" : "gen1 (interacts with) Lick",
        "interaction" : "interacts with",
        "SUID" : 1171,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1167",
        "source" : "871",
        "target" : "1165",
        "shared_name" : "gen1 (interacts with) Leer",
        "name" : "gen1 (interacts with) Leer",
        "interaction" : "interacts with",
        "SUID" : 1167,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1163",
        "source" : "871",
        "target" : "1161",
        "shared_name" : "gen1 (interacts with) Leech Seed",
        "name" : "gen1 (interacts with) Leech Seed",
        "interaction" : "interacts with",
        "SUID" : 1163,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1159",
        "source" : "871",
        "target" : "1157",
        "shared_name" : "gen1 (interacts with) Leech Life",
        "name" : "gen1 (interacts with) Leech Life",
        "interaction" : "interacts with",
        "SUID" : 1159,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1155",
        "source" : "871",
        "target" : "1153",
        "shared_name" : "gen1 (interacts with) Kinesis",
        "name" : "gen1 (interacts with) Kinesis",
        "interaction" : "interacts with",
        "SUID" : 1155,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1151",
        "source" : "871",
        "target" : "1149",
        "shared_name" : "gen1 (interacts with) Karate Chop",
        "name" : "gen1 (interacts with) Karate Chop",
        "interaction" : "interacts with",
        "SUID" : 1151,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1147",
        "source" : "871",
        "target" : "1145",
        "shared_name" : "gen1 (interacts with) Jump Kick",
        "name" : "gen1 (interacts with) Jump Kick",
        "interaction" : "interacts with",
        "SUID" : 1147,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1143",
        "source" : "871",
        "target" : "1141",
        "shared_name" : "gen1 (interacts with) Ice Punch",
        "name" : "gen1 (interacts with) Ice Punch",
        "interaction" : "interacts with",
        "SUID" : 1143,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1139",
        "source" : "871",
        "target" : "1137",
        "shared_name" : "gen1 (interacts with) Ice Beam",
        "name" : "gen1 (interacts with) Ice Beam",
        "interaction" : "interacts with",
        "SUID" : 1139,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1135",
        "source" : "871",
        "target" : "1133",
        "shared_name" : "gen1 (interacts with) Hypnosis",
        "name" : "gen1 (interacts with) Hypnosis",
        "interaction" : "interacts with",
        "SUID" : 1135,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1131",
        "source" : "871",
        "target" : "1129",
        "shared_name" : "gen1 (interacts with) Hyper Fang",
        "name" : "gen1 (interacts with) Hyper Fang",
        "interaction" : "interacts with",
        "SUID" : 1131,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1127",
        "source" : "871",
        "target" : "1125",
        "shared_name" : "gen1 (interacts with) Hyper Beam",
        "name" : "gen1 (interacts with) Hyper Beam",
        "interaction" : "interacts with",
        "SUID" : 1127,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1123",
        "source" : "871",
        "target" : "1121",
        "shared_name" : "gen1 (interacts with) Hydro Pump",
        "name" : "gen1 (interacts with) Hydro Pump",
        "interaction" : "interacts with",
        "SUID" : 1123,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1119",
        "source" : "871",
        "target" : "1117",
        "shared_name" : "gen1 (interacts with) Horn Drill",
        "name" : "gen1 (interacts with) Horn Drill",
        "interaction" : "interacts with",
        "SUID" : 1119,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1115",
        "source" : "871",
        "target" : "1113",
        "shared_name" : "gen1 (interacts with) Horn Attack",
        "name" : "gen1 (interacts with) Horn Attack",
        "interaction" : "interacts with",
        "SUID" : 1115,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1111",
        "source" : "871",
        "target" : "1109",
        "shared_name" : "gen1 (interacts with) High Jump Kick",
        "name" : "gen1 (interacts with) High Jump Kick",
        "interaction" : "interacts with",
        "SUID" : 1111,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1107",
        "source" : "871",
        "target" : "1105",
        "shared_name" : "gen1 (interacts with) Headbutt",
        "name" : "gen1 (interacts with) Headbutt",
        "interaction" : "interacts with",
        "SUID" : 1107,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1103",
        "source" : "871",
        "target" : "1101",
        "shared_name" : "gen1 (interacts with) Haze",
        "name" : "gen1 (interacts with) Haze",
        "interaction" : "interacts with",
        "SUID" : 1103,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1099",
        "source" : "871",
        "target" : "1097",
        "shared_name" : "gen1 (interacts with) Harden",
        "name" : "gen1 (interacts with) Harden",
        "interaction" : "interacts with",
        "SUID" : 1099,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1095",
        "source" : "871",
        "target" : "1093",
        "shared_name" : "gen1 (interacts with) Gust",
        "name" : "gen1 (interacts with) Gust",
        "interaction" : "interacts with",
        "SUID" : 1095,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1091",
        "source" : "871",
        "target" : "1089",
        "shared_name" : "gen1 (interacts with) Guillotine",
        "name" : "gen1 (interacts with) Guillotine",
        "interaction" : "interacts with",
        "SUID" : 1091,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1087",
        "source" : "871",
        "target" : "1085",
        "shared_name" : "gen1 (interacts with) Growth",
        "name" : "gen1 (interacts with) Growth",
        "interaction" : "interacts with",
        "SUID" : 1087,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1083",
        "source" : "871",
        "target" : "1081",
        "shared_name" : "gen1 (interacts with) Growl",
        "name" : "gen1 (interacts with) Growl",
        "interaction" : "interacts with",
        "SUID" : 1083,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1079",
        "source" : "871",
        "target" : "1077",
        "shared_name" : "gen1 (interacts with) Glare",
        "name" : "gen1 (interacts with) Glare",
        "interaction" : "interacts with",
        "SUID" : 1079,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1075",
        "source" : "871",
        "target" : "1073",
        "shared_name" : "gen1 (interacts with) Fury Swipes",
        "name" : "gen1 (interacts with) Fury Swipes",
        "interaction" : "interacts with",
        "SUID" : 1075,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1071",
        "source" : "871",
        "target" : "1069",
        "shared_name" : "gen1 (interacts with) Fury Attack",
        "name" : "gen1 (interacts with) Fury Attack",
        "interaction" : "interacts with",
        "SUID" : 1071,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1067",
        "source" : "871",
        "target" : "1065",
        "shared_name" : "gen1 (interacts with) Focus Energy",
        "name" : "gen1 (interacts with) Focus Energy",
        "interaction" : "interacts with",
        "SUID" : 1067,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1063",
        "source" : "871",
        "target" : "1061",
        "shared_name" : "gen1 (interacts with) Fly",
        "name" : "gen1 (interacts with) Fly",
        "interaction" : "interacts with",
        "SUID" : 1063,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1059",
        "source" : "871",
        "target" : "1057",
        "shared_name" : "gen1 (interacts with) Flash",
        "name" : "gen1 (interacts with) Flash",
        "interaction" : "interacts with",
        "SUID" : 1059,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1055",
        "source" : "871",
        "target" : "1053",
        "shared_name" : "gen1 (interacts with) Flamethrower",
        "name" : "gen1 (interacts with) Flamethrower",
        "interaction" : "interacts with",
        "SUID" : 1055,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1051",
        "source" : "871",
        "target" : "1049",
        "shared_name" : "gen1 (interacts with) Fissure",
        "name" : "gen1 (interacts with) Fissure",
        "interaction" : "interacts with",
        "SUID" : 1051,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1047",
        "source" : "871",
        "target" : "1045",
        "shared_name" : "gen1 (interacts with) Fire Spin",
        "name" : "gen1 (interacts with) Fire Spin",
        "interaction" : "interacts with",
        "SUID" : 1047,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1043",
        "source" : "871",
        "target" : "1041",
        "shared_name" : "gen1 (interacts with) Fire Punch",
        "name" : "gen1 (interacts with) Fire Punch",
        "interaction" : "interacts with",
        "SUID" : 1043,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1039",
        "source" : "871",
        "target" : "1037",
        "shared_name" : "gen1 (interacts with) Fire Blast",
        "name" : "gen1 (interacts with) Fire Blast",
        "interaction" : "interacts with",
        "SUID" : 1039,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1035",
        "source" : "871",
        "target" : "1033",
        "shared_name" : "gen1 (interacts with) Explosion",
        "name" : "gen1 (interacts with) Explosion",
        "interaction" : "interacts with",
        "SUID" : 1035,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1031",
        "source" : "871",
        "target" : "1029",
        "shared_name" : "gen1 (interacts with) Ember",
        "name" : "gen1 (interacts with) Ember",
        "interaction" : "interacts with",
        "SUID" : 1031,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1027",
        "source" : "871",
        "target" : "1025",
        "shared_name" : "gen1 (interacts with) Egg Bomb",
        "name" : "gen1 (interacts with) Egg Bomb",
        "interaction" : "interacts with",
        "SUID" : 1027,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1023",
        "source" : "871",
        "target" : "1021",
        "shared_name" : "gen1 (interacts with) Earthquake",
        "name" : "gen1 (interacts with) Earthquake",
        "interaction" : "interacts with",
        "SUID" : 1023,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1019",
        "source" : "871",
        "target" : "1017",
        "shared_name" : "gen1 (interacts with) Drill Peck",
        "name" : "gen1 (interacts with) Drill Peck",
        "interaction" : "interacts with",
        "SUID" : 1019,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1015",
        "source" : "871",
        "target" : "1013",
        "shared_name" : "gen1 (interacts with) Dream Eater",
        "name" : "gen1 (interacts with) Dream Eater",
        "interaction" : "interacts with",
        "SUID" : 1015,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1011",
        "source" : "871",
        "target" : "1009",
        "shared_name" : "gen1 (interacts with) Dragon Rage",
        "name" : "gen1 (interacts with) Dragon Rage",
        "interaction" : "interacts with",
        "SUID" : 1011,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1007",
        "source" : "871",
        "target" : "1005",
        "shared_name" : "gen1 (interacts with) Double-Edge",
        "name" : "gen1 (interacts with) Double-Edge",
        "interaction" : "interacts with",
        "SUID" : 1007,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1003",
        "source" : "871",
        "target" : "1001",
        "shared_name" : "gen1 (interacts with) Double Team",
        "name" : "gen1 (interacts with) Double Team",
        "interaction" : "interacts with",
        "SUID" : 1003,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "999",
        "source" : "871",
        "target" : "997",
        "shared_name" : "gen1 (interacts with) Double Slap",
        "name" : "gen1 (interacts with) Double Slap",
        "interaction" : "interacts with",
        "SUID" : 999,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "995",
        "source" : "871",
        "target" : "993",
        "shared_name" : "gen1 (interacts with) Double Kick",
        "name" : "gen1 (interacts with) Double Kick",
        "interaction" : "interacts with",
        "SUID" : 995,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "991",
        "source" : "871",
        "target" : "989",
        "shared_name" : "gen1 (interacts with) Dizzy Punch",
        "name" : "gen1 (interacts with) Dizzy Punch",
        "interaction" : "interacts with",
        "SUID" : 991,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "987",
        "source" : "871",
        "target" : "985",
        "shared_name" : "gen1 (interacts with) Disable",
        "name" : "gen1 (interacts with) Disable",
        "interaction" : "interacts with",
        "SUID" : 987,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "983",
        "source" : "871",
        "target" : "981",
        "shared_name" : "gen1 (interacts with) Dig",
        "name" : "gen1 (interacts with) Dig",
        "interaction" : "interacts with",
        "SUID" : 983,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "979",
        "source" : "871",
        "target" : "977",
        "shared_name" : "gen1 (interacts with) Defense Curl",
        "name" : "gen1 (interacts with) Defense Curl",
        "interaction" : "interacts with",
        "SUID" : 979,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "975",
        "source" : "871",
        "target" : "973",
        "shared_name" : "gen1 (interacts with) Cut",
        "name" : "gen1 (interacts with) Cut",
        "interaction" : "interacts with",
        "SUID" : 975,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "971",
        "source" : "871",
        "target" : "969",
        "shared_name" : "gen1 (interacts with) Crabhammer",
        "name" : "gen1 (interacts with) Crabhammer",
        "interaction" : "interacts with",
        "SUID" : 971,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "967",
        "source" : "871",
        "target" : "965",
        "shared_name" : "gen1 (interacts with) Counter",
        "name" : "gen1 (interacts with) Counter",
        "interaction" : "interacts with",
        "SUID" : 967,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "963",
        "source" : "871",
        "target" : "961",
        "shared_name" : "gen1 (interacts with) Conversion",
        "name" : "gen1 (interacts with) Conversion",
        "interaction" : "interacts with",
        "SUID" : 963,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "959",
        "source" : "871",
        "target" : "957",
        "shared_name" : "gen1 (interacts with) Constrict",
        "name" : "gen1 (interacts with) Constrict",
        "interaction" : "interacts with",
        "SUID" : 959,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "955",
        "source" : "871",
        "target" : "953",
        "shared_name" : "gen1 (interacts with) Confusion",
        "name" : "gen1 (interacts with) Confusion",
        "interaction" : "interacts with",
        "SUID" : 955,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "951",
        "source" : "871",
        "target" : "949",
        "shared_name" : "gen1 (interacts with) Confuse Ray",
        "name" : "gen1 (interacts with) Confuse Ray",
        "interaction" : "interacts with",
        "SUID" : 951,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "947",
        "source" : "871",
        "target" : "945",
        "shared_name" : "gen1 (interacts with) Comet Punch",
        "name" : "gen1 (interacts with) Comet Punch",
        "interaction" : "interacts with",
        "SUID" : 947,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "943",
        "source" : "871",
        "target" : "941",
        "shared_name" : "gen1 (interacts with) Clamp",
        "name" : "gen1 (interacts with) Clamp",
        "interaction" : "interacts with",
        "SUID" : 943,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "939",
        "source" : "871",
        "target" : "937",
        "shared_name" : "gen1 (interacts with) Bubble Beam",
        "name" : "gen1 (interacts with) Bubble Beam",
        "interaction" : "interacts with",
        "SUID" : 939,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "935",
        "source" : "871",
        "target" : "933",
        "shared_name" : "gen1 (interacts with) Bubble",
        "name" : "gen1 (interacts with) Bubble",
        "interaction" : "interacts with",
        "SUID" : 935,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "931",
        "source" : "871",
        "target" : "929",
        "shared_name" : "gen1 (interacts with) Bonemerang",
        "name" : "gen1 (interacts with) Bonemerang",
        "interaction" : "interacts with",
        "SUID" : 931,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "927",
        "source" : "871",
        "target" : "925",
        "shared_name" : "gen1 (interacts with) Bone Club",
        "name" : "gen1 (interacts with) Bone Club",
        "interaction" : "interacts with",
        "SUID" : 927,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "923",
        "source" : "871",
        "target" : "921",
        "shared_name" : "gen1 (interacts with) Body Slam",
        "name" : "gen1 (interacts with) Body Slam",
        "interaction" : "interacts with",
        "SUID" : 923,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "919",
        "source" : "871",
        "target" : "917",
        "shared_name" : "gen1 (interacts with) Blizzard",
        "name" : "gen1 (interacts with) Blizzard",
        "interaction" : "interacts with",
        "SUID" : 919,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "915",
        "source" : "871",
        "target" : "913",
        "shared_name" : "gen1 (interacts with) Bite",
        "name" : "gen1 (interacts with) Bite",
        "interaction" : "interacts with",
        "SUID" : 915,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "911",
        "source" : "871",
        "target" : "909",
        "shared_name" : "gen1 (interacts with) Bind",
        "name" : "gen1 (interacts with) Bind",
        "interaction" : "interacts with",
        "SUID" : 911,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "907",
        "source" : "871",
        "target" : "905",
        "shared_name" : "gen1 (interacts with) Bide",
        "name" : "gen1 (interacts with) Bide",
        "interaction" : "interacts with",
        "SUID" : 907,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "903",
        "source" : "871",
        "target" : "901",
        "shared_name" : "gen1 (interacts with) Barrier",
        "name" : "gen1 (interacts with) Barrier",
        "interaction" : "interacts with",
        "SUID" : 903,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "899",
        "source" : "871",
        "target" : "897",
        "shared_name" : "gen1 (interacts with) Barrage",
        "name" : "gen1 (interacts with) Barrage",
        "interaction" : "interacts with",
        "SUID" : 899,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "895",
        "source" : "871",
        "target" : "893",
        "shared_name" : "gen1 (interacts with) Aurora Beam",
        "name" : "gen1 (interacts with) Aurora Beam",
        "interaction" : "interacts with",
        "SUID" : 895,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "891",
        "source" : "871",
        "target" : "889",
        "shared_name" : "gen1 (interacts with) Amnesia",
        "name" : "gen1 (interacts with) Amnesia",
        "interaction" : "interacts with",
        "SUID" : 891,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "887",
        "source" : "871",
        "target" : "885",
        "shared_name" : "gen1 (interacts with) Agility",
        "name" : "gen1 (interacts with) Agility",
        "interaction" : "interacts with",
        "SUID" : 887,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "883",
        "source" : "871",
        "target" : "881",
        "shared_name" : "gen1 (interacts with) Acid Armor",
        "name" : "gen1 (interacts with) Acid Armor",
        "interaction" : "interacts with",
        "SUID" : 883,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "879",
        "source" : "871",
        "target" : "877",
        "shared_name" : "gen1 (interacts with) Acid",
        "name" : "gen1 (interacts with) Acid",
        "interaction" : "interacts with",
        "SUID" : 879,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "875",
        "source" : "871",
        "target" : "873",
        "shared_name" : "gen1 (interacts with) Absorb",
        "name" : "gen1 (interacts with) Absorb",
        "interaction" : "interacts with",
        "SUID" : 875,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "869",
        "source" : "457",
        "target" : "867",
        "shared_name" : "gen7 (interacts with) Zippy Zap",
        "name" : "gen7 (interacts with) Zippy Zap",
        "interaction" : "interacts with",
        "SUID" : 869,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "865",
        "source" : "457",
        "target" : "863",
        "shared_name" : "gen7 (interacts with) Zing Zap",
        "name" : "gen7 (interacts with) Zing Zap",
        "interaction" : "interacts with",
        "SUID" : 865,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "861",
        "source" : "457",
        "target" : "859",
        "shared_name" : "gen7 (interacts with) Veevee Volley",
        "name" : "gen7 (interacts with) Veevee Volley",
        "interaction" : "interacts with",
        "SUID" : 861,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "857",
        "source" : "457",
        "target" : "855",
        "shared_name" : "gen7 (interacts with) Twinkle Tackle",
        "name" : "gen7 (interacts with) Twinkle Tackle",
        "interaction" : "interacts with",
        "SUID" : 857,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "853",
        "source" : "457",
        "target" : "851",
        "shared_name" : "gen7 (interacts with) Trop Kick",
        "name" : "gen7 (interacts with) Trop Kick",
        "interaction" : "interacts with",
        "SUID" : 853,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "849",
        "source" : "457",
        "target" : "847",
        "shared_name" : "gen7 (interacts with) Toxic Thread",
        "name" : "gen7 (interacts with) Toxic Thread",
        "interaction" : "interacts with",
        "SUID" : 849,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "845",
        "source" : "457",
        "target" : "843",
        "shared_name" : "gen7 (interacts with) Throat Chop",
        "name" : "gen7 (interacts with) Throat Chop",
        "interaction" : "interacts with",
        "SUID" : 845,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "841",
        "source" : "457",
        "target" : "839",
        "shared_name" : "gen7 (interacts with) Tectonic Rage",
        "name" : "gen7 (interacts with) Tectonic Rage",
        "interaction" : "interacts with",
        "SUID" : 841,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "837",
        "source" : "457",
        "target" : "835",
        "shared_name" : "gen7 (interacts with) Tearful Look",
        "name" : "gen7 (interacts with) Tearful Look",
        "interaction" : "interacts with",
        "SUID" : 837,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "833",
        "source" : "457",
        "target" : "831",
        "shared_name" : "gen7 (interacts with) Supersonic Skystrike",
        "name" : "gen7 (interacts with) Supersonic Skystrike",
        "interaction" : "interacts with",
        "SUID" : 833,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "829",
        "source" : "457",
        "target" : "827",
        "shared_name" : "gen7 (interacts with) Sunsteel Strike",
        "name" : "gen7 (interacts with) Sunsteel Strike",
        "interaction" : "interacts with",
        "SUID" : 829,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "825",
        "source" : "457",
        "target" : "823",
        "shared_name" : "gen7 (interacts with) Subzero Slammer",
        "name" : "gen7 (interacts with) Subzero Slammer",
        "interaction" : "interacts with",
        "SUID" : 825,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "821",
        "source" : "457",
        "target" : "819",
        "shared_name" : "gen7 (interacts with) Strength Sap",
        "name" : "gen7 (interacts with) Strength Sap",
        "interaction" : "interacts with",
        "SUID" : 821,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "817",
        "source" : "457",
        "target" : "815",
        "shared_name" : "gen7 (interacts with) Stomping Tantrum",
        "name" : "gen7 (interacts with) Stomping Tantrum",
        "interaction" : "interacts with",
        "SUID" : 817,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "813",
        "source" : "457",
        "target" : "811",
        "shared_name" : "gen7 (interacts with) Stoked Sparksurfer",
        "name" : "gen7 (interacts with) Stoked Sparksurfer",
        "interaction" : "interacts with",
        "SUID" : 813,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "809",
        "source" : "457",
        "target" : "807",
        "shared_name" : "gen7 (interacts with) Spotlight",
        "name" : "gen7 (interacts with) Spotlight",
        "interaction" : "interacts with",
        "SUID" : 809,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "805",
        "source" : "457",
        "target" : "803",
        "shared_name" : "gen7 (interacts with) Splishy Splash",
        "name" : "gen7 (interacts with) Splishy Splash",
        "interaction" : "interacts with",
        "SUID" : 805,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "801",
        "source" : "457",
        "target" : "799",
        "shared_name" : "gen7 (interacts with) Splintered Stormshards",
        "name" : "gen7 (interacts with) Splintered Stormshards",
        "interaction" : "interacts with",
        "SUID" : 801,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "797",
        "source" : "457",
        "target" : "795",
        "shared_name" : "gen7 (interacts with) Spirit Shackle",
        "name" : "gen7 (interacts with) Spirit Shackle",
        "interaction" : "interacts with",
        "SUID" : 797,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "793",
        "source" : "457",
        "target" : "791",
        "shared_name" : "gen7 (interacts with) Speed Swap",
        "name" : "gen7 (interacts with) Speed Swap",
        "interaction" : "interacts with",
        "SUID" : 793,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "789",
        "source" : "457",
        "target" : "787",
        "shared_name" : "gen7 (interacts with) Spectral Thief",
        "name" : "gen7 (interacts with) Spectral Thief",
        "interaction" : "interacts with",
        "SUID" : 789,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "785",
        "source" : "457",
        "target" : "783",
        "shared_name" : "gen7 (interacts with) Sparkly Swirl",
        "name" : "gen7 (interacts with) Sparkly Swirl",
        "interaction" : "interacts with",
        "SUID" : 785,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "781",
        "source" : "457",
        "target" : "779",
        "shared_name" : "gen7 (interacts with) Sparkling Aria",
        "name" : "gen7 (interacts with) Sparkling Aria",
        "interaction" : "interacts with",
        "SUID" : 781,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "777",
        "source" : "457",
        "target" : "775",
        "shared_name" : "gen7 (interacts with) Soul-Stealing 7-Star Strike",
        "name" : "gen7 (interacts with) Soul-Stealing 7-Star Strike",
        "interaction" : "interacts with",
        "SUID" : 777,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "773",
        "source" : "457",
        "target" : "771",
        "shared_name" : "gen7 (interacts with) Solar Blade",
        "name" : "gen7 (interacts with) Solar Blade",
        "interaction" : "interacts with",
        "SUID" : 773,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "769",
        "source" : "457",
        "target" : "767",
        "shared_name" : "gen7 (interacts with) Smart Strike",
        "name" : "gen7 (interacts with) Smart Strike",
        "interaction" : "interacts with",
        "SUID" : 769,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "765",
        "source" : "457",
        "target" : "763",
        "shared_name" : "gen7 (interacts with) Sizzly Slide",
        "name" : "gen7 (interacts with) Sizzly Slide",
        "interaction" : "interacts with",
        "SUID" : 765,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "761",
        "source" : "457",
        "target" : "759",
        "shared_name" : "gen7 (interacts with) Sinister Arrow Raid",
        "name" : "gen7 (interacts with) Sinister Arrow Raid",
        "interaction" : "interacts with",
        "SUID" : 761,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "757",
        "source" : "457",
        "target" : "755",
        "shared_name" : "gen7 (interacts with) Shore Up",
        "name" : "gen7 (interacts with) Shore Up",
        "interaction" : "interacts with",
        "SUID" : 757,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "753",
        "source" : "457",
        "target" : "751",
        "shared_name" : "gen7 (interacts with) Shell Trap",
        "name" : "gen7 (interacts with) Shell Trap",
        "interaction" : "interacts with",
        "SUID" : 753,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "749",
        "source" : "457",
        "target" : "747",
        "shared_name" : "gen7 (interacts with) Shattered Psyche",
        "name" : "gen7 (interacts with) Shattered Psyche",
        "interaction" : "interacts with",
        "SUID" : 749,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "745",
        "source" : "457",
        "target" : "743",
        "shared_name" : "gen7 (interacts with) Shadow Bone",
        "name" : "gen7 (interacts with) Shadow Bone",
        "interaction" : "interacts with",
        "SUID" : 745,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "741",
        "source" : "457",
        "target" : "739",
        "shared_name" : "gen7 (interacts with) Searing Sunraze Smash",
        "name" : "gen7 (interacts with) Searing Sunraze Smash",
        "interaction" : "interacts with",
        "SUID" : 741,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "737",
        "source" : "457",
        "target" : "735",
        "shared_name" : "gen7 (interacts with) Savage Spin-Out",
        "name" : "gen7 (interacts with) Savage Spin-Out",
        "interaction" : "interacts with",
        "SUID" : 737,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "733",
        "source" : "457",
        "target" : "731",
        "shared_name" : "gen7 (interacts with) Sappy Seed",
        "name" : "gen7 (interacts with) Sappy Seed",
        "interaction" : "interacts with",
        "SUID" : 733,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "729",
        "source" : "457",
        "target" : "727",
        "shared_name" : "gen7 (interacts with) Revelation Dance",
        "name" : "gen7 (interacts with) Revelation Dance",
        "interaction" : "interacts with",
        "SUID" : 729,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "725",
        "source" : "457",
        "target" : "723",
        "shared_name" : "gen7 (interacts with) Purify",
        "name" : "gen7 (interacts with) Purify",
        "interaction" : "interacts with",
        "SUID" : 725,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "721",
        "source" : "457",
        "target" : "719",
        "shared_name" : "gen7 (interacts with) Pulverizing Pancake",
        "name" : "gen7 (interacts with) Pulverizing Pancake",
        "interaction" : "interacts with",
        "SUID" : 721,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "717",
        "source" : "457",
        "target" : "715",
        "shared_name" : "gen7 (interacts with) Psychic Terrain",
        "name" : "gen7 (interacts with) Psychic Terrain",
        "interaction" : "interacts with",
        "SUID" : 717,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "713",
        "source" : "457",
        "target" : "711",
        "shared_name" : "gen7 (interacts with) Psychic Fangs",
        "name" : "gen7 (interacts with) Psychic Fangs",
        "interaction" : "interacts with",
        "SUID" : 713,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "709",
        "source" : "457",
        "target" : "707",
        "shared_name" : "gen7 (interacts with) Prismatic Laser",
        "name" : "gen7 (interacts with) Prismatic Laser",
        "interaction" : "interacts with",
        "SUID" : 709,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "705",
        "source" : "457",
        "target" : "703",
        "shared_name" : "gen7 (interacts with) Power Trip",
        "name" : "gen7 (interacts with) Power Trip",
        "interaction" : "interacts with",
        "SUID" : 705,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "701",
        "source" : "457",
        "target" : "699",
        "shared_name" : "gen7 (interacts with) Pollen Puff",
        "name" : "gen7 (interacts with) Pollen Puff",
        "interaction" : "interacts with",
        "SUID" : 701,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "697",
        "source" : "457",
        "target" : "695",
        "shared_name" : "gen7 (interacts with) Plasma Fists",
        "name" : "gen7 (interacts with) Plasma Fists",
        "interaction" : "interacts with",
        "SUID" : 697,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "693",
        "source" : "457",
        "target" : "691",
        "shared_name" : "gen7 (interacts with) Pika Papow",
        "name" : "gen7 (interacts with) Pika Papow",
        "interaction" : "interacts with",
        "SUID" : 693,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "689",
        "source" : "457",
        "target" : "687",
        "shared_name" : "gen7 (interacts with) Photon Geyser",
        "name" : "gen7 (interacts with) Photon Geyser",
        "interaction" : "interacts with",
        "SUID" : 689,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "685",
        "source" : "457",
        "target" : "683",
        "shared_name" : "gen7 (interacts with) Oceanic Operetta",
        "name" : "gen7 (interacts with) Oceanic Operetta",
        "interaction" : "interacts with",
        "SUID" : 685,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "681",
        "source" : "457",
        "target" : "679",
        "shared_name" : "gen7 (interacts with) Never-Ending Nightmare",
        "name" : "gen7 (interacts with) Never-Ending Nightmare",
        "interaction" : "interacts with",
        "SUID" : 681,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "677",
        "source" : "457",
        "target" : "675",
        "shared_name" : "gen7 (interacts with) Nature's Madness",
        "name" : "gen7 (interacts with) Nature's Madness",
        "interaction" : "interacts with",
        "SUID" : 677,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "673",
        "source" : "457",
        "target" : "671",
        "shared_name" : "gen7 (interacts with) Multi-Attack",
        "name" : "gen7 (interacts with) Multi-Attack",
        "interaction" : "interacts with",
        "SUID" : 673,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "669",
        "source" : "457",
        "target" : "667",
        "shared_name" : "gen7 (interacts with) Moongeist Beam",
        "name" : "gen7 (interacts with) Moongeist Beam",
        "interaction" : "interacts with",
        "SUID" : 669,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "665",
        "source" : "457",
        "target" : "663",
        "shared_name" : "gen7 (interacts with) Mind Blown",
        "name" : "gen7 (interacts with) Mind Blown",
        "interaction" : "interacts with",
        "SUID" : 665,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "661",
        "source" : "457",
        "target" : "659",
        "shared_name" : "gen7 (interacts with) Menacing Moonraze Maelstrom",
        "name" : "gen7 (interacts with) Menacing Moonraze Maelstrom",
        "interaction" : "interacts with",
        "SUID" : 661,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "657",
        "source" : "457",
        "target" : "655",
        "shared_name" : "gen7 (interacts with) Malicious Moonsault",
        "name" : "gen7 (interacts with) Malicious Moonsault",
        "interaction" : "interacts with",
        "SUID" : 657,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "653",
        "source" : "457",
        "target" : "651",
        "shared_name" : "gen7 (interacts with) Lunge",
        "name" : "gen7 (interacts with) Lunge",
        "interaction" : "interacts with",
        "SUID" : 653,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "649",
        "source" : "457",
        "target" : "647",
        "shared_name" : "gen7 (interacts with) Liquidation",
        "name" : "gen7 (interacts with) Liquidation",
        "interaction" : "interacts with",
        "SUID" : 649,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "645",
        "source" : "457",
        "target" : "643",
        "shared_name" : "gen7 (interacts with) Light That Burns the Sky",
        "name" : "gen7 (interacts with) Light That Burns the Sky",
        "interaction" : "interacts with",
        "SUID" : 645,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "641",
        "source" : "457",
        "target" : "639",
        "shared_name" : "gen7 (interacts with) Let's Snuggle Forever",
        "name" : "gen7 (interacts with) Let's Snuggle Forever",
        "interaction" : "interacts with",
        "SUID" : 641,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "637",
        "source" : "457",
        "target" : "635",
        "shared_name" : "gen7 (interacts with) Leafage",
        "name" : "gen7 (interacts with) Leafage",
        "interaction" : "interacts with",
        "SUID" : 637,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "633",
        "source" : "457",
        "target" : "631",
        "shared_name" : "gen7 (interacts with) Laser Focus",
        "name" : "gen7 (interacts with) Laser Focus",
        "interaction" : "interacts with",
        "SUID" : 633,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "629",
        "source" : "457",
        "target" : "627",
        "shared_name" : "gen7 (interacts with) Instruct",
        "name" : "gen7 (interacts with) Instruct",
        "interaction" : "interacts with",
        "SUID" : 629,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "625",
        "source" : "457",
        "target" : "623",
        "shared_name" : "gen7 (interacts with) Inferno Overdrive",
        "name" : "gen7 (interacts with) Inferno Overdrive",
        "interaction" : "interacts with",
        "SUID" : 625,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "621",
        "source" : "457",
        "target" : "619",
        "shared_name" : "gen7 (interacts with) Ice Hammer",
        "name" : "gen7 (interacts with) Ice Hammer",
        "interaction" : "interacts with",
        "SUID" : 621,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "617",
        "source" : "457",
        "target" : "615",
        "shared_name" : "gen7 (interacts with) Hydro Vortex",
        "name" : "gen7 (interacts with) Hydro Vortex",
        "interaction" : "interacts with",
        "SUID" : 617,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "613",
        "source" : "457",
        "target" : "611",
        "shared_name" : "gen7 (interacts with) High Horsepower",
        "name" : "gen7 (interacts with) High Horsepower",
        "interaction" : "interacts with",
        "SUID" : 613,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "609",
        "source" : "457",
        "target" : "607",
        "shared_name" : "gen7 (interacts with) Guardian of Alola",
        "name" : "gen7 (interacts with) Guardian of Alola",
        "interaction" : "interacts with",
        "SUID" : 609,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "605",
        "source" : "457",
        "target" : "603",
        "shared_name" : "gen7 (interacts with) Glitzy Glow",
        "name" : "gen7 (interacts with) Glitzy Glow",
        "interaction" : "interacts with",
        "SUID" : 605,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "601",
        "source" : "457",
        "target" : "599",
        "shared_name" : "gen7 (interacts with) Gigavolt Havoc",
        "name" : "gen7 (interacts with) Gigavolt Havoc",
        "interaction" : "interacts with",
        "SUID" : 601,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "597",
        "source" : "457",
        "target" : "595",
        "shared_name" : "gen7 (interacts with) Genesis Supernova",
        "name" : "gen7 (interacts with) Genesis Supernova",
        "interaction" : "interacts with",
        "SUID" : 597,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "593",
        "source" : "457",
        "target" : "591",
        "shared_name" : "gen7 (interacts with) Gear Up",
        "name" : "gen7 (interacts with) Gear Up",
        "interaction" : "interacts with",
        "SUID" : 593,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "589",
        "source" : "457",
        "target" : "587",
        "shared_name" : "gen7 (interacts with) Freezy Frost",
        "name" : "gen7 (interacts with) Freezy Frost",
        "interaction" : "interacts with",
        "SUID" : 589,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "585",
        "source" : "457",
        "target" : "583",
        "shared_name" : "gen7 (interacts with) Floral Healing",
        "name" : "gen7 (interacts with) Floral Healing",
        "interaction" : "interacts with",
        "SUID" : 585,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "581",
        "source" : "457",
        "target" : "579",
        "shared_name" : "gen7 (interacts with) Floaty Fall",
        "name" : "gen7 (interacts with) Floaty Fall",
        "interaction" : "interacts with",
        "SUID" : 581,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "577",
        "source" : "457",
        "target" : "575",
        "shared_name" : "gen7 (interacts with) Fleur Cannon",
        "name" : "gen7 (interacts with) Fleur Cannon",
        "interaction" : "interacts with",
        "SUID" : 577,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "573",
        "source" : "457",
        "target" : "571",
        "shared_name" : "gen7 (interacts with) First Impression",
        "name" : "gen7 (interacts with) First Impression",
        "interaction" : "interacts with",
        "SUID" : 573,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "569",
        "source" : "457",
        "target" : "567",
        "shared_name" : "gen7 (interacts with) Fire Lash",
        "name" : "gen7 (interacts with) Fire Lash",
        "interaction" : "interacts with",
        "SUID" : 569,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "565",
        "source" : "457",
        "target" : "563",
        "shared_name" : "gen7 (interacts with) Extreme Evoboost",
        "name" : "gen7 (interacts with) Extreme Evoboost",
        "interaction" : "interacts with",
        "SUID" : 565,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "561",
        "source" : "457",
        "target" : "559",
        "shared_name" : "gen7 (interacts with) Dragon Hammer",
        "name" : "gen7 (interacts with) Dragon Hammer",
        "interaction" : "interacts with",
        "SUID" : 561,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "557",
        "source" : "457",
        "target" : "555",
        "shared_name" : "gen7 (interacts with) Double Iron Bash",
        "name" : "gen7 (interacts with) Double Iron Bash",
        "interaction" : "interacts with",
        "SUID" : 557,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "553",
        "source" : "457",
        "target" : "551",
        "shared_name" : "gen7 (interacts with) Devastating Drake",
        "name" : "gen7 (interacts with) Devastating Drake",
        "interaction" : "interacts with",
        "SUID" : 553,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "549",
        "source" : "457",
        "target" : "547",
        "shared_name" : "gen7 (interacts with) Darkest Lariat",
        "name" : "gen7 (interacts with) Darkest Lariat",
        "interaction" : "interacts with",
        "SUID" : 549,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "545",
        "source" : "457",
        "target" : "543",
        "shared_name" : "gen7 (interacts with) Corkscrew Crash",
        "name" : "gen7 (interacts with) Corkscrew Crash",
        "interaction" : "interacts with",
        "SUID" : 545,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "541",
        "source" : "457",
        "target" : "539",
        "shared_name" : "gen7 (interacts with) Core Enforcer",
        "name" : "gen7 (interacts with) Core Enforcer",
        "interaction" : "interacts with",
        "SUID" : 541,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "537",
        "source" : "457",
        "target" : "535",
        "shared_name" : "gen7 (interacts with) Continental Crush",
        "name" : "gen7 (interacts with) Continental Crush",
        "interaction" : "interacts with",
        "SUID" : 537,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "533",
        "source" : "457",
        "target" : "531",
        "shared_name" : "gen7 (interacts with) Clangorous Soulblaze",
        "name" : "gen7 (interacts with) Clangorous Soulblaze",
        "interaction" : "interacts with",
        "SUID" : 533,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "529",
        "source" : "457",
        "target" : "527",
        "shared_name" : "gen7 (interacts with) Clanging Scales",
        "name" : "gen7 (interacts with) Clanging Scales",
        "interaction" : "interacts with",
        "SUID" : 529,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "525",
        "source" : "457",
        "target" : "523",
        "shared_name" : "gen7 (interacts with) Catastropika",
        "name" : "gen7 (interacts with) Catastropika",
        "interaction" : "interacts with",
        "SUID" : 525,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "521",
        "source" : "457",
        "target" : "519",
        "shared_name" : "gen7 (interacts with) Buzzy Buzz",
        "name" : "gen7 (interacts with) Buzzy Buzz",
        "interaction" : "interacts with",
        "SUID" : 521,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "517",
        "source" : "457",
        "target" : "515",
        "shared_name" : "gen7 (interacts with) Burn Up",
        "name" : "gen7 (interacts with) Burn Up",
        "interaction" : "interacts with",
        "SUID" : 517,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "513",
        "source" : "457",
        "target" : "511",
        "shared_name" : "gen7 (interacts with) Brutal Swing",
        "name" : "gen7 (interacts with) Brutal Swing",
        "interaction" : "interacts with",
        "SUID" : 513,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "509",
        "source" : "457",
        "target" : "507",
        "shared_name" : "gen7 (interacts with) Breakneck Blitz",
        "name" : "gen7 (interacts with) Breakneck Blitz",
        "interaction" : "interacts with",
        "SUID" : 509,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "505",
        "source" : "457",
        "target" : "503",
        "shared_name" : "gen7 (interacts with) Bouncy Bubble",
        "name" : "gen7 (interacts with) Bouncy Bubble",
        "interaction" : "interacts with",
        "SUID" : 505,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "501",
        "source" : "457",
        "target" : "499",
        "shared_name" : "gen7 (interacts with) Bloom Doom",
        "name" : "gen7 (interacts with) Bloom Doom",
        "interaction" : "interacts with",
        "SUID" : 501,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "497",
        "source" : "457",
        "target" : "495",
        "shared_name" : "gen7 (interacts with) Black Hole Eclipse",
        "name" : "gen7 (interacts with) Black Hole Eclipse",
        "interaction" : "interacts with",
        "SUID" : 497,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "493",
        "source" : "457",
        "target" : "491",
        "shared_name" : "gen7 (interacts with) Beak Blast",
        "name" : "gen7 (interacts with) Beak Blast",
        "interaction" : "interacts with",
        "SUID" : 493,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "489",
        "source" : "457",
        "target" : "487",
        "shared_name" : "gen7 (interacts with) Baneful Bunker",
        "name" : "gen7 (interacts with) Baneful Bunker",
        "interaction" : "interacts with",
        "SUID" : 489,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "485",
        "source" : "457",
        "target" : "483",
        "shared_name" : "gen7 (interacts with) Baddy Bad",
        "name" : "gen7 (interacts with) Baddy Bad",
        "interaction" : "interacts with",
        "SUID" : 485,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "481",
        "source" : "457",
        "target" : "479",
        "shared_name" : "gen7 (interacts with) Aurora Veil",
        "name" : "gen7 (interacts with) Aurora Veil",
        "interaction" : "interacts with",
        "SUID" : 481,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "477",
        "source" : "457",
        "target" : "475",
        "shared_name" : "gen7 (interacts with) Anchor Shot",
        "name" : "gen7 (interacts with) Anchor Shot",
        "interaction" : "interacts with",
        "SUID" : 477,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "473",
        "source" : "457",
        "target" : "471",
        "shared_name" : "gen7 (interacts with) All-Out Pummeling",
        "name" : "gen7 (interacts with) All-Out Pummeling",
        "interaction" : "interacts with",
        "SUID" : 473,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "469",
        "source" : "457",
        "target" : "467",
        "shared_name" : "gen7 (interacts with) Acid Downpour",
        "name" : "gen7 (interacts with) Acid Downpour",
        "interaction" : "interacts with",
        "SUID" : 469,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "465",
        "source" : "457",
        "target" : "463",
        "shared_name" : "gen7 (interacts with) Accelerock",
        "name" : "gen7 (interacts with) Accelerock",
        "interaction" : "interacts with",
        "SUID" : 465,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "461",
        "source" : "457",
        "target" : "459",
        "shared_name" : "gen7 (interacts with) 10,000,000 Volt Thunderbolt",
        "name" : "gen7 (interacts with) 10,000,000 Volt Thunderbolt",
        "interaction" : "interacts with",
        "SUID" : 461,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "455",
        "source" : "207",
        "target" : "453",
        "shared_name" : "gen6 (interacts with) Water Shuriken",
        "name" : "gen6 (interacts with) Water Shuriken",
        "interaction" : "interacts with",
        "SUID" : 455,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "451",
        "source" : "207",
        "target" : "449",
        "shared_name" : "gen6 (interacts with) Venom Drench",
        "name" : "gen6 (interacts with) Venom Drench",
        "interaction" : "interacts with",
        "SUID" : 451,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "447",
        "source" : "207",
        "target" : "445",
        "shared_name" : "gen6 (interacts with) Trick-or-Treat",
        "name" : "gen6 (interacts with) Trick-or-Treat",
        "interaction" : "interacts with",
        "SUID" : 447,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "443",
        "source" : "207",
        "target" : "441",
        "shared_name" : "gen6 (interacts with) Topsy-Turvy",
        "name" : "gen6 (interacts with) Topsy-Turvy",
        "interaction" : "interacts with",
        "SUID" : 443,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "439",
        "source" : "207",
        "target" : "437",
        "shared_name" : "gen6 (interacts with) Thousand Waves",
        "name" : "gen6 (interacts with) Thousand Waves",
        "interaction" : "interacts with",
        "SUID" : 439,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "435",
        "source" : "207",
        "target" : "433",
        "shared_name" : "gen6 (interacts with) Thousand Arrows",
        "name" : "gen6 (interacts with) Thousand Arrows",
        "interaction" : "interacts with",
        "SUID" : 435,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "431",
        "source" : "207",
        "target" : "429",
        "shared_name" : "gen6 (interacts with) Sticky Web",
        "name" : "gen6 (interacts with) Sticky Web",
        "interaction" : "interacts with",
        "SUID" : 431,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "427",
        "source" : "207",
        "target" : "425",
        "shared_name" : "gen6 (interacts with) Steam Eruption",
        "name" : "gen6 (interacts with) Steam Eruption",
        "interaction" : "interacts with",
        "SUID" : 427,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "423",
        "source" : "207",
        "target" : "421",
        "shared_name" : "gen6 (interacts with) Spiky Shield",
        "name" : "gen6 (interacts with) Spiky Shield",
        "interaction" : "interacts with",
        "SUID" : 423,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "419",
        "source" : "207",
        "target" : "417",
        "shared_name" : "gen6 (interacts with) Rototiller",
        "name" : "gen6 (interacts with) Rototiller",
        "interaction" : "interacts with",
        "SUID" : 419,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "415",
        "source" : "207",
        "target" : "413",
        "shared_name" : "gen6 (interacts with) Precipice Blades",
        "name" : "gen6 (interacts with) Precipice Blades",
        "interaction" : "interacts with",
        "SUID" : 415,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "411",
        "source" : "207",
        "target" : "409",
        "shared_name" : "gen6 (interacts with) Power-Up Punch",
        "name" : "gen6 (interacts with) Power-Up Punch",
        "interaction" : "interacts with",
        "SUID" : 411,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "407",
        "source" : "207",
        "target" : "405",
        "shared_name" : "gen6 (interacts with) Powder",
        "name" : "gen6 (interacts with) Powder",
        "interaction" : "interacts with",
        "SUID" : 407,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "403",
        "source" : "207",
        "target" : "401",
        "shared_name" : "gen6 (interacts with) Play Rough",
        "name" : "gen6 (interacts with) Play Rough",
        "interaction" : "interacts with",
        "SUID" : 403,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "399",
        "source" : "207",
        "target" : "397",
        "shared_name" : "gen6 (interacts with) Play Nice",
        "name" : "gen6 (interacts with) Play Nice",
        "interaction" : "interacts with",
        "SUID" : 399,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "395",
        "source" : "207",
        "target" : "393",
        "shared_name" : "gen6 (interacts with) Phantom Force",
        "name" : "gen6 (interacts with) Phantom Force",
        "interaction" : "interacts with",
        "SUID" : 395,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "391",
        "source" : "207",
        "target" : "389",
        "shared_name" : "gen6 (interacts with) Petal Blizzard",
        "name" : "gen6 (interacts with) Petal Blizzard",
        "interaction" : "interacts with",
        "SUID" : 391,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "387",
        "source" : "207",
        "target" : "385",
        "shared_name" : "gen6 (interacts with) Parting Shot",
        "name" : "gen6 (interacts with) Parting Shot",
        "interaction" : "interacts with",
        "SUID" : 387,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "383",
        "source" : "207",
        "target" : "381",
        "shared_name" : "gen6 (interacts with) Parabolic Charge",
        "name" : "gen6 (interacts with) Parabolic Charge",
        "interaction" : "interacts with",
        "SUID" : 383,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "379",
        "source" : "207",
        "target" : "377",
        "shared_name" : "gen6 (interacts with) Origin Pulse",
        "name" : "gen6 (interacts with) Origin Pulse",
        "interaction" : "interacts with",
        "SUID" : 379,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "375",
        "source" : "207",
        "target" : "373",
        "shared_name" : "gen6 (interacts with) Oblivion Wing",
        "name" : "gen6 (interacts with) Oblivion Wing",
        "interaction" : "interacts with",
        "SUID" : 375,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "371",
        "source" : "207",
        "target" : "369",
        "shared_name" : "gen6 (interacts with) Nuzzle",
        "name" : "gen6 (interacts with) Nuzzle",
        "interaction" : "interacts with",
        "SUID" : 371,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "367",
        "source" : "207",
        "target" : "365",
        "shared_name" : "gen6 (interacts with) Noble Roar",
        "name" : "gen6 (interacts with) Noble Roar",
        "interaction" : "interacts with",
        "SUID" : 367,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "363",
        "source" : "207",
        "target" : "361",
        "shared_name" : "gen6 (interacts with) Mystical Fire",
        "name" : "gen6 (interacts with) Mystical Fire",
        "interaction" : "interacts with",
        "SUID" : 363,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "359",
        "source" : "207",
        "target" : "357",
        "shared_name" : "gen6 (interacts with) Moonblast",
        "name" : "gen6 (interacts with) Moonblast",
        "interaction" : "interacts with",
        "SUID" : 359,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "355",
        "source" : "207",
        "target" : "353",
        "shared_name" : "gen6 (interacts with) Misty Terrain",
        "name" : "gen6 (interacts with) Misty Terrain",
        "interaction" : "interacts with",
        "SUID" : 355,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "351",
        "source" : "207",
        "target" : "349",
        "shared_name" : "gen6 (interacts with) Mat Block",
        "name" : "gen6 (interacts with) Mat Block",
        "interaction" : "interacts with",
        "SUID" : 351,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "347",
        "source" : "207",
        "target" : "345",
        "shared_name" : "gen6 (interacts with) Magnetic Flux",
        "name" : "gen6 (interacts with) Magnetic Flux",
        "interaction" : "interacts with",
        "SUID" : 347,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "343",
        "source" : "207",
        "target" : "341",
        "shared_name" : "gen6 (interacts with) Light of Ruin",
        "name" : "gen6 (interacts with) Light of Ruin",
        "interaction" : "interacts with",
        "SUID" : 343,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "339",
        "source" : "207",
        "target" : "337",
        "shared_name" : "gen6 (interacts with) Land's Wrath",
        "name" : "gen6 (interacts with) Land's Wrath",
        "interaction" : "interacts with",
        "SUID" : 339,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "335",
        "source" : "207",
        "target" : "333",
        "shared_name" : "gen6 (interacts with) King's Shield",
        "name" : "gen6 (interacts with) King's Shield",
        "interaction" : "interacts with",
        "SUID" : 335,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "331",
        "source" : "207",
        "target" : "329",
        "shared_name" : "gen6 (interacts with) Ion Deluge",
        "name" : "gen6 (interacts with) Ion Deluge",
        "interaction" : "interacts with",
        "SUID" : 331,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "327",
        "source" : "207",
        "target" : "325",
        "shared_name" : "gen6 (interacts with) Infestation",
        "name" : "gen6 (interacts with) Infestation",
        "interaction" : "interacts with",
        "SUID" : 327,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "323",
        "source" : "207",
        "target" : "321",
        "shared_name" : "gen6 (interacts with) Hyperspace Hole",
        "name" : "gen6 (interacts with) Hyperspace Hole",
        "interaction" : "interacts with",
        "SUID" : 323,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "319",
        "source" : "207",
        "target" : "317",
        "shared_name" : "gen6 (interacts with) Hyperspace Fury",
        "name" : "gen6 (interacts with) Hyperspace Fury",
        "interaction" : "interacts with",
        "SUID" : 319,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "315",
        "source" : "207",
        "target" : "313",
        "shared_name" : "gen6 (interacts with) Hold Hands",
        "name" : "gen6 (interacts with) Hold Hands",
        "interaction" : "interacts with",
        "SUID" : 315,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "311",
        "source" : "207",
        "target" : "309",
        "shared_name" : "gen6 (interacts with) Hold Back",
        "name" : "gen6 (interacts with) Hold Back",
        "interaction" : "interacts with",
        "SUID" : 311,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "307",
        "source" : "207",
        "target" : "305",
        "shared_name" : "gen6 (interacts with) Happy Hour",
        "name" : "gen6 (interacts with) Happy Hour",
        "interaction" : "interacts with",
        "SUID" : 307,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "303",
        "source" : "207",
        "target" : "301",
        "shared_name" : "gen6 (interacts with) Grassy Terrain",
        "name" : "gen6 (interacts with) Grassy Terrain",
        "interaction" : "interacts with",
        "SUID" : 303,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "299",
        "source" : "207",
        "target" : "297",
        "shared_name" : "gen6 (interacts with) Geomancy",
        "name" : "gen6 (interacts with) Geomancy",
        "interaction" : "interacts with",
        "SUID" : 299,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "295",
        "source" : "207",
        "target" : "293",
        "shared_name" : "gen6 (interacts with) Freeze-Dry",
        "name" : "gen6 (interacts with) Freeze-Dry",
        "interaction" : "interacts with",
        "SUID" : 295,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "291",
        "source" : "207",
        "target" : "289",
        "shared_name" : "gen6 (interacts with) Forest's Curse",
        "name" : "gen6 (interacts with) Forest's Curse",
        "interaction" : "interacts with",
        "SUID" : 291,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "287",
        "source" : "207",
        "target" : "285",
        "shared_name" : "gen6 (interacts with) Flying Press",
        "name" : "gen6 (interacts with) Flying Press",
        "interaction" : "interacts with",
        "SUID" : 287,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "283",
        "source" : "207",
        "target" : "281",
        "shared_name" : "gen6 (interacts with) Flower Shield",
        "name" : "gen6 (interacts with) Flower Shield",
        "interaction" : "interacts with",
        "SUID" : 283,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "279",
        "source" : "207",
        "target" : "277",
        "shared_name" : "gen6 (interacts with) Fell Stinger",
        "name" : "gen6 (interacts with) Fell Stinger",
        "interaction" : "interacts with",
        "SUID" : 279,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "275",
        "source" : "207",
        "target" : "273",
        "shared_name" : "gen6 (interacts with) Fairy Wind",
        "name" : "gen6 (interacts with) Fairy Wind",
        "interaction" : "interacts with",
        "SUID" : 275,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "271",
        "source" : "207",
        "target" : "269",
        "shared_name" : "gen6 (interacts with) Fairy Lock",
        "name" : "gen6 (interacts with) Fairy Lock",
        "interaction" : "interacts with",
        "SUID" : 271,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "267",
        "source" : "207",
        "target" : "265",
        "shared_name" : "gen6 (interacts with) Electrify",
        "name" : "gen6 (interacts with) Electrify",
        "interaction" : "interacts with",
        "SUID" : 267,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "263",
        "source" : "207",
        "target" : "261",
        "shared_name" : "gen6 (interacts with) Electric Terrain",
        "name" : "gen6 (interacts with) Electric Terrain",
        "interaction" : "interacts with",
        "SUID" : 263,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "259",
        "source" : "207",
        "target" : "257",
        "shared_name" : "gen6 (interacts with) Eerie Impulse",
        "name" : "gen6 (interacts with) Eerie Impulse",
        "interaction" : "interacts with",
        "SUID" : 259,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "255",
        "source" : "207",
        "target" : "253",
        "shared_name" : "gen6 (interacts with) Draining Kiss",
        "name" : "gen6 (interacts with) Draining Kiss",
        "interaction" : "interacts with",
        "SUID" : 255,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "251",
        "source" : "207",
        "target" : "249",
        "shared_name" : "gen6 (interacts with) Dragon Ascent",
        "name" : "gen6 (interacts with) Dragon Ascent",
        "interaction" : "interacts with",
        "SUID" : 251,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "247",
        "source" : "207",
        "target" : "245",
        "shared_name" : "gen6 (interacts with) Disarming Voice",
        "name" : "gen6 (interacts with) Disarming Voice",
        "interaction" : "interacts with",
        "SUID" : 247,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "243",
        "source" : "207",
        "target" : "241",
        "shared_name" : "gen6 (interacts with) Diamond Storm",
        "name" : "gen6 (interacts with) Diamond Storm",
        "interaction" : "interacts with",
        "SUID" : 243,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "239",
        "source" : "207",
        "target" : "237",
        "shared_name" : "gen6 (interacts with) Dazzling Gleam",
        "name" : "gen6 (interacts with) Dazzling Gleam",
        "interaction" : "interacts with",
        "SUID" : 239,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "235",
        "source" : "207",
        "target" : "233",
        "shared_name" : "gen6 (interacts with) Crafty Shield",
        "name" : "gen6 (interacts with) Crafty Shield",
        "interaction" : "interacts with",
        "SUID" : 235,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "231",
        "source" : "207",
        "target" : "229",
        "shared_name" : "gen6 (interacts with) Confide",
        "name" : "gen6 (interacts with) Confide",
        "interaction" : "interacts with",
        "SUID" : 231,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "227",
        "source" : "207",
        "target" : "225",
        "shared_name" : "gen6 (interacts with) Celebrate",
        "name" : "gen6 (interacts with) Celebrate",
        "interaction" : "interacts with",
        "SUID" : 227,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "223",
        "source" : "207",
        "target" : "221",
        "shared_name" : "gen6 (interacts with) Boomburst",
        "name" : "gen6 (interacts with) Boomburst",
        "interaction" : "interacts with",
        "SUID" : 223,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "219",
        "source" : "207",
        "target" : "217",
        "shared_name" : "gen6 (interacts with) Belch",
        "name" : "gen6 (interacts with) Belch",
        "interaction" : "interacts with",
        "SUID" : 219,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "215",
        "source" : "207",
        "target" : "213",
        "shared_name" : "gen6 (interacts with) Baby-Doll Eyes",
        "name" : "gen6 (interacts with) Baby-Doll Eyes",
        "interaction" : "interacts with",
        "SUID" : 215,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "211",
        "source" : "207",
        "target" : "209",
        "shared_name" : "gen6 (interacts with) Aromatic Mist",
        "name" : "gen6 (interacts with) Aromatic Mist",
        "interaction" : "interacts with",
        "SUID" : 211,
        "shared_interaction" : "interacts with",
        "selected" : false
      },
      "selected" : false
    } ]
  }
},"Network": {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.3",
  "target_cytoscapejs_version" : "~2.1",
  "data" : {
    "shared_name" : "Network",
    "name" : "Network",
    "SUID" : 128,
    "__Annotations" : [ ],
    "selected" : false
  },
  "elements" : {
    "nodes" : [ ],
    "edges" : [ ]
  }
}}